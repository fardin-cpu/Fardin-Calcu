import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  CONST_CATEGORIES,
  CONV_CATEGORIES,
  SCIENTIFIC_CONSTANTS,
  UNIT_CONVERSIONS,
} from './calculator/constantsData';
import { formatDms, gcdInt, lcmInt, primeFactorizeString, tryExactRepresentation } from './calculator/exactMath';
import {
  computeDistribution,
  computeStatistics,
  evalSpreadsheetCell,
  solveInequality,
  solvePolynomial,
} from './calculator/modesSolver';
import { DistType, StatRow, StatType } from './calculator/types';
import { OfflineIndicator, PWAInstallButton } from './components/PWAControls';

interface KeyDef {
  id: string;
  face?: string;
  shiftLabel?: string;
  alphaLabel?: string;
  main?: string;
  shiftAct?: string;
  alphaAct?: string;
  cls?: string;
  blueLabel?: string;
  isDp?: boolean;
}

const TOP: KeyDef[] = [
  { id: 'SHIFT', face: '', shiftLabel: 'SHIFT', alphaLabel: '', main: '@sh', shiftAct: '', alphaAct: '', cls: 'rd' },
  { id: 'ALPHA', face: '', shiftLabel: '', alphaLabel: 'ALPHA', main: '@al', shiftAct: '', alphaAct: '', cls: 'rd' },
  { id: 'DP', isDp: true },
  { id: 'MENU', face: '', shiftLabel: '<u>MENU</u> SETUP', alphaLabel: '', main: '@menu', shiftAct: '@setup', alphaAct: '', cls: 'rd' },
  { id: 'ON', face: '', shiftLabel: '<u>ON</u>', alphaLabel: '', main: '@on', shiftAct: '@on', alphaAct: '', cls: 'rd' },
  { id: 'OPTN', face: 'OPTN', shiftLabel: 'QR', alphaLabel: '', main: '@optn', shiftAct: '@qr', alphaAct: '', cls: 'dk' },
  { id: 'CALC', face: 'CALC', shiftLabel: 'SOLVE', alphaLabel: '=', main: '@calc', shiftAct: '@solve', alphaAct: '=', cls: 'dk' },
  { id: 'INT', face: '∫▫', shiftLabel: 'd/dx', alphaLabel: ':', main: '@int', shiftAct: '@deriv', alphaAct: ':', cls: 'dk' },
  { id: 'X', face: '<i>x</i>', shiftLabel: 'Σ', alphaLabel: 'Π', main: 'x', shiftAct: '@sum', alphaAct: '@prod', cls: 'dk' },
  { id: 'FRAC', face: '▭/▭', shiftLabel: '■▭', alphaLabel: '÷R', main: '@frac', shiftAct: '@mxfrac', alphaAct: '÷R', cls: 'dk' },
  { id: 'SQ', face: '√▭', shiftLabel: '∛', alphaLabel: '', main: '@sqrt', shiftAct: '@cbrt', alphaAct: '', cls: 'dk' },
  { id: 'X2', face: '<i>x</i>²', shiftLabel: 'x³', alphaLabel: '', main: '²', shiftAct: '³', alphaAct: '', cls: 'dk', blueLabel: 'DEC' },
  { id: 'XP', face: '<i>x</i><sup>▪</sup>', shiftLabel: 'ˣ√', alphaLabel: '', main: '@pow', shiftAct: '@nroot', alphaAct: '', cls: 'dk', blueLabel: 'HEX' },
  { id: 'LOG', face: 'log▫', shiftLabel: '10ˣ', alphaLabel: '', main: '@logb', shiftAct: '@pow10', alphaAct: '', cls: 'dk', blueLabel: 'BIN' },
  { id: 'LN', face: 'ln', shiftLabel: 'eˣ', alphaLabel: '', main: 'ln(', shiftAct: '@powe', alphaAct: '', cls: 'dk', blueLabel: 'OCT' },
  { id: 'NEG', face: '(−)', shiftLabel: 'log', alphaLabel: 'A', main: '−', shiftAct: 'log(', alphaAct: 'A', cls: 'dk' },
  { id: 'DMS', face: '°′″', shiftLabel: 'FACT', alphaLabel: 'B', main: '@dms', shiftAct: '@fact', alphaAct: 'B', cls: 'dk' },
  { id: 'INV', face: '<i>x</i>⁻¹', shiftLabel: 'x!', alphaLabel: 'C', main: '⁻¹', shiftAct: '!', alphaAct: 'C', cls: 'dk' },
  { id: 'SIN', face: 'sin', shiftLabel: 'sin⁻¹', alphaLabel: 'D', main: 'sin(', shiftAct: 'asin(', alphaAct: 'D', cls: 'dk' },
  { id: 'COS', face: 'cos', shiftLabel: 'cos⁻¹', alphaLabel: 'E', main: 'cos(', shiftAct: 'acos(', alphaAct: 'E', cls: 'dk' },
  { id: 'TAN', face: 'tan', shiftLabel: 'tan⁻¹', alphaLabel: 'F', main: 'tan(', shiftAct: 'atan(', alphaAct: 'F', cls: 'dk' },
  { id: 'STO', face: 'STO', shiftLabel: 'RECALL', alphaLabel: '', main: '@sto', shiftAct: '@rcl', alphaAct: '', cls: 'dk' },
  { id: 'ENG', face: 'ENG', shiftLabel: '∠', alphaLabel: 'i', main: '@eng', shiftAct: '@ang', alphaAct: 'i', cls: 'dk' },
  { id: 'LP', face: '(', shiftLabel: 'Abs', alphaLabel: '', main: '(', shiftAct: '@abs', alphaAct: '', cls: 'dk' },
  { id: 'RP', face: ')', shiftLabel: ';', alphaLabel: 'x', main: ')', shiftAct: ';', alphaAct: 'x', cls: 'dk' },
  { id: 'SD', face: 'S⇔D', shiftLabel: 'a b/c⇔d/c', alphaLabel: 'y', main: '@sd', shiftAct: '@mx', alphaAct: 'y', cls: 'dk' },
  { id: 'MP', face: 'M+', shiftLabel: 'M−', alphaLabel: 'M', main: '@mp', shiftAct: '@mm', alphaAct: 'M', cls: 'dk' },
];

const NUM: KeyDef[] = [
  { id: '7', face: '7', shiftLabel: 'CONST', alphaLabel: '', main: '7', shiftAct: '@const', alphaAct: '', cls: 'lt' },
  { id: '8', face: '8', shiftLabel: 'CONV', alphaLabel: '', main: '8', shiftAct: '@conv', alphaAct: '', cls: 'lt' },
  { id: '9', face: '9', shiftLabel: 'RESET', alphaLabel: '', main: '9', shiftAct: '@reset', alphaAct: '', cls: 'lt' },
  { id: 'DEL', face: 'DEL', shiftLabel: 'INS', alphaLabel: 'UNDO', main: '@del', shiftAct: '@ins', alphaAct: '@undo', cls: 'bl' },
  { id: 'AC', face: 'AC', shiftLabel: 'OFF', alphaLabel: '', main: '@ac', shiftAct: '@off', alphaAct: '', cls: 'bl' },
  { id: '4', face: '4', shiftLabel: '', alphaLabel: '', main: '4', shiftAct: '', alphaAct: '', cls: 'lt' },
  { id: '5', face: '5', shiftLabel: '', alphaLabel: '', main: '5', shiftAct: '', alphaAct: '', cls: 'lt' },
  { id: '6', face: '6', shiftLabel: '', alphaLabel: '', main: '6', shiftAct: '', alphaAct: '', cls: 'lt' },
  { id: 'MUL', face: '×', shiftLabel: 'nPr', alphaLabel: 'GCD', main: '×', shiftAct: 'P', alphaAct: 'GCD(', cls: 'lt' },
  { id: 'DIV', face: '÷', shiftLabel: 'nCr', alphaLabel: 'LCM', main: '÷', shiftAct: 'C', alphaAct: 'LCM(', cls: 'lt' },
  { id: '1', face: '1', shiftLabel: '', alphaLabel: '', main: '1', shiftAct: '', alphaAct: '', cls: 'lt' },
  { id: '2', face: '2', shiftLabel: '', alphaLabel: '', main: '2', shiftAct: '', alphaAct: '', cls: 'lt' },
  { id: '3', face: '3', shiftLabel: '', alphaLabel: '', main: '3', shiftAct: '', alphaAct: '', cls: 'lt' },
  { id: 'ADD', face: '+', shiftLabel: 'Pol', alphaLabel: 'Int', main: '+', shiftAct: 'Pol(', alphaAct: 'Int(', cls: 'lt' },
  { id: 'SUB', face: '−', shiftLabel: 'Rec', alphaLabel: 'Intg', main: '−', shiftAct: 'Rec(', alphaAct: 'Intg(', cls: 'lt' },
  { id: '0', face: '0', shiftLabel: 'Rnd', alphaLabel: '', main: '0', shiftAct: 'Rnd(', alphaAct: '', cls: 'lt' },
  { id: 'DOT', face: '.', shiftLabel: 'Ran#', alphaLabel: 'RanInt', main: '.', shiftAct: 'Ran#', alphaAct: 'RanInt(', cls: 'lt' },
  { id: 'EXP', face: '×10<sup>x</sup>', shiftLabel: 'π', alphaLabel: 'e', main: 'ᴇ', shiftAct: 'π', alphaAct: 'ℯ', cls: 'lt' },
  { id: 'ANS', face: 'Ans', shiftLabel: '%', alphaLabel: '', main: 'Ans', shiftAct: '%', alphaAct: '', cls: 'lt' },
  { id: 'EQ', face: '=', shiftLabel: '≈', alphaLabel: '', main: '@eq', shiftAct: '@approx', alphaAct: '', cls: 'lt' },
];

const KM: Record<string, { m: string; s: string; a: string }> = {};
[...TOP, ...NUM].forEach((k) => {
  if (!k.isDp) {
    KM[k.id] = { m: k.main ?? '', s: k.shiftAct ?? '', a: k.alphaAct ?? '' };
  }
});
['U', 'D', 'L', 'R'].forEach((id) => {
  KM[id] = { m: '', s: '', a: '' };
});

const OPS = ['+', '−', '×', '÷', '⁄', '^', '²', '³', '⁻¹', '!', 'P', 'C', 'ˣ√', '%', '∠', '÷R', 'and', 'or', 'xor', 'xnor', '·', '×v'];
const DISP: Record<string, string> = {
  'asin(': 'sin⁻¹(',
  'acos(': 'cos⁻¹(',
  'atan(': 'tan⁻¹(',
  'asinh(': 'sinh⁻¹(',
  'acosh(': 'cosh⁻¹(',
  'atanh(': 'tanh⁻¹(',
  'abs(': 'Abs(',
  '∛(': '³√(',
  'ℯ': 'e',
  'Ran#': 'Ran#',
  '■': ' ',
  '⁄': '/',
  '·': '•',
  '×v': '×',
};

const STRUCT_OPEN = new Set([
  '⟨FR:', '⟨MX:', '⟨SQ:', '⟨CR:', '⟨NR:', '⟨PW:', '⟨LG:', '⟨AB:', '⟨IN:', '⟨DX:', '⟨SM:', '⟨PR:',
]);
const STRUCT_ATOM_OPEN = new Set([
  '⟨FR:', '⟨MX:', '⟨SQ:', '⟨CR:', '⟨NR:', '⟨LG:', '⟨AB:', '⟨IN:', '⟨DX:', '⟨SM:', '⟨PR:',
]);
const STRUCT_CLOSE: Record<string, string> = {
  '⟨FR:': '⟩FR',
  '⟨MX:': '⟩MX',
  '⟨SQ:': '⟩SQ',
  '⟨CR:': '⟩CR',
  '⟨NR:': '⟩NR',
  '⟨PW:': '⟩PW',
  '⟨LG:': '⟩LG',
  '⟨AB:': '⟩AB',
  '⟨IN:': '⟩IN',
  '⟨DX:': '⟩DX',
  '⟨SM:': '⟩SM',
  '⟨PR:': '⟩PR',
};
const CLOSE_TO_OPEN: Record<string, string> = {
  '⟩FR': '⟨FR:',
  '⟩MX': '⟨MX:',
  '⟩SQ': '⟨SQ:',
  '⟩CR': '⟨CR:',
  '⟩NR': '⟨NR:',
  '⟩PW': '⟨PW:',
  '⟩LG': '⟨LG:',
  '⟩AB': '⟨AB:',
  '⟩IN': '⟨IN:',
  '⟩DX': '⟨DX:',
  '⟩SM': '⟨SM:',
  '⟩PR': '⟨PR:',
};

function findMatchingClose(t: string[], openIdx: number): { bars: number[]; closeIdx: number } {
  const bars: number[] = [];
  let depth = 1;
  for (let i = openIdx + 1; i < t.length; i++) {
    if (STRUCT_OPEN.has(t[i])) depth++;
    else if (CLOSE_TO_OPEN[t[i]]) {
      depth--;
      if (depth === 0) return { bars, closeIdx: i };
    } else if (depth === 1 && t[i] === '¦') {
      bars.push(i);
    }
  }
  return { bars, closeIdx: t.length };
}

function findMatchingOpen(t: string[], closeIdx: number): number {
  let depth = 1;
  for (let i = closeIdx - 1; i >= 0; i--) {
    if (CLOSE_TO_OPEN[t[i]]) depth++;
    else if (STRUCT_OPEN.has(t[i])) {
      depth--;
      if (depth === 0) return i;
    }
  }
  return 0;
}

function pullLeftOperandStart(t: string[], c: number): number {
  let idx = c;
  const isPost = (tok: string | undefined) => tok !== undefined && ['²', '³', '⁻¹', '!', '%', '°', 'ʳ', 'ᵍ'].includes(tok);
  while (idx > 0 && (isPost(t[idx - 1]) || t[idx - 1] === '⟩PW')) {
    if (t[idx - 1] === '⟩PW') idx = findMatchingOpen(t, idx - 1);
    else idx--;
  }
  if (idx === 0) return c;
  const prev = t[idx - 1];
  if (CLOSE_TO_OPEN[prev]) {
    return findMatchingOpen(t, idx - 1);
  }
  if (prev === ')') {
    let d = 1;
    let k = idx - 2;
    while (k >= 0 && d > 0) {
      if (t[k] === ')') d++;
      else if (t[k] === '(' || t[k].endsWith('(')) d--;
      if (d === 0) break;
      k--;
    }
    return Math.max(0, k);
  }
  if (/^[0-9.]$/.test(prev)) {
    let k = idx - 1;
    while (k > 0 && (/^[0-9.]$/.test(t[k - 1]) || t[k - 1] === 'ᴇ')) k--;
    return k;
  }
  if (
    prev === 'π' || prev === 'ℯ' || prev === 'i' || prev === 'Ans' || prev === 'Ran#' ||
    prev.startsWith('CONST:') || /^[A-FMxy]$/.test(prev) ||
    prev === 'MatA' || prev === 'MatB' || prev === 'MatC' || prev === 'MatAns' ||
    prev === 'VctA' || prev === 'VctB' || prev === 'VctC' || prev === 'VctAns'
  ) {
    return idx - 1;
  }
  return c;
}

function jumpVertical(t: string[], c: number, dir: 'U' | 'D'): number | null {
  let depth = 0;
  for (let i = c - 1; i >= 0; i--) {
    if (CLOSE_TO_OPEN[t[i]]) depth++;
    else if (STRUCT_OPEN.has(t[i])) {
      if (depth === 0) {
        const { bars, closeIdx } = findMatchingClose(t, i);
        if (t[i] === '⟨PW:' && dir === 'D' && c <= closeIdx) {
          return closeIdx + 1;
        }
        if (bars.length > 0 && c <= closeIdx) {
          const segStarts = [i + 1, ...bars.map((b) => b + 1)];
          const segEnds = [...bars, closeIdx];
          const curSeg = segEnds.findIndex((end) => c <= end);
          if (dir === 'D' && curSeg >= 0 && curSeg < segStarts.length - 1) {
            return segStarts[curSeg + 1];
          }
          if (dir === 'U' && curSeg > 0) {
            return segEnds[curSeg - 1];
          }
        }
      }
      depth--;
    }
  }
  return null;
}

function tokensToReadable(t: string[]): string {
  return t
    .map((tok) => {
      if (tok === '⟨FR:' || tok === '⟨MX:') return '(';
      if (tok === '⟨SQ:') return '√(';
      if (tok === '⟨CR:') return '∛(';
      if (tok === '⟨NR:') return 'root(';
      if (tok === '⟨PW:') return '^(';
      if (tok === '⟨LG:') return 'log(';
      if (tok === '⟨AB:') return 'abs(';
      if (tok === '⟨IN:') return '∫(';
      if (tok === '⟨DX:') return 'd/dx(';
      if (tok === '⟨SM:') return 'Σ(';
      if (tok === '⟨PR:') return 'Π(';
      if (tok === '¦') return '/';
      if (CLOSE_TO_OPEN[tok]) return ')';
      return tok;
    })
    .join('');
}

const APPS = [
  'Calculate',
  'Complex',
  'Base-N',
  'Matrix',
  'Vector',
  'Statistics',
  'Distribution',
  'Spreadsheet',
  'Table',
  'Equation/Func',
  'Inequality',
  'Ratio',
];
const SETUP = ['Angle Unit', 'Number Format', 'Fraction Result', 'Complex Format', 'Statistics Freq', 'Decimal Mark'];

interface Cpx {
  re: number;
  im: number;
}

interface ListState {
  t: string;
  items: string[];
  i: number;
  code?: string;
  fn: (idx: number) => void;
}

interface FormState {
  t: string;
  n: string[];
  v: string[][];
  i: number;
  fn: (fields: string[][]) => string[];
  out: string[] | null;
  p: number;
}

interface CalcResult {
  v?: number;
  cpx?: Cpx;
  mat?: number[][];
  vec?: number[];
  text?: string;
  err?: string;
}

interface CalcState {
  t: string[];
  c: number;
  sh: number;
  al: number;
  ins: boolean;
  mode: string;
  ans: number;
  ansCpx: Cpx;
  v: Record<string, number>;
  vc: Record<string, Cpx>;
  mats: Record<'MatA' | 'MatB' | 'MatC', number[][]>;
  matAns: number[][];
  vecs: Record<'VctA' | 'VctB' | 'VctC', number[]>;
  vctAns: number[];
  sheet: string[][];
  res: CalcResult | null;
  done: number;
  pend: 'sto' | 'rcl' | null;
  on: number;
  fm: number;
  eng: number; // 0 = off, integer != 0 = shift steps
  dms: boolean;
  factMode: boolean;
  cmplxFmt: 'RECT' | 'POLAR';
  qrPayload: string | null;
  hist: string[][];
  hi: number;
  undo: Array<{ t: string[]; c: number }>;
  app: string;
  ls: ListState | null;
  fo: FormState | null;
  base: 'D' | 'H' | 'B' | 'O';
  nf: { t: 'N' | 'F' | 'S'; n: number };
  normVar: 1 | 2;
  mx: number;
  statFreq: boolean;
  decComma: boolean;
  dat: StatRow[];
  statType: StatType;
  statReg: boolean;
  statStep: 'x' | 'y' | 'freq';
  statDraft: { x: number; y: number };
}

const STORAGE_KEY = 'fardin_fx991_state_v1';

function createInitialState(): CalcState {
  return {
    t: [],
    c: 0,
    sh: 0,
    al: 0,
    ins: false,
    mode: 'D',
    ans: 0,
    ansCpx: { re: 0, im: 0 },
    v: {},
    vc: {},
    mats: {
      MatA: [[1, 0], [0, 1]],
      MatB: [[0, 0], [0, 0]],
      MatC: [[0, 0], [0, 0]],
    },
    matAns: [[1, 0], [0, 1]],
    vecs: {
      VctA: [1, 0, 0],
      VctB: [0, 1, 0],
      VctC: [0, 0, 0],
    },
    vctAns: [1, 0, 0],
    sheet: Array.from({ length: 5 }, () => Array(3).fill('')),
    res: null,
    done: 0,
    pend: null,
    on: 1,
    fm: 1,
    eng: 0,
    dms: false,
    factMode: false,
    cmplxFmt: 'RECT',
    qrPayload: null,
    hist: [],
    hi: 0,
    undo: [],
    app: 'calc',
    ls: null,
    fo: null,
    base: 'D',
    nf: { t: 'N', n: 0 },
    normVar: 2,
    mx: 0,
    statFreq: false,
    decComma: false,
    dat: [],
    statType: '1-VAR',
    statReg: false,
    statStep: 'x',
    statDraft: { x: 0, y: 0 },
  };
}

function loadSavedState(): CalcState {
  const base = createInitialState();
  try {
    if (typeof window === 'undefined' || !window.localStorage) return base;
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return base;
    const p = JSON.parse(raw) as Partial<CalcState>;
    if (!p || typeof p !== 'object') return base;
    return {
      ...base,
      mode: p.mode === 'R' || p.mode === 'G' ? p.mode : 'D',
      ans: typeof p.ans === 'number' && Number.isFinite(p.ans) ? p.ans : 0,
      ansCpx: p.ansCpx && typeof p.ansCpx.re === 'number' ? p.ansCpx : base.ansCpx,
      v: p.v && typeof p.v === 'object' ? p.v : {},
      vc: p.vc && typeof p.vc === 'object' ? p.vc : {},
      mats: p.mats && p.mats.MatA ? p.mats : base.mats,
      matAns: Array.isArray(p.matAns) ? p.matAns : base.matAns,
      vecs: p.vecs && p.vecs.VctA ? p.vecs : base.vecs,
      vctAns: Array.isArray(p.vctAns) ? p.vctAns : base.vctAns,
      sheet: Array.isArray(p.sheet) && p.sheet.length === 5 ? p.sheet : base.sheet,
      fm: p.fm === 0 ? 0 : 1,
      cmplxFmt: p.cmplxFmt === 'POLAR' ? 'POLAR' : 'RECT',
      hist: Array.isArray(p.hist) ? p.hist.slice(-20) : [],
      hi: Array.isArray(p.hist) ? p.hist.length : 0,
      app: typeof p.app === 'string' && ['calc', 'cplx', 'base', 'mat', 'vec', 'stat'].includes(p.app) ? p.app : 'calc',
      base: p.base === 'H' || p.base === 'B' || p.base === 'O' ? p.base : 'D',
      nf: p.nf && (p.nf.t === 'N' || p.nf.t === 'F' || p.nf.t === 'S') ? p.nf : base.nf,
      normVar: p.normVar === 1 ? 1 : 2,
      mx: p.mx === 1 ? 1 : 0,
      statFreq: Boolean(p.statFreq),
      decComma: Boolean(p.decComma),
      dat: Array.isArray(p.dat) ? p.dat : [],
      statType: p.statType || '1-VAR',
      statReg: Boolean(p.statReg),
    };
  } catch {
    return base;
  }
}

function savePersistedState(s: CalcState) {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return;
    const payload = {
      mode: s.mode,
      ans: s.ans,
      ansCpx: s.ansCpx,
      v: s.v,
      vc: s.vc,
      mats: s.mats,
      matAns: s.matAns,
      vecs: s.vecs,
      vctAns: s.vctAns,
      sheet: s.sheet,
      fm: s.fm,
      cmplxFmt: s.cmplxFmt,
      hist: s.hist.slice(-20),
      app: ['calc', 'cplx', 'base', 'mat', 'vec', 'stat'].includes(s.app) ? s.app : 'calc',
      base: s.base,
      nf: s.nf,
      normVar: s.normVar,
      mx: s.mx,
      statFreq: s.statFreq,
      decComma: s.decComma,
      dat: s.dat,
      statType: s.statType,
      statReg: s.statReg,
    };
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  } catch {
    // Ignore storage quota / private mode errors
  }
}

function toFrac(x: number): [number, number] | null {
  if (!isFinite(x) || Number.isInteger(x) || Math.abs(x) > 1e7 || Math.abs(x) < 1e-6) return null;
  const s = x < 0 ? -1 : 1;
  const a = Math.abs(x);
  let h1 = 1, h0 = 0, k1 = 0, k0 = 1, b = a;
  for (let i = 0; i < 40; i++) {
    const f = Math.floor(b);
    [h1, h0] = [f * h1 + h0, h1];
    [k1, k0] = [f * k1 + k0, k1];
    if (h1 > 0 && Math.abs(a - h1 / k1) <= 1e-11 * Math.max(1, a)) return k1 < 1e5 ? [s * h1, k1] : null;
    if (b - f < 1e-15) break;
    b = 1 / (b - f);
  }
  return null;
}

const cAdd = (a: Cpx, b: Cpx): Cpx => ({ re: a.re + b.re, im: a.im + b.im });
const cSub = (a: Cpx, b: Cpx): Cpx => ({ re: a.re - b.re, im: a.im - b.im });
const cMul = (a: Cpx, b: Cpx): Cpx => ({ re: a.re * b.re - a.im * b.im, im: a.re * b.im + a.im * b.re });
const cDiv = (a: Cpx, b: Cpx): Cpx => {
  const d = b.re * b.re + b.im * b.im;
  if (d === 0) throw 'Math ERROR';
  return { re: (a.re * b.re + a.im * b.im) / d, im: (a.im * b.re - a.re * b.im) / d };
};
const cExp = (a: Cpx): Cpx => {
  const r = Math.exp(a.re);
  return { re: r * Math.cos(a.im), im: r * Math.sin(a.im) };
};
const cLn = (a: Cpx): Cpx => {
  const r = Math.hypot(a.re, a.im);
  if (r === 0) throw 'Math ERROR';
  return { re: Math.log(r), im: Math.atan2(a.im, a.re) };
};
const cPow = (a: Cpx, b: Cpx): Cpx => {
  if (a.im === 0 && b.im === 0) {
    if (a.re === 0 && b.re < 0) throw 'Math ERROR';
    if (a.re === 0 && b.re === 0) return { re: 1, im: 0 };
    if (a.re > 0 || Number.isInteger(b.re)) return { re: Math.pow(a.re, b.re), im: 0 };
  }
  if (a.re === 0 && a.im === 0) {
    if (b.re > 0 && b.im === 0) return { re: 0, im: 0 };
    throw 'Math ERROR';
  }
  return cExp(cMul(b, cLn(a)));
};

function matDet(m: number[][]): number {
  const n = m.length;
  if (!n || m[0].length !== n) throw 'Dimension ERROR';
  const a = m.map((r) => [...r]);
  let det = 1;
  for (let i = 0; i < n; i++) {
    let pv = i;
    for (let j = i + 1; j < n; j++) if (Math.abs(a[j][i]) > Math.abs(a[pv][i])) pv = j;
    if (Math.abs(a[pv][i]) < 1e-13) return 0;
    if (pv !== i) { [a[i], a[pv]] = [a[pv], a[i]]; det = -det; }
    det *= a[i][i];
    for (let j = i + 1; j < n; j++) {
      const f = a[j][i] / a[i][i];
      for (let k = i; k < n; k++) a[j][k] -= f * a[i][k];
    }
  }
  return det;
}

function matInv(m: number[][]): number[][] {
  const n = m.length;
  if (!n || m[0].length !== n) throw 'Dimension ERROR';
  const aug = m.map((r, i) => [...r, ...Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))]);
  for (let i = 0; i < n; i++) {
    let pv = i;
    for (let j = i + 1; j < n; j++) if (Math.abs(aug[j][i]) > Math.abs(aug[pv][i])) pv = j;
    if (Math.abs(aug[pv][i]) < 1e-13) throw 'Math ERROR';
    if (pv !== i) [aug[i], aug[pv]] = [aug[pv], aug[i]];
    const d = aug[i][i];
    for (let k = 0; k < 2 * n; k++) aug[i][k] /= d;
    for (let j = 0; j < n; j++) {
      if (j === i) continue;
      const f = aug[j][i];
      for (let k = 0; k < 2 * n; k++) aug[j][k] -= f * aug[i][k];
    }
  }
  return aug.map((r) => r.slice(n));
}

function matMul(a: number[][], b: number[][]): number[][] {
  if (a[0].length !== b.length) throw 'Dimension ERROR';
  const out = Array.from({ length: a.length }, () => Array(b[0].length).fill(0));
  for (let i = 0; i < a.length; i++) {
    for (let k = 0; k < b.length; k++) {
      for (let j = 0; j < b[0].length; j++) out[i][j] += a[i][k] * b[k][j];
    }
  }
  return out;
}

export default function App() {
  const sRef = useRef<CalcState>(loadSavedState());
  const exRef = useRef<HTMLDivElement>(null);
  const [, setTick] = useState(0);
  const forceDraw = useCallback(() => {
    savePersistedState(sRef.current);
    setTick((t) => t + 1);
  }, []);

  const S = sRef.current;

  type RVal =
    | { k: 'c'; c: Cpx }
    | { k: 'm'; m: number[][] }
    | { k: 'v'; v: number[] };

  const asC = (r: RVal): Cpx => {
    if (r.k !== 'c') throw 'Syntax ERROR';
    return r.c;
  };
  const asR = (r: RVal): number => {
    const c = asC(r);
    if (Math.abs(c.im) > 1e-10) throw 'Math ERROR';
    return c.re;
  };

  const evalAny = (T: string[], localVars?: Record<string, number>): RVal => {
    let p = 0;
    const pk = () => T[p];
    const ME = (): never => { throw 'Math ERROR'; };
    const SE = (): never => { throw 'Syntax ERROR'; };
    const BN = S.app === 'base';
    const RX = { D: 10, H: 16, B: 2, O: 8 }[S.base];
    const D = (t: string | undefined) => t !== undefined && (BN ? /^[0-9A-F]$/ : /^[0-9.]$/).test(t);
    const rad = (x: number) => (S.mode === 'D' ? (x * Math.PI) / 180 : S.mode === 'G' ? (x * Math.PI) / 200 : x);
    const deg = (x: number) => (S.mode === 'D' ? (x * 180) / Math.PI : S.mode === 'G' ? (x * 200) / Math.PI : x);
    const cl = (r: number) => (Math.abs(r) < 1e-13 ? 0 : r);

    const findMatchingParen = (startPos: number): number => {
      let depth = 1;
      let idx = startPos;
      while (idx < T.length && depth > 0) {
        const tok = T[idx];
        if (tok === '(' || tok.endsWith('(')) depth++;
        else if (tok === ')') depth--;
        if (depth === 0) return idx;
        idx++;
      }
      return T.length;
    };

    const splitArgs = (tokens: string[]): string[][] => {
      const args: string[][] = [];
      let cur: string[] = [];
      let depth = 0;
      for (const tok of tokens) {
        if (tok === '(' || tok.endsWith('(')) depth++;
        else if (tok === ')') depth--;
        if (depth === 0 && tok === ';') {
          args.push(cur);
          cur = [];
        } else {
          cur.push(tok);
        }
      }
      if (cur.length || args.length) args.push(cur);
      return args;
    };

    const fact = (n: number) => {
      if (!Number.isInteger(n) || n < 0 || n > 69) ME();
      let r = 1;
      for (let i = 2; i <= n; i++) r *= i;
      return r;
    };
    const perm = (n: number, r: number) => {
      if (!Number.isInteger(n) || !Number.isInteger(r) || r < 0 || r > n) ME();
      let v = 1;
      for (let i = 0; i < r; i++) v *= n - i;
      return v;
    };
    const comb = (n: number, r: number) => {
      if (!Number.isInteger(n) || !Number.isInteger(r) || r < 0 || r > n) ME();
      let v = 1;
      const k = Math.min(r, n - r);
      for (let i = 1; i <= k; i++) v = (v * (n - k + i)) / i;
      return Math.round(v);
    };

    const singleArgFns = new Set([
      'sin(', 'cos(', 'tan(', 'asin(', 'acos(', 'atan(',
      'sinh(', 'cosh(', 'tanh(', 'asinh(', 'acosh(', 'atanh(',
      'log(', 'ln(', '√(', '∛(', 'abs(', 'Int(', 'Intg(', 'Rnd(',
      'Arg(', 'Conjg(', 'ReP(', 'ImP(', 'Not(', 'Neg(', 'Det(', 'Trn(', 'UnitV(',
    ]);
    const multiArgFns = new Set([
      '∫(', 'd/dx(', 'Σ(', 'Π(', 'GCD(', 'LCM(', 'RanInt(', 'Angle(', 'Pol(', 'Rec(',
    ]);

    const isAtom = (t: string | undefined) =>
      t !== undefined &&
      (D(t) ||
        t === '(' ||
        STRUCT_ATOM_OPEN.has(t) ||
        singleArgFns.has(t) ||
        multiArgFns.has(t) ||
        t === 'π' ||
        t === 'ℯ' ||
        t === 'i' ||
        t === 'Ans' ||
        t === 'Ran#' ||
        t.startsWith('CONST:') ||
        t === 'MatA' || t === 'MatB' || t === 'MatC' || t === 'MatAns' ||
        t === 'VctA' || t === 'VctB' || t === 'VctC' || t === 'VctAns' ||
        /^[A-FMxy]$/.test(t));

    const evalFn = (fn: string, args: string[][]): RVal => {
      if (fn === '∫(') {
        if (args.length < 3) throw 'Argument ERROR';
        const a = asR(evalAny(args[1], localVars));
        const b = asR(evalAny(args[2], localVars));
        const f = (x: number) => asR(evalAny(args[0], { ...localVars, x }));
        const simpson = (l: number, r: number, fl: number, fm: number, fr: number) => ((r - l) / 6) * (fl + 4 * fm + fr);
        const rec = (l: number, r: number, eps: number, w: number, fl: number, fm: number, fr: number, dep: number): number => {
          const m = (l + r) / 2;
          const flm = f((l + m) / 2);
          const frm = f((m + r) / 2);
          const L = simpson(l, m, fl, flm, fm);
          const R = simpson(m, r, fm, frm, fr);
          const d = L + R - w;
          if (dep <= 0 || Math.abs(d) <= 15 * eps) return L + R + d / 15;
          return rec(l, m, eps / 2, L, fl, flm, fm, dep - 1) + rec(m, r, eps / 2, R, fm, frm, fr, dep - 1);
        };
        const m = (a + b) / 2;
        const fa = f(a), fm = f(m), fb = f(b);
        return { k: 'c', c: { re: rec(a, b, 1e-8, simpson(a, b, fa, fm, fb), fa, fm, fb, 11), im: 0 } };
      }
      if (fn === 'd/dx(') {
        if (args.length < 2) throw 'Argument ERROR';
        const at = asR(evalAny(args[1], localVars));
        const f = (x: number) => asR(evalAny(args[0], { ...localVars, x }));
        const h = Math.max(1e-5, Math.abs(at) * 1e-5);
        const d = (-f(at + 2 * h) + 8 * f(at + h) - 8 * f(at - h) + f(at - 2 * h)) / (12 * h);
        return { k: 'c', c: { re: d, im: 0 } };
      }
      if (fn === 'Σ(' || fn === 'Π(') {
        if (args.length < 3) throw 'Argument ERROR';
        const lo = Math.round(asR(evalAny(args[1], localVars)));
        const hi = Math.round(asR(evalAny(args[2], localVars)));
        if (hi - lo > 5000) ME();
        let acc = fn === 'Σ(' ? 0 : 1;
        for (let k = lo; k <= hi; k++) {
          const v = asR(evalAny(args[0], { ...localVars, x: k }));
          acc = fn === 'Σ(' ? acc + v : acc * v;
        }
        return { k: 'c', c: { re: acc, im: 0 } };
      }
      if (fn === 'GCD(' || fn === 'LCM(' || fn === 'RanInt(') {
        if (args.length < 2) throw 'Argument ERROR';
        const a = asR(evalAny(args[0], localVars));
        const b = asR(evalAny(args[1], localVars));
        if (fn === 'GCD(') return { k: 'c', c: { re: gcdInt(a, b), im: 0 } };
        if (fn === 'LCM(') return { k: 'c', c: { re: lcmInt(a, b), im: 0 } };
        const lo = Math.ceil(a), hi = Math.floor(b);
        if (lo > hi) ME();
        return { k: 'c', c: { re: Math.floor(Math.random() * (hi - lo + 1)) + lo, im: 0 } };
      }
      if (fn === 'Angle(') {
        if (args.length < 2) throw 'Argument ERROR';
        const a = evalAny(args[0], localVars);
        const b = evalAny(args[1], localVars);
        if (a.k !== 'v' || b.k !== 'v' || a.v.length !== b.v.length) throw 'Dimension ERROR';
        const dot = a.v.reduce((s, v, i) => s + v * b.v[i], 0);
        const ma = Math.hypot(...a.v), mb = Math.hypot(...b.v);
        if (!ma || !mb) ME();
        return { k: 'c', c: { re: deg(Math.acos(Math.max(-1, Math.min(1, dot / (ma * mb))))), im: 0 } };
      }
      if (fn === 'Pol(' || fn === 'Rec(') {
        if (args.length < 2) throw 'Argument ERROR';
        const x1 = asR(evalAny(args[0], localVars));
        const x2 = asR(evalAny(args[1], localVars));
        if (fn === 'Pol(') return { k: 'c', c: { re: Math.hypot(x1, x2), im: 0 } };
        return { k: 'c', c: { re: x1 * Math.cos(rad(x2)), im: 0 } };
      }

      if (args.length < 1 || !args[0].length) SE();
      const val = evalAny(args[0], localVars);

      if (fn === 'Det(') { if (val.k !== 'm') throw 'Syntax ERROR'; return { k: 'c', c: { re: matDet(val.m), im: 0 } }; }
      if (fn === 'Trn(') { if (val.k !== 'm') throw 'Syntax ERROR'; return { k: 'm', m: val.m[0].map((_, j) => val.m.map((r) => r[j])) }; }
      if (fn === 'UnitV(') {
        if (val.k !== 'v') throw 'Syntax ERROR';
        const m = Math.hypot(...val.v);
        if (!m) throw 'Math ERROR';
        return { k: 'v', v: val.v.map((x) => x / m) };
      }
      if (fn === 'abs(') {
        if (val.k === 'v') return { k: 'c', c: { re: Math.hypot(...val.v), im: 0 } };
        const c = asC(val);
        return { k: 'c', c: { re: Math.hypot(c.re, c.im), im: 0 } };
      }

      const c = asC(val);
      if (fn === 'Arg(') { if (!c.re && !c.im) ME(); return { k: 'c', c: { re: deg(Math.atan2(c.im, c.re)), im: 0 } }; }
      if (fn === 'Conjg(') return { k: 'c', c: { re: c.re, im: -c.im } };
      if (fn === 'ReP(') return { k: 'c', c: { re: c.re, im: 0 } };
      if (fn === 'ImP(') return { k: 'c', c: { re: c.im, im: 0 } };
      if (fn === 'Not(') return { k: 'c', c: { re: (~(Math.trunc(c.re) | 0)) | 0, im: 0 } };
      if (fn === 'Neg(') return { k: 'c', c: { re: (-(Math.trunc(c.re) | 0)) | 0, im: 0 } };

      if (fn === '√(') {
        if (c.im === 0 && c.re >= 0) return { k: 'c', c: { re: Math.sqrt(c.re), im: 0 } };
        if (S.app === 'cplx') return { k: 'c', c: cPow(c, { re: 0.5, im: 0 }) };
        ME();
      }
      if (fn === '∛(') {
        if (c.im === 0) return { k: 'c', c: { re: Math.cbrt(c.re), im: 0 } };
        return { k: 'c', c: cPow(c, { re: 1 / 3, im: 0 }) };
      }
      if (fn === 'sin(') {
        if (Math.abs(c.im) < 1e-12) return { k: 'c', c: { re: cl(Math.sin(rad(c.re))), im: 0 } };
        const x = rad(c.re), y = rad(c.im);
        return { k: 'c', c: { re: cl(Math.sin(x) * Math.cosh(y)), im: cl(Math.cos(x) * Math.sinh(y)) } };
      }
      if (fn === 'cos(') {
        if (Math.abs(c.im) < 1e-12) return { k: 'c', c: { re: cl(Math.cos(rad(c.re))), im: 0 } };
        const x = rad(c.re), y = rad(c.im);
        return { k: 'c', c: { re: cl(Math.cos(x) * Math.cosh(y)), im: cl(-Math.sin(x) * Math.sinh(y)) } };
      }
      if (fn === 'tan(') {
        const q = S.mode === 'D' ? 180 : S.mode === 'G' ? 200 : Math.PI;
        if (Math.abs(c.im) < 1e-12) {
          if (Math.abs((((c.re % q) + q) % q) - q / 2) < 1e-12) ME();
          return { k: 'c', c: { re: cl(Math.tan(rad(c.re))), im: 0 } };
        }
        const x = rad(c.re), y = rad(c.im);
        return {
          k: 'c',
          c: cDiv(
            { re: Math.sin(x) * Math.cosh(y), im: Math.cos(x) * Math.sinh(y) },
            { re: Math.cos(x) * Math.cosh(y), im: -Math.sin(x) * Math.sinh(y) }
          ),
        };
      }
      if (fn === 'ln(') {
        if (c.im === 0 && c.re > 0) return { k: 'c', c: { re: Math.log(c.re), im: 0 } };
        if (S.app === 'cplx') return { k: 'c', c: cLn(c) };
        ME();
      }
      if (fn === 'log(') {
        if (c.im === 0 && c.re > 0) return { k: 'c', c: { re: Math.log10(c.re), im: 0 } };
        if (S.app === 'cplx') {
          const l = cLn(c);
          return { k: 'c', c: { re: l.re / Math.LN10, im: l.im / Math.LN10 } };
        }
        ME();
      }

      const x = asR(val);
      if (fn === 'asin(') { if (Math.abs(x) > 1) ME(); return { k: 'c', c: { re: deg(Math.asin(x)), im: 0 } }; }
      if (fn === 'acos(') { if (Math.abs(x) > 1) ME(); return { k: 'c', c: { re: deg(Math.acos(x)), im: 0 } }; }
      if (fn === 'atan(') return { k: 'c', c: { re: deg(Math.atan(x)), im: 0 } };
      if (fn === 'sinh(') return { k: 'c', c: { re: Math.sinh(x), im: 0 } };
      if (fn === 'cosh(') return { k: 'c', c: { re: Math.cosh(x), im: 0 } };
      if (fn === 'tanh(') return { k: 'c', c: { re: Math.tanh(x), im: 0 } };
      if (fn === 'asinh(') return { k: 'c', c: { re: Math.asinh(x), im: 0 } };
      if (fn === 'acosh(') { if (x < 1) ME(); return { k: 'c', c: { re: Math.acosh(x), im: 0 } }; }
      if (fn === 'atanh(') { if (x <= -1 || x >= 1) ME(); return { k: 'c', c: { re: Math.atanh(x), im: 0 } }; }
      if (fn === 'Int(') return { k: 'c', c: { re: Math.trunc(x), im: 0 } };
      if (fn === 'Intg(') return { k: 'c', c: { re: Math.floor(x), im: 0 } };
      if (fn === 'Rnd(') {
        const d = S.nf.t === 'F' ? S.nf.n : 10;
        const f = Math.pow(10, d);
        return { k: 'c', c: { re: Math.round(x * f) / f, im: 0 } };
      }
      return SE();
    };

    function atom(): RVal {
      const t = pk();
      if (t === undefined) SE();
      if (D(t)) {
        let s = '';
        while (D(pk())) s += T[p++];
        if (s === '.' || s.split('.').length > 2) SE();
        if (BN && [...s].some((c) => parseInt(c, 16) >= RX)) SE();
        let v = BN ? parseInt(s, RX) : parseFloat(s);
        // DMS degrees chain like 12°30°45°
        if (pk() === '°') {
          p++;
          let degVal = v;
          const readDmsPart = (): number | null => {
            if (!D(pk())) return null;
            let ds = '';
            while (D(pk())) ds += T[p++];
            if (pk() === '°' || pk() === '′' || pk() === '″') p++;
            return parseFloat(ds);
          };
          const m = readDmsPart();
          if (m !== null) {
            degVal += m / 60;
            const sec = readDmsPart();
            if (sec !== null) degVal += sec / 3600;
          }
          return { k: 'c', c: { re: degVal, im: 0 } };
        }
        if (pk() === 'ᴇ') {
          p++;
          let sg = 1;
          if (pk() === '−') { p++; sg = -1; }
          let e = '';
          while (D(pk()) && pk() !== '.') e += T[p++];
          if (!e) SE();
          v *= Math.pow(10, sg * parseInt(e, 10));
        }
        return { k: 'c', c: { re: v, im: 0 } };
      }
      if (t === '(') {
        p++;
        const v = ex();
        if (pk() === ')') p++;
        return v;
      }
      if (t === '⟨SQ:' || t === '⟨CR:') {
        p++;
        const closeTok = STRUCT_CLOSE[t];
        const val = ex();
        if (pk() === closeTok) p++;
        else SE();
        const c = asC(val);
        if (t === '⟨SQ:') {
          if (c.im === 0 && c.re >= 0) return { k: 'c', c: { re: Math.sqrt(c.re), im: 0 } };
          if (S.app === 'cplx') return { k: 'c', c: cPow(c, { re: 0.5, im: 0 }) };
          ME();
        } else {
          if (c.im === 0) return { k: 'c', c: { re: Math.cbrt(c.re), im: 0 } };
          return { k: 'c', c: cPow(c, { re: 1 / 3, im: 0 }) };
        }
      }
      if (t === '⟨FR:') {
        p++;
        const num = ex();
        if (pk() !== '¦') SE();
        p++;
        const den = ex();
        if (pk() === '⟩FR') p++;
        else SE();
        if (num.k === 'm' && den.k === 'c') {
          const s = asR(den);
          if (s === 0) ME();
          return { k: 'm', m: num.m.map((rw) => rw.map((x) => x / s)) };
        }
        if (num.k === 'v' && den.k === 'c') {
          const s = asR(den);
          if (s === 0) ME();
          return { k: 'v', v: num.v.map((x) => x / s) };
        }
        return { k: 'c', c: cDiv(asC(num), asC(den)) };
      }
      if (t === '⟨MX:') {
        p++;
        const w = asR(ex());
        if (pk() !== '¦') SE();
        p++;
        const n = asR(ex());
        if (pk() !== '¦') SE();
        p++;
        const d = asR(ex());
        if (pk() === '⟩MX') p++;
        else SE();
        if (d === 0) ME();
        return { k: 'c', c: { re: (w < 0 ? -1 : 1) * (Math.abs(w) + Math.abs(n / d)), im: 0 } };
      }
      if (t === '⟨NR:') {
        p++;
        const idx = asR(ex());
        if (pk() !== '¦') SE();
        p++;
        const radVal = ex();
        if (pk() === '⟩NR') p++;
        else SE();
        if (idx === 0) ME();
        const c = asC(radVal);
        if (c.im === 0) {
          if (c.re >= 0) return { k: 'c', c: { re: Math.pow(c.re, 1 / idx), im: 0 } };
          if (Number.isInteger(idx) && Math.abs(idx % 2) === 1) {
            return { k: 'c', c: { re: -Math.pow(-c.re, 1 / idx), im: 0 } };
          }
          if (S.app === 'cplx') return { k: 'c', c: cPow(c, { re: 1 / idx, im: 0 }) };
          ME();
        }
        return { k: 'c', c: cPow(c, { re: 1 / idx, im: 0 }) };
      }
      if (t === '⟨LG:') {
        p++;
        const baseVal = asC(ex());
        if (pk() !== '¦') SE();
        p++;
        const argVal = asC(ex());
        if (pk() === '⟩LG') p++;
        else SE();
        if (baseVal.im === 0 && argVal.im === 0 && baseVal.re > 0 && baseVal.re !== 1 && argVal.re > 0) {
          return { k: 'c', c: { re: Math.log(argVal.re) / Math.log(baseVal.re), im: 0 } };
        }
        if (S.app === 'cplx') {
          if ((baseVal.re === 1 && baseVal.im === 0) || (baseVal.re === 0 && baseVal.im === 0)) ME();
          return { k: 'c', c: cDiv(cLn(argVal), cLn(baseVal)) };
        }
        ME();
      }
      if (t === '⟨AB:') {
        p++;
        const val = ex();
        if (pk() === '⟩AB') p++;
        else SE();
        if (val.k === 'v') return { k: 'c', c: { re: Math.hypot(...val.v), im: 0 } };
        const c = asC(val);
        return { k: 'c', c: { re: Math.hypot(c.re, c.im), im: 0 } };
      }
      if (t === '⟨IN:' || t === '⟨DX:' || t === '⟨SM:' || t === '⟨PR:') {
        const openIdx = p++;
        const { bars, closeIdx } = findMatchingClose(T, openIdx);
        if ((t === '⟨DX:' && bars.length < 1) || (t !== '⟨DX:' && bars.length < 2)) throw 'Argument ERROR';
        const exprToks = T.slice(openIdx + 1, bars[0]);
        const arg1Toks = T.slice(bars[0] + 1, bars[1] ?? closeIdx);
        const arg2Toks = bars.length >= 2 ? T.slice(bars[1] + 1, closeIdx) : [];
        p = closeIdx + 1;
        const fnMap: Record<string, string> = { '⟨IN:': '∫(', '⟨DX:': 'd/dx(', '⟨SM:': 'Σ(', '⟨PR:': 'Π(' };
        const args = bars.length >= 2 ? [exprToks, arg1Toks, arg2Toks] : [exprToks, arg1Toks];
        return evalFn(fnMap[t], args);
      }
      if (singleArgFns.has(t!) || multiArgFns.has(t!)) {
        const fn = T[p++];
        const closeIdx = findMatchingParen(p);
        const inner = T.slice(p, closeIdx);
        p = closeIdx < T.length ? closeIdx + 1 : T.length;
        return evalFn(fn, splitArgs(inner));
      }
      p++;
      if (t === 'π') return { k: 'c', c: { re: Math.PI, im: 0 } };
      if (t === 'ℯ') return { k: 'c', c: { re: Math.E, im: 0 } };
      if (t === 'i') {
        if (S.app !== 'cplx') SE();
        return { k: 'c', c: { re: 0, im: 1 } };
      }
      if (t === 'Ans') return { k: 'c', c: S.app === 'cplx' ? S.ansCpx : { re: S.ans, im: 0 } };
      if (t === 'Ran#') return { k: 'c', c: { re: Math.floor(Math.random() * 1000) / 1000, im: 0 } };
      if (t!.startsWith('CONST:')) {
        const parts = t!.split(':');
        return { k: 'c', c: { re: parseFloat(parts[parts.length - 1]), im: 0 } };
      }
      if (t === 'MatA' || t === 'MatB' || t === 'MatC') return { k: 'm', m: S.mats[t] };
      if (t === 'MatAns') return { k: 'm', m: S.matAns };
      if (t === 'VctA' || t === 'VctB' || t === 'VctC') return { k: 'v', v: S.vecs[t] };
      if (t === 'VctAns') return { k: 'v', v: S.vctAns };
      if (/^[A-FMxy]$/.test(t!)) {
        if (localVars && localVars[t!] !== undefined) return { k: 'c', c: { re: localVars[t!], im: 0 } };
        if (S.app === 'cplx' && S.vc[t!]) return { k: 'c', c: S.vc[t!] };
        return { k: 'c', c: { re: S.v[t!] || 0, im: 0 } };
      }
      return SE();
    }

    function post(): RVal {
      let val = atom();
      for (;;) {
        const t = pk();
        if (val.k === 'm') {
          if (t === '⁻¹') { p++; val = { k: 'm', m: matInv(val.m) }; continue; }
          if (t === '²') { p++; val = { k: 'm', m: matMul(val.m, val.m) }; continue; }
          if (t === '⟨PW:') {
            p++;
            const n = asR(ex());
            if (pk() === '⟩PW') p++;
            else SE();
            if (n === -1) val = { k: 'm', m: matInv(val.m) };
            else if (Number.isInteger(n) && n >= 1 && n <= 10) {
              let r = val.m;
              for (let k = 1; k < n; k++) r = matMul(r, val.m);
              val = { k: 'm', m: r };
            } else ME();
            continue;
          }
          break;
        }
        if (t === '⟨PW:') {
          p++;
          const e = ex();
          if (pk() === '⟩PW') p++;
          else SE();
          val = { k: 'c', c: cPow(asC(val), asC(e)) };
        }
        else if (t === '!') { p++; val = { k: 'c', c: { re: fact(asR(val)), im: 0 } }; }
        else if (t === '²') { p++; const c = asC(val); val = { k: 'c', c: cMul(c, c) }; }
        else if (t === '³') { p++; const c = asC(val); val = { k: 'c', c: cMul(cMul(c, c), c) }; }
        else if (t === '⁻¹') { p++; val = { k: 'c', c: cDiv({ re: 1, im: 0 }, asC(val)) }; }
        else if (t === '%') { p++; val = { k: 'c', c: cDiv(asC(val), { re: 100, im: 0 }) }; }
        else if (t === '°') { p++; val = { k: 'c', c: { re: deg((asR(val) * Math.PI) / 180), im: 0 } }; }
        else if (t === 'ʳ') { p++; val = { k: 'c', c: { re: deg(asR(val)), im: 0 } }; }
        else if (t === 'ᵍ') { p++; val = { k: 'c', c: { re: deg((asR(val) * Math.PI) / 200), im: 0 } }; }
        else if (t && t.startsWith('CONV:')) {
          p++;
          const code = t.slice(5);
          const conv = UNIT_CONVERSIONS.find((u) => u.code === code);
          if (!conv) throw 'Syntax ERROR';
          val = { k: 'c', c: { re: conv.convert(asR(val)), im: 0 } };
        } else break;
      }
      return val;
    }

    function expo(): RVal {
      if (pk() === '−') { p++; const v = expo(); return { k: 'c', c: { re: -asC(v).re, im: -asC(v).im } }; }
      if (pk() === '+') { p++; return expo(); }
      const b = post();
      if (pk() === '^') { p++; return { k: 'c', c: cPow(asC(b), asC(expo())) }; }
      return b;
    }

    function pw(): RVal {
      let v = post();
      for (;;) {
        const t = pk();
        if (t === '^') {
          p++;
          const e = expo();
          if (v.k === 'm') {
            const n = asR(e);
            if (n === -1) v = { k: 'm', m: matInv(v.m) };
            else if (Number.isInteger(n) && n >= 1 && n <= 10) {
              let r = v.m;
              for (let k = 1; k < n; k++) r = matMul(r, v.m);
              v = { k: 'm', m: r };
            } else ME();
          } else {
            v = { k: 'c', c: cPow(asC(v), asC(e)) };
          }
        } else if (t === 'ˣ√') {
          p++;
          const idx = asR(v);
          const r = asR(post());
          if (r < 0 && Number.isInteger(idx) && idx % 2) v = { k: 'c', c: { re: -Math.pow(-r, 1 / idx), im: 0 } };
          else v = { k: 'c', c: { re: Math.pow(r, 1 / idx), im: 0 } };
        } else if (t === 'P') {
          p++;
          v = { k: 'c', c: { re: perm(asR(v), asR(post())), im: 0 } };
        } else if (t === 'C') {
          p++;
          v = { k: 'c', c: { re: comb(asR(v), asR(post())), im: 0 } };
        } else if (t === '∠') {
          p++;
          if (S.app !== 'cplx') SE();
          const r = asR(v);
          const th = rad(asR(post()));
          v = { k: 'c', c: { re: r * Math.cos(th), im: r * Math.sin(th) } };
        } else break;
      }
      return v;
    }

    function un(): RVal {
      if (pk() === '−') {
        p++;
        const v = un();
        if (v.k === 'm') return { k: 'm', m: v.m.map((r) => r.map((x) => -x)) };
        if (v.k === 'v') return { k: 'v', v: v.v.map((x) => -x) };
        return { k: 'c', c: { re: -v.c.re, im: -v.c.im } };
      }
      if (pk() === '+') { p++; return un(); }
      return pw();
    }

    function frac(): RVal {
      let v = un();
      while (pk() === '⁄') {
        p++;
        const r = un();
        if (v.k === 'm' && r.k === 'c') {
          const s = asR(r);
          if (s === 0) ME();
          v = { k: 'm', m: v.m.map((rw) => rw.map((x) => x / s)) };
        } else if (v.k === 'v' && r.k === 'c') {
          const s = asR(r);
          if (s === 0) ME();
          v = { k: 'v', v: v.v.map((x) => x / s) };
        } else {
          v = { k: 'c', c: cDiv(asC(v), asC(r)) };
        }
      }
      return v;
    }

    function term(): RVal {
      let v = frac();
      for (;;) {
        const t = pk();
        if (t === '×') {
          p++;
          const r = frac();
          if (v.k === 'm' && r.k === 'm') v = { k: 'm', m: matMul(v.m, r.m) };
          else if (v.k === 'm' && r.k === 'c') { const s = asR(r); v = { k: 'm', m: v.m.map((rw) => rw.map((x) => x * s)) }; }
          else if (v.k === 'c' && r.k === 'm') { const s = asR(v); v = { k: 'm', m: r.m.map((rw) => rw.map((x) => x * s)) }; }
          else if (v.k === 'v' && r.k === 'c') { const s = asR(r); v = { k: 'v', v: v.v.map((x) => x * s) }; }
          else if (v.k === 'c' && r.k === 'v') { const s = asR(v); v = { k: 'v', v: r.v.map((x) => x * s) }; }
          else v = { k: 'c', c: cMul(asC(v), asC(r)) };
        } else if (t === '·') {
          p++;
          const r = frac();
          if (v.k !== 'v' || r.k !== 'v' || v.v.length !== r.v.length) throw 'Dimension ERROR';
          v = { k: 'c', c: { re: v.v.reduce((s, x, i) => s + x * r.v[i], 0), im: 0 } };
        } else if (t === '×v') {
          p++;
          const r = frac();
          if (v.k !== 'v' || r.k !== 'v') throw 'Dimension ERROR';
          const a = v.v.length === 2 ? [...v.v, 0] : v.v;
          const b = r.v.length === 2 ? [...r.v, 0] : r.v;
          v = { k: 'v', v: [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]] };
        } else if (t === '÷') {
          p++;
          const r = frac();
          if (v.k === 'm' && r.k === 'c') {
            const s = asR(r);
            if (s === 0) ME();
            v = { k: 'm', m: v.m.map((rw) => rw.map((x) => x / s)) };
          } else if (v.k === 'm' && r.k === 'm') {
            v = { k: 'm', m: matMul(v.m, matInv(r.m)) };
          } else if (v.k === 'v' && r.k === 'c') {
            const s = asR(r);
            if (s === 0) ME();
            v = { k: 'v', v: v.v.map((x) => x / s) };
          } else {
            v = { k: 'c', c: cDiv(asC(v), asC(r)) };
          }
        } else if (isAtom(t)) {
          const r = frac();
          if (v.k === 'c' && r.k === 'm') { const s = asR(v); v = { k: 'm', m: r.m.map((rw) => rw.map((x) => x * s)) }; }
          else if (v.k === 'c' && r.k === 'v') { const s = asR(v); v = { k: 'v', v: r.v.map((x) => x * s) }; }
          else v = { k: 'c', c: cMul(asC(v), asC(r)) };
        } else break;
      }
      return v;
    }

    function addSub(): RVal {
      let v = term();
      while (pk() === '+' || pk() === '−' || pk() === '■') {
        const o = T[p++];
        if (o === '■') {
          const fracPart = term();
          const whole = asR(v);
          const f = asR(fracPart);
          v = { k: 'c', c: { re: (whole < 0 ? -1 : 1) * (Math.abs(whole) + Math.abs(f)), im: 0 } };
          continue;
        }
        const r = term();
        if (v.k === 'm' && r.k === 'm') {
          if (v.m.length !== r.m.length || v.m[0].length !== r.m[0].length) throw 'Dimension ERROR';
          v = { k: 'm', m: v.m.map((rw, ri) => rw.map((x, ci) => (o === '+' ? x + r.m[ri][ci] : x - r.m[ri][ci]))) };
        } else if (v.k === 'v' && r.k === 'v') {
          if (v.v.length !== r.v.length) throw 'Dimension ERROR';
          v = { k: 'v', v: v.v.map((x, i) => (o === '+' ? x + r.v[i] : x - r.v[i])) };
        } else {
          v = { k: 'c', c: o === '+' ? cAdd(asC(v), asC(r)) : cSub(asC(v), asC(r)) };
        }
      }
      return v;
    }

    function bitAnd(): RVal {
      let v = addSub();
      while (pk() === 'and') {
        p++;
        const a = Math.trunc(asR(v)) | 0;
        const b = Math.trunc(asR(addSub())) | 0;
        v = { k: 'c', c: { re: (a & b) | 0, im: 0 } };
      }
      return v;
    }

    function ex(): RVal {
      let v = bitAnd();
      while (pk() === 'or' || pk() === 'xor' || pk() === 'xnor') {
        const o = T[p++];
        const a = Math.trunc(asR(v)) | 0;
        const b = Math.trunc(asR(bitAnd())) | 0;
        const res = o === 'or' ? a | b : o === 'xor' ? a ^ b : ~(a ^ b);
        v = { k: 'c', c: { re: res | 0, im: 0 } };
      }
      return v;
    }

    const res = ex();
    if (p < T.length) SE();
    if (res.k === 'c') {
      if (!isFinite(res.c.re) || !isFinite(res.c.im)) ME();
      return {
        k: 'c',
        c: {
          re: res.c.re === 0 ? 0 : parseFloat(res.c.re.toPrecision(14)),
          im: Math.abs(res.c.im) < 1e-13 && res.c.im !== 0 && Math.abs(res.c.re) > 1e-5 ? 0 : res.c.im === 0 ? 0 : parseFloat(res.c.im.toPrecision(14)),
        },
      };
    }
    return res;
  };

  const calc = (T: string[], localVars?: Record<string, number>): number => {
    const r = evalAny(T, localVars);
    return asR(r);
  };

  const fmt = (v: number): string => {
    if (S.app === 'base') {
      const n = Math.trunc(v);
      return (S.base !== 'D' && n < 0 ? n >>> 0 : n)
        .toString({ D: 10, H: 16, B: 2, O: 8 }[S.base])
        .toUpperCase();
    }
    const applyMark = (s: string) => (S.decComma ? s.replace(/\./g, ',') : s);
    if (S.nf.t === 'F') return applyMark((v < 0 ? '−' : '') + Math.abs(v).toFixed(S.nf.n));
    if (S.nf.t === 'S') {
      const [m, e] = Math.abs(v).toExponential(S.nf.n ? S.nf.n - 1 : 9).split('e');
      return applyMark((v < 0 ? '−' : '') + m + '×10^' + parseInt(e, 10));
    }
    if (v === 0) return '0';
    const r = Number(v.toPrecision(10));
    const A = Math.abs(r);
    const sg = r < 0 ? '−' : '';
    const lowThresh = S.normVar === 1 ? 1e-2 : 1e-9;
    if (A >= 1e10 || A < lowThresh) {
      const [m, e] = A.toExponential(9).split('e');
      return applyMark(sg + Number(m) + '×10^' + parseInt(e, 10));
    }
    return applyMark(sg + A.toLocaleString('en-US', { useGrouping: false, maximumFractionDigits: 20 }));
  };

  const Tfmt = (v: number): string => fmt(v);
  const Efmt = (v: number): string => {
    if (S.fm && S.nf.t === 'N') {
      const ex = tryExactRepresentation(v, Boolean(S.mx));
      if (ex) return ex.texLike;
    }
    return Tfmt(v);
  };

  const form = (t: string, n: string[], fn: (fields: string[][]) => string[]) => {
    S.fo = { t, n, v: n.map(() => []), i: 0, fn, out: null, p: 0 };
    S.t = [];
    S.c = 0;
    S.res = null;
    S.done = 0;
  };

  const exitApp = () => {
    S.app = 'calc';
    S.fo = null;
    S.t = [];
    S.c = 0;
    S.res = null;
    S.done = 0;
    S.dat = [];
    S.statStep = 'x';
  };

  const pickSet = (i: number) => {
    if (i === 0) {
      S.ls = {
        t: 'ANGLE',
        items: ['Degree', 'Radian', 'Gradian'],
        i: 0,
        fn: (j) => { S.mode = 'DRG'[j]; S.ls = null; },
      };
    } else if (i === 1) {
      S.ls = {
        t: 'FORMAT',
        items: ['Fix', 'Sci', 'Norm 1 (10⁻²)', 'Norm 2 (10⁻⁹)'],
        i: 0,
        fn: (j) => {
          S.ls = null;
          if (j === 2 || j === 3) {
            S.nf = { t: 'N', n: 0 };
            S.normVar = j === 2 ? 1 : 2;
          } else {
            form(['Fix', 'Sci'][j] + ' 0~9', ['n'], (f) => {
              S.nf = {
                t: ('FS'[j] as 'F' | 'S'),
                n: Math.max(0, Math.min(9, Math.round(calc(f[0])))),
              };
              S.fo = null;
              S.t = [];
              S.c = 0;
              return [];
            });
          }
        },
      };
    } else if (i === 2) {
      S.ls = {
        t: 'FRACTION',
        items: ['ab/c', 'd/c'],
        i: 0,
        fn: (j) => { S.mx = j === 0 ? 1 : 0; S.ls = null; },
      };
    } else if (i === 3) {
      S.ls = {
        t: 'COMPLEX',
        items: ['a+bi', 'r∠θ'],
        i: 0,
        fn: (j) => { S.cmplxFmt = j === 0 ? 'RECT' : 'POLAR'; S.ls = null; },
      };
    } else if (i === 4) {
      S.ls = {
        t: 'STAT FREQ',
        items: ['On', 'Off'],
        i: S.statFreq ? 0 : 1,
        fn: (j) => { S.statFreq = j === 0; S.ls = null; },
      };
    } else {
      S.ls = {
        t: 'DECIMAL MARK',
        items: ['Dot (.)', 'Comma (,)'],
        i: S.decComma ? 1 : 0,
        fn: (j) => { S.decComma = j === 1; S.ls = null; },
      };
    }
  };

  const gauss = (f: string[][], n: number): string[] => {
    const M: number[][] = [];
    for (let i = 0; i < n; i++) M.push(f.slice(i * (n + 1), (i + 1) * (n + 1)).map((x) => calc(x)));
    for (let c = 0; c < n; c++) {
      let p = c;
      for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
      if (Math.abs(M[p][c]) < 1e-12) throw 'Math ERROR';
      [M[c], M[p]] = [M[p], M[c]];
      for (let r = 0; r < n; r++) {
        if (r !== c) {
          const q = M[r][c] / M[c][c];
          for (let k = c; k <= n; k++) M[r][k] -= q * M[c][k];
        }
      }
    }
    return M.map((r, i) => 'xyz'[i] + '=' + Efmt(r[n] / r[i]));
  };

  const startEqn = (j: number) => {
    S.ls = null;
    S.app = 'eqn';
    if (j === 0 || j === 1) {
      const deg = j === 0 ? 2 : 3;
      const names = deg === 2 ? ['a', 'b', 'c'] : ['a', 'b', 'c', 'd'];
      form(deg === 2 ? 'aX²+bX+c' : 'aX³+bX²+cX+d', names, (f) => {
        const coeffs = f.map((x) => calc(x));
        if (!coeffs[0]) throw 'Math ERROR';
        const roots = solvePolynomial(coeffs);
        return roots.map((r, idx) => {
          const imAbs = Math.abs(r.im);
          if (imAbs < 1e-9) return `x${idx + 1}=${Efmt(r.re)}`;
          return `x${idx + 1}=${Efmt(r.re)}${r.im >= 0 ? '+' : '−'}${Efmt(imAbs)}i`;
        });
      });
      return;
    }
    const n = j;
    const nm: string[] = [];
    for (let r = 1; r <= n; r++) {
      for (const k of 'abcd'.slice(0, n + 1)) nm.push(k + r);
    }
    form(n + ' unknowns', nm, (f) => gauss(f, n));
  };

  const tableCalc = (f: string[][]): string[] => {
    const hasG = f[1].length > 0;
    const a = calc(f[2]);
    const b = calc(f[3]);
    const s = calc(f[4]);
    if (!(s > 0) || b < a) throw 'Math ERROR';
    const N = Math.min(44, Math.floor((b - a) / s + 1e-9));
    const o: string[] = [];
    for (let k = 0; k <= N; k++) {
      const x = a + k * s;
      let y1: string;
      try { y1 = Tfmt(calc(f[0], { x })); } catch { y1 = 'ERR'; }
      if (hasG) {
        let y2: string;
        try { y2 = Tfmt(calc(f[1], { x })); } catch { y2 = 'ERR'; }
        o.push(`TBL:${Tfmt(x)}|${y1}|${y2}`);
      } else {
        o.push(`TBL:${Tfmt(x)}|${y1}`);
      }
    }
    return o;
  };

  const startMatrixEdit = (name: 'MatA' | 'MatB' | 'MatC', rows: number, cols: number) => {
    const nm: string[] = [];
    for (let r = 1; r <= rows; r++) for (let c = 1; c <= cols; c++) nm.push(`${name}[${r},${c}]`);
    form(name, nm, (f) => {
      const vals = f.map((x) => (x.length ? calc(x) : 0));
      const m: number[][] = [];
      for (let r = 0; r < rows; r++) m.push(vals.slice(r * cols, (r + 1) * cols));
      S.mats[name] = m;
      S.fo = null;
      S.t = [];
      S.c = 0;
      return [];
    });
    const cur = S.mats[name];
    if (cur.length === rows && cur[0]?.length === cols) {
      S.fo!.v = cur.flat().map((v) => String(v).split(''));
    }
    S.t = S.fo!.v[0].slice();
    S.c = S.t.length;
  };

  const openMatrixSizePicker = (name: 'MatA' | 'MatB' | 'MatC') => {
    const sizes: Array<[number, number]> = [
      [2, 2], [2, 3], [3, 2], [3, 3], [1, 2], [1, 3], [2, 1], [3, 1], [1, 1],
    ];
    S.ls = {
      t: `${name} SIZE`,
      items: sizes.map(([r, c]) => `${r}×${c}`),
      i: 0,
      fn: (k) => {
        S.ls = null;
        startMatrixEdit(name, sizes[k][0], sizes[k][1]);
      },
    };
  };

  const startVectorEdit = (name: 'VctA' | 'VctB' | 'VctC', dim: number) => {
    const nm = Array.from({ length: dim }, (_, i) => `${name}[${i + 1}]`);
    form(name, nm, (f) => {
      S.vecs[name] = f.map((x) => (x.length ? calc(x) : 0));
      S.fo = null;
      S.t = [];
      S.c = 0;
      return [];
    });
    if (S.vecs[name].length === dim) {
      S.fo!.v = S.vecs[name].map((v) => String(v).split(''));
    }
    S.t = S.fo!.v[0].slice();
    S.c = S.t.length;
  };

  const startDist = (d: DistType) => {
    const specs: Record<DistType, { title: string; fields: string[] }> = {
      NORMAL_PD: { title: 'Normal PD', fields: ['x', 'σ', 'μ'] },
      NORMAL_CD: { title: 'Normal CD', fields: ['Low', 'Up', 'σ', 'μ'] },
      INV_NORMAL: { title: 'Inv Normal', fields: ['Area', 'σ', 'μ'] },
      BINOMIAL_PD: { title: 'Binom PD', fields: ['x', 'N', 'p'] },
      BINOMIAL_CD: { title: 'Binom CD', fields: ['x', 'N', 'p'] },
      POISSON_PD: { title: 'Poisson PD', fields: ['x', 'λ'] },
      POISSON_CD: { title: 'Poisson CD', fields: ['x', 'λ'] },
    };
    const sp = specs[d];
    form(sp.title, sp.fields, (f) => ['p=' + Tfmt(computeDistribution(d, f.map((x) => calc(x))))]);
  };

  const openStatTypeMenu = () => {
    const types: StatType[] = ['1-VAR', 'LINEAR', 'QUAD', 'LOG', 'E_EXP', 'AB_EXP', 'POWER', 'INV'];
    S.ls = {
      t: 'STATISTICS',
      items: [
        '1-Variable',
        'y = a+bx',
        'y = a+bx+cx²',
        'y = a+b·ln(x)',
        'y = a·e^(bx)',
        'y = a·b^x',
        'y = a·x^b',
        'y = a+b/x',
      ],
      i: 0,
      fn: (j) => {
        S.ls = null;
        S.statType = types[j];
        S.statReg = j > 0;
        S.dat = [];
        S.statStep = 'x';
        S.t = [];
        S.c = 0;
      },
    };
  };

  const pickApp = (i: number) => {
    const a = ['calc', 'cplx', 'base', 'mat', 'vec', 'stat', 'dist', 'sheet', 'table', 'eqn', 'ineq', 'ratio'][i];
    exitApp();
    S.ls = null;
    if (a === 'eqn') {
      S.ls = {
        t: 'EQUATION',
        items: ['aX²+bX+c=0', 'aX³+bX²+cX+d=0', 'a₁x+b₁y=c₁', 'a₁x+b₁y+c₁z=d₁'],
        i: 0,
        fn: startEqn,
      };
      return;
    }
    if (a === 'ineq') {
      S.app = 'ineq';
      S.ls = {
        t: 'INEQUALITY',
        items: ['aX²+bX+c > 0', 'aX²+bX+c < 0', 'aX²+bX+c ≥ 0', 'aX²+bX+c ≤ 0'],
        i: 0,
        fn: (j) => {
          S.ls = null;
          const op = (['>', '<', '≥', '≤'] as const)[j];
          form(`aX²+bX+c ${op} 0`, ['a', 'b', 'c'], (f) => [solveInequality(f.map((x) => calc(x)), op)]);
        },
      };
      return;
    }
    if (a === 'mat') {
      S.app = 'mat';
      S.ls = {
        t: 'DEFINE MAT',
        items: ['MatA', 'MatB', 'MatC'],
        i: 0,
        fn: (j) => {
          const names: Array<'MatA' | 'MatB' | 'MatC'> = ['MatA', 'MatB', 'MatC'];
          openMatrixSizePicker(names[j]);
        },
      };
      return;
    }
    if (a === 'vec') {
      S.app = 'vec';
      S.ls = {
        t: 'DEFINE VCT',
        items: ['VctA (3D)', 'VctB (3D)', 'VctC (3D)', 'VctA (2D)', 'VctB (2D)', 'VctC (2D)'],
        i: 0,
        fn: (j) => {
          S.ls = null;
          const picks: Array<['VctA' | 'VctB' | 'VctC', number]> = [
            ['VctA', 3], ['VctB', 3], ['VctC', 3], ['VctA', 2], ['VctB', 2], ['VctC', 2],
          ];
          startVectorEdit(picks[j][0], picks[j][1]);
        },
      };
      return;
    }
    if (a === 'dist') {
      S.app = 'dist';
      const dists: DistType[] = ['NORMAL_PD', 'NORMAL_CD', 'INV_NORMAL', 'BINOMIAL_PD', 'BINOMIAL_CD', 'POISSON_PD', 'POISSON_CD'];
      S.ls = {
        t: 'DISTRIBUTION',
        items: ['Normal PD', 'Normal CD', 'Inverse Normal', 'Binomial PD', 'Binomial CD', 'Poisson PD', 'Poisson CD'],
        i: 0,
        fn: (j) => { S.ls = null; startDist(dists[j]); },
      };
      return;
    }
    if (a === 'sheet') {
      S.app = 'sheet';
      const cells: string[] = [];
      for (let r = 1; r <= 5; r++) for (const c of ['A', 'B', 'C']) cells.push(`${c}${r}`);
      form('Spreadsheet', cells, (f) => {
        for (let r = 0; r < 5; r++) {
          for (let c = 0; c < 3; c++) {
            S.sheet[r][c] = f[r * 3 + c].join('');
          }
        }
        const out: string[] = [];
        for (let r = 0; r < 5; r++) {
          for (let c = 0; c < 3; c++) {
            const val = evalSpreadsheetCell(S.sheet[r][c], S.sheet);
            if (val !== '') out.push(`${['A', 'B', 'C'][c]}${r + 1}=${val}`);
          }
        }
        return out.length ? out : ['Empty Sheet'];
      });
      S.fo!.v = S.sheet.flat().map((s) => s.split(''));
      S.t = S.fo!.v[0].slice();
      S.c = S.t.length;
      return;
    }
    if (a === 'stat') {
      S.app = 'stat';
      openStatTypeMenu();
      return;
    }

    S.app = a;
    S.base = 'D';
    if (a === 'table') form('Table', ['f(x)=', 'g(x)=', 'Start', 'End', 'Step'], tableCalc);
    else if (a === 'ratio') {
      S.ls = {
        t: 'RATIO',
        items: ['A:B = X:D', 'A:B = C:X'],
        i: 0,
        fn: (j) => {
          S.ls = null;
          if (j === 0) {
            form('A:B=X:D', ['A', 'B', 'D'], (f) => {
              const [A, B, D] = f.map((x) => calc(x));
              if (!B) throw 'Math ERROR';
              return ['X=' + Tfmt((A * D) / B)];
            });
          } else {
            form('A:B=C:X', ['A', 'B', 'C'], (f) => {
              const [A, B, C] = f.map((x) => calc(x));
              if (!A) throw 'Math ERROR';
              return ['X=' + Tfmt((B * C) / A)];
            });
          }
        },
      };
    }
  };

  const openList = (t: string, items: string[]) => {
    S.ls = { t, items, i: 0, code: '', fn: t === 'MENU' ? pickApp : pickSet };
  };

  const statOut = () => {
    const summary = computeStatistics(S.dat, S.statType, S.statFreq);
    const out: string[] = [];
    if (!summary) {
      out.push('No Data');
    } else {
      out.push(`n=${summary.n}`);
      out.push(`x̄=${Tfmt(summary.meanX)}`);
      out.push(`Σx=${Tfmt(summary.sumX)}`);
      out.push(`Σx²=${Tfmt(summary.sumX2)}`);
      out.push(`σx=${Tfmt(summary.popStdX)}`);
      out.push(`sx=${summary.n > 1 ? Tfmt(summary.sampStdX) : 'Math ERROR'}`);
      out.push(`minX=${Tfmt(summary.minX)}`);
      out.push(`Q1=${Tfmt(summary.q1)}`);
      out.push(`Med=${Tfmt(summary.med)}`);
      out.push(`Q3=${Tfmt(summary.q3)}`);
      out.push(`maxX=${Tfmt(summary.maxX)}`);
      if (S.statType !== '1-VAR' && summary.meanY !== undefined) {
        out.push(`ȳ=${Tfmt(summary.meanY)}`);
        out.push(`Σy=${Tfmt(summary.sumY ?? 0)}`);
        out.push(`Σy²=${Tfmt(summary.sumY2 ?? 0)}`);
        out.push(`Σxy=${Tfmt(summary.sumXY ?? 0)}`);
        if (summary.regCoeffs) {
          out.push(`a=${Tfmt(summary.regCoeffs.a)}`);
          out.push(`b=${Tfmt(summary.regCoeffs.b)}`);
          if (summary.regCoeffs.c !== undefined) out.push(`c=${Tfmt(summary.regCoeffs.c)}`);
          if (summary.regCoeffs.r !== undefined) out.push(`r=${Tfmt(summary.regCoeffs.r)}`);
        }
      }
    }
    S.fo = {
      t: S.statType,
      n: [],
      v: [],
      i: 0,
      p: 0,
      fn: () => [],
      out,
    };
  };

  const pushUndo = () => {
    S.undo.push({ t: S.t.slice(), c: S.c });
    if (S.undo.length > 20) S.undo.shift();
  };

  const ins = (tk: string[]) => {
    S.qrPayload = null;
    if (S.done) {
      const f = tk[0];
      if (OPS.includes(f)) S.t = ['Ans'];
      else S.t = [];
      S.c = S.t.length;
      S.done = 0;
      S.res = null;
      S.dms = false;
      S.factMode = false;
      S.eng = 0;
    }
    pushUndo();
    const delCount = S.ins && S.c < S.t.length ? 1 : 0;
    S.t.splice(S.c, delCount, ...tk);
    S.c += tk.length;
  };

  const leaveDone = () => {
    if (S.done) {
      S.done = 0;
      S.res = null;
      S.c = S.t.length;
      S.dms = false;
      S.factMode = false;
      S.eng = 0;
    }
  };

  const executeMainExpr = (forceApprox = false): CalcResult | null => {
    try {
      // Multi-statement ':'
      if (S.t.includes(':')) {
        const parts: string[][] = [];
        let cur: string[] = [];
        for (const tok of S.t) {
          if (tok === ':') { parts.push(cur); cur = []; }
          else cur.push(tok);
        }
        parts.push(cur);
        let last: CalcResult = { v: 0 };
        for (const p of parts) {
          if (!p.length) continue;
          const r = evalAny(p);
          if (r.k === 'c') {
            S.ans = r.c.re;
            S.ansCpx = r.c;
            last = Math.abs(r.c.im) > 1e-11 ? { cpx: r.c, v: r.c.re } : { v: r.c.re };
          }
        }
        return last;
      }

      // Top-level Pol(x;y) / Rec(r;θ)
      if (S.t[0] === 'Pol(' || S.t[0] === 'Rec(') {
        const inner = S.t.slice(1, S.t[S.t.length - 1] === ')' ? -1 : undefined);
        const semi = inner.indexOf(';');
        if (semi <= 0) throw 'Argument ERROR';
        const a1 = calc(inner.slice(0, semi));
        const a2 = calc(inner.slice(semi + 1));
        const rad = (x: number) => (S.mode === 'D' ? (x * Math.PI) / 180 : S.mode === 'G' ? (x * Math.PI) / 200 : x);
        const deg = (x: number) => (S.mode === 'D' ? (x * 180) / Math.PI : S.mode === 'G' ? (x * 200) / Math.PI : x);
        if (S.t[0] === 'Pol(') {
          const r = Math.hypot(a1, a2);
          const th = deg(Math.atan2(a2, a1));
          S.v.x = r;
          S.v.y = th;
          return { v: r, text: `r=${Tfmt(r)} θ=${Tfmt(th)}` };
        }
        const x = a1 * Math.cos(rad(a2));
        const y = a1 * Math.sin(rad(a2));
        S.v.x = x;
        S.v.y = y;
        return { v: x, text: `x=${Tfmt(x)} y=${Tfmt(y)}` };
      }

      // Top-level Euclidean ÷R
      const divRIdx = S.t.indexOf('÷R');
      if (divRIdx > 0) {
        const a = Math.trunc(calc(S.t.slice(0, divRIdx)));
        const b = Math.trunc(calc(S.t.slice(divRIdx + 1)));
        if (b === 0) throw 'Math ERROR';
        const q = Math.trunc(a / b);
        const r = a - q * b;
        return { v: q, text: `Q=${q}, R=${r}` };
      }

      const ev = evalAny(S.t);
      if (ev.k === 'm') {
        S.matAns = ev.m.map((r) => [...r]);
        return { mat: ev.m, text: '[' + ev.m.map((r) => r.map((x) => Tfmt(x)).join(' ')).join('; ') + ']' };
      }
      if (ev.k === 'v') {
        S.vctAns = [...ev.v];
        return { vec: ev.v, text: '[' + ev.v.map((x) => Tfmt(x)).join(' ') + ']' };
      }
      if (S.app === 'cplx' && Math.abs(ev.c.im) > 1e-11) {
        return { cpx: ev.c, v: ev.c.re };
      }
      if (Math.abs(ev.c.im) > 1e-10) throw 'Math ERROR';
      if (forceApprox) S.fm = 0;
      return { v: ev.c.re };
    } catch (e) {
      return { err: typeof e === 'string' ? e : 'Syntax ERROR' };
    }
  };

  const openOptnMenu = () => {
    if (S.app === 'base') {
      openList('BASE OPTN', ['and', 'or', 'xor', 'xnor', 'Not(', 'Neg(']);
      S.ls!.fn = (j) => { S.ls = null; ins([['and', 'or', 'xor', 'xnor', 'Not(', 'Neg('][j]]); };
    } else if (S.app === 'cplx') {
      openList('COMPLEX OPTN', ['Arg(', 'Conjg(', 'ReP(', 'ImP(', '▶r∠θ', '▶a+bi']);
      S.ls!.fn = (j) => {
        S.ls = null;
        if (j < 4) ins([['Arg(', 'Conjg(', 'ReP(', 'ImP('][j]]);
        else S.cmplxFmt = j === 4 ? 'POLAR' : 'RECT';
      };
    } else if (S.app === 'mat') {
      openList('MATRIX OPTN', ['MatA', 'MatB', 'MatC', 'MatAns', 'Det(', 'Trn(', 'Define Mat']);
      S.ls!.fn = (j) => {
        S.ls = null;
        if (j < 6) ins([['MatA', 'MatB', 'MatC', 'MatAns', 'Det(', 'Trn('][j]]);
        else {
          S.ls = {
            t: 'DEFINE MAT',
            items: ['MatA', 'MatB', 'MatC'],
            i: 0,
            fn: (mIdx) => openMatrixSizePicker((['MatA', 'MatB', 'MatC'] as const)[mIdx]),
          };
        }
      };
    } else if (S.app === 'vec') {
      openList('VECTOR OPTN', ['VctA', 'VctB', 'VctC', 'VctAns', 'DotP (·)', 'CrossP (×)', 'Angle(', 'UnitV(']);
      S.ls!.fn = (j) => {
        S.ls = null;
        ins([['VctA', 'VctB', 'VctC', 'VctAns', '·', '×v', 'Angle(', 'UnitV('][j]]);
      };
    } else if (S.app === 'stat') {
      const items = S.statType === '1-VAR'
        ? ['1-Var Calc', 'View Data', 'Select Type', 'Clear Data']
        : ['Stat Calc', 'Estimate ŷ', 'Estimate x̂', 'View Data', 'Select Type', 'Clear Data'];
      openList('STAT OPTN', items);
      S.ls!.fn = (j) => {
        S.ls = null;
        const label = items[j];
        if (label === '1-Var Calc' || label === 'Stat Calc') {
          statOut();
        } else if (label === 'View Data') {
          S.fo = {
            t: 'STAT DATA',
            n: [],
            v: [],
            i: 0,
            p: 0,
            fn: () => [],
            out: S.dat.length
              ? S.dat.map((row, idx) =>
                  S.statType === '1-VAR'
                    ? `${idx + 1}: x=${Tfmt(row.x)}${S.statFreq ? ` f=${row.freq}` : ''}`
                    : `${idx + 1}: (${Tfmt(row.x)}, ${Tfmt(row.y)})${S.statFreq ? ` f=${row.freq}` : ''}`
                )
              : ['No Data'],
          };
        } else if (label === 'Select Type') {
          openStatTypeMenu();
        } else if (label === 'Clear Data') {
          S.dat = [];
          S.statStep = 'x';
          S.t = [];
          S.c = 0;
        } else if (label === 'Estimate ŷ' || label === 'Estimate x̂') {
          const summary = computeStatistics(S.dat, S.statType, S.statFreq);
          if (!summary?.regCoeffs) {
            S.fo = { t: S.statType, n: [], v: [], i: 0, p: 0, fn: () => [], out: ['Data ERROR'] };
            return;
          }
          const { a, b, c = 0 } = summary.regCoeffs;
          if (label === 'Estimate ŷ') {
            form('Estimate ŷ', ['x'], (vals) => {
              const x = calc(vals[0]);
              let y = 0;
              if (S.statType === 'LINEAR') y = a + b * x;
              else if (S.statType === 'QUAD') y = a + b * x + c * x * x;
              else if (S.statType === 'LOG') { if (x <= 0) throw 'Math ERROR'; y = a + b * Math.log(x); }
              else if (S.statType === 'E_EXP') y = a * Math.exp(b * x);
              else if (S.statType === 'AB_EXP') y = a * Math.pow(b, x);
              else if (S.statType === 'POWER') { if (x <= 0) throw 'Math ERROR'; y = a * Math.pow(x, b); }
              else if (S.statType === 'INV') { if (x === 0) throw 'Math ERROR'; y = a + b / x; }
              return [`ŷ=${Tfmt(y)}`];
            });
          } else {
            form('Estimate x̂', ['y'], (vals) => {
              const y = calc(vals[0]);
              let x = 0;
              if (S.statType === 'LINEAR') { if (!b) throw 'Math ERROR'; x = (y - a) / b; }
              else if (S.statType === 'LOG') { if (!b) throw 'Math ERROR'; x = Math.exp((y - a) / b); }
              else if (S.statType === 'E_EXP') { if (!b || y / a <= 0) throw 'Math ERROR'; x = Math.log(y / a) / b; }
              else if (S.statType === 'AB_EXP') { if (b <= 0 || b === 1 || y / a <= 0) throw 'Math ERROR'; x = Math.log(y / a) / Math.log(b); }
              else if (S.statType === 'POWER') { if (!b || y / a <= 0) throw 'Math ERROR'; x = Math.pow(y / a, 1 / b); }
              else if (S.statType === 'INV') { if (y === a) throw 'Math ERROR'; x = b / (y - a); }
              else throw 'Math ERROR';
              return [`x̂=${Tfmt(x)}`];
            });
          }
        }
      };
    } else {
      openList('OPTION', ['sinh(', 'cosh(', 'tanh(', 'sinh⁻¹(', 'cosh⁻¹(', 'tanh⁻¹(', '° (deg)', 'ʳ (rad)', 'ᵍ (gra)']);
      S.ls!.fn = (j) => {
        S.ls = null;
        ins([['sinh(', 'cosh(', 'tanh(', 'asinh(', 'acosh(', 'atanh(', '°', 'ʳ', 'ᵍ'][j]]);
      };
    }
  };

  const openCalcOrSolve = (isSolve: boolean) => {
    const valid = new Set(['A', 'B', 'C', 'D', 'E', 'F', 'x', 'y', 'M']);
    const varsFound = Array.from(new Set(S.t.filter((x) => valid.has(x))));
    if (!isSolve && varsFound.length === 0) {
      special('@eq');
      return;
    }
    const targetVars = varsFound.length ? varsFound : ['x'];
    const exprSnapshot = S.t.slice();
    const fields = isSolve ? ['Guess x', ...targetVars.filter((v) => v !== 'x')] : targetVars;
    form(isSolve ? 'SOLVE' : 'CALC', fields, (vals) => {
      const local: Record<string, number> = { ...S.v };
      fields.forEach((name, idx) => {
        const key = name === 'Guess x' ? 'x' : name;
        const parsed = vals[idx].length ? calc(vals[idx]) : (S.v[key] || 0);
        local[key] = parsed;
        S.v[key] = parsed;
      });
      if (!isSolve) {
        const out = calc(exprSnapshot, local);
        S.ans = out;
        return [`Ans=${Tfmt(out)}`];
      }
      const eqIdx = exprSnapshot.indexOf('=');
      const lhs = eqIdx >= 0 ? exprSnapshot.slice(0, eqIdx) : exprSnapshot;
      const rhs = eqIdx >= 0 ? exprSnapshot.slice(eqIdx + 1) : [];
      const evalAt = (xVal: number) =>
        calc(lhs, { ...local, x: xVal }) - (rhs.length ? calc(rhs, { ...local, x: xVal }) : 0);
      let x = local.x ?? 0;
      for (let it = 0; it < 80; it++) {
        const fx = evalAt(x);
        if (Math.abs(fx) < 1e-11) break;
        const h = Math.max(1e-7, Math.abs(x) * 1e-7);
        const df = (evalAt(x + h) - evalAt(x - h)) / (2 * h);
        if (!isFinite(df) || Math.abs(df) < 1e-14) { x += 0.17; continue; }
        const step = Math.max(-1e4, Math.min(1e4, fx / df));
        x -= step;
        if (Math.abs(step) < 1e-11) break;
      }
      if (!isFinite(x) || Math.abs(evalAt(x)) > 1e-5) throw 'Can’t Solve';
      S.v.x = x;
      S.ans = x;
      return [`x=${Tfmt(x)}`, `L−R=${Tfmt(evalAt(x))}`];
    });
    S.fo!.v = fields.map((name) => {
      const key = name === 'Guess x' ? 'x' : name;
      return String(S.v[key] ?? 0).split('');
    });
    S.t = S.fo!.v[0].slice();
    S.c = S.t.length;
  };

  const modeKey = (id: string): boolean => {
    const L = S.ls;
    const f = S.fo;
    if (S.qrPayload !== null) {
      if (id === 'AC' || id === 'ON' || id === 'OPTN') {
        S.qrPayload = null;
        return true;
      }
      return true;
    }
    if (L) {
      if (id === 'SHIFT' || id === 'ALPHA') return true;
      S.sh = S.al = 0;
      if (id === 'U') { L.code = ''; L.i = (L.i + L.items.length - 1) % L.items.length; }
      else if (id === 'D') { L.code = ''; L.i = (L.i + 1) % L.items.length; }
      else if (id === 'EQ') { L.code = ''; L.fn(L.i); }
      else if (id === 'AC' || id === 'MENU' || id === 'ON') {
        S.ls = null;
        if (id === 'ON') {
          S.t = []; S.c = 0; S.res = null; S.done = 0; S.fo = null; S.app = 'calc';
        }
      } else if (L.items.length > 12 && /^[0-9]$/.test(id)) {
        const nextCode = (L.code || '') + id;
        if (nextCode.length === 1) {
          L.code = nextCode;
          const jump = nextCode === '0' ? 0 : Math.min(L.items.length - 1, Number(nextCode) * 10 - 1);
          L.i = jump;
        } else {
          const idx = parseInt(nextCode.slice(0, 2), 10) - 1;
          L.code = '';
          if (idx >= 0 && idx < L.items.length) L.fn(idx);
        }
      } else if (/^[1-9]$/.test(id) && +id <= L.items.length) {
        L.fn(+id - 1);
      } else if (L.items.length <= 12) {
        const abcIdx: Record<string, number> = { NEG: 9, DMS: 10, INV: 11 };
        if (abcIdx[id] !== undefined && abcIdx[id] < L.items.length) L.fn(abcIdx[id]);
      }
      return true;
    }
    if (id === 'ON') return false; // let ON perform full immediate clear!
    if (S.sh || S.al) return false;
    if (f) {
      if (f.out) {
        if (id === 'U') f.p = Math.max(0, f.p - 1);
        else if (id === 'D') f.p = Math.min(f.out.length - 1, f.p + 1);
        else if (id === 'AC' || id === 'EQ') {
          f.out = null;
          if (!f.n.length) {
            S.fo = null;
            if (S.app === 'na') S.app = 'calc';
          }
        }
        return true;
      }
      const sv = () => { f.v[f.i] = S.t.slice(); };
      const ld = () => { S.t = f.v[f.i].slice(); S.c = S.t.length; };
      if (id === 'U' || id === 'D') {
        sv();
        f.i = Math.max(0, Math.min(f.n.length - 1, f.i + (id === 'D' ? 1 : -1)));
        ld();
        return true;
      }
      if (id === 'EQ') {
        sv();
        if (f.i < f.n.length - 1) {
          f.i++;
          ld();
        } else {
          f.p = 0;
          try {
            const r = f.fn(f.v);
            if (S.fo === f) f.out = r;
          } catch (e) {
            f.out = [typeof e === 'string' ? e : 'Syntax ERROR'];
          }
        }
        return true;
      }
      if (id === 'AC') {
        if (S.t.length) { S.t = []; S.c = 0; }
        else exitApp();
        return true;
      }
      return false;
    }
    if (S.app === 'stat') {
      if (id === 'EQ') {
        if (S.t.length || S.statStep !== 'x') {
          try {
            const val = S.t.length ? calc(S.t) : S.statStep === 'freq' ? 1 : 0;
            if (S.statStep === 'x') {
              if (!S.t.length) return true;
              if (S.statType === '1-VAR') {
                if (S.statFreq) {
                  S.statDraft = { x: val, y: 0 };
                  S.statStep = 'freq';
                } else {
                  S.dat.push({ x: val, y: 0, freq: 1 });
                }
              } else {
                S.statDraft = { x: val, y: 0 };
                S.statStep = 'y';
              }
            } else if (S.statStep === 'y') {
              if (S.statFreq) {
                S.statDraft.y = val;
                S.statStep = 'freq';
              } else {
                S.dat.push({ x: S.statDraft.x, y: val, freq: 1 });
                S.statStep = 'x';
              }
            } else {
              S.dat.push({ x: S.statDraft.x, y: S.statDraft.y, freq: Math.max(0, Math.round(val)) });
              S.statStep = 'x';
            }
          } catch {
            /* ignore invalid stat token */
          }
          S.t = [];
          S.c = 0;
        }
        return true;
      }
      if (id === 'OPTN') {
        openOptnMenu();
        return true;
      }
      if (id === 'AC') {
        if (S.t.length) { S.t = []; S.c = 0; }
        else if (S.statStep !== 'x') { S.statStep = 'x'; }
        else if (S.dat.length) S.dat = [];
        else exitApp();
        return true;
      }
    }
    if (S.app === 'base') {
      const B: Record<string, 'D' | 'H' | 'B' | 'O'> = { X2: 'D', XP: 'H', LOG: 'B', LN: 'O' };
      const Lt: Record<string, string> = { NEG: 'A', DMS: 'B', INV: 'C', SIN: 'D', COS: 'E', TAN: 'F' };
      if (B[id]) { S.base = B[id]; return true; }
      if (Lt[id]) {
        if (S.base === 'H') ins([Lt[id]]);
        return true;
      }
      if (/^[0-9]$/.test(id)) {
        const rx = { D: 10, H: 16, B: 2, O: 8 }[S.base];
        if (Number(id) >= rx) return true;
      }
      if (['DOT', 'EXP', 'FRAC', 'SQ', 'INT', 'X', 'SD', 'ENG'].includes(id)) return true;
    }
    if (S.app === 'cplx' && id === 'ENG') {
      if (S.res && S.res.v !== undefined) return false; // let ENG shift result if result displayed
      ins(['i']);
      return true;
    }
    return false;
  };

  const special = (a: string) => {
    switch (a) {
      case '@eq':
      case '@approx': {
        if (!S.t.length) {
          if (S.res && a === '@approx') S.fm = 0;
          break;
        }
        S.fm = a === '@approx' ? 0 : 1;
        S.eng = 0;
        S.dms = false;
        S.factMode = false;
        const r = executeMainExpr(a === '@approx');
        if (r) {
          S.res = r;
          if (!r.err) {
            if (r.v !== undefined) S.ans = r.v;
            if (r.cpx) S.ansCpx = r.cpx;
            S.hist.push(S.t.slice());
            S.hi = S.hist.length;
          }
          S.done = 1;
        }
        break;
      }
      case '@frac':
      case '@mxfrac':
      case '@nroot': {
        S.qrPayload = null;
        if (S.done) {
          S.t = [];
          S.c = 0;
          S.done = 0;
          S.res = null;
          S.dms = false;
          S.factMode = false;
          S.eng = 0;
        }
        pushUndo();
        const pullStart = pullLeftOperandStart(S.t, S.c);
        const pulled = S.t.slice(pullStart, S.c);
        if (a === '@frac') {
          const tpl = ['⟨FR:', ...pulled, '¦', '⟩FR'];
          S.t.splice(pullStart, S.c - pullStart, ...tpl);
          S.c = pulled.length ? pullStart + 1 + pulled.length + 1 : pullStart + 1;
        } else if (a === '@mxfrac') {
          const tpl = ['⟨MX:', ...pulled, '¦', '¦', '⟩MX'];
          S.t.splice(pullStart, S.c - pullStart, ...tpl);
          S.c = pulled.length ? pullStart + 1 + pulled.length + 1 : pullStart + 1;
        } else {
          const tpl = ['⟨NR:', ...pulled, '¦', '⟩NR'];
          S.t.splice(pullStart, S.c - pullStart, ...tpl);
          S.c = pulled.length ? pullStart + 1 + pulled.length + 1 : pullStart + 1;
        }
        break;
      }
      case '@sqrt':
      case '@cbrt':
      case '@abs':
      case '@logb':
      case '@int':
      case '@deriv':
      case '@sum':
      case '@prod':
      case '@pow10':
      case '@powe': {
        S.qrPayload = null;
        if (S.done) {
          S.t = [];
          S.c = 0;
          S.done = 0;
          S.res = null;
          S.dms = false;
          S.factMode = false;
          S.eng = 0;
        }
        pushUndo();
        if (a === '@pow10') {
          S.t.splice(S.c, 0, '1', '0', '⟨PW:', '⟩PW');
          S.c += 3;
        } else if (a === '@powe') {
          S.t.splice(S.c, 0, 'ℯ', '⟨PW:', '⟩PW');
          S.c += 2;
        } else if (a === '@logb') {
          S.t.splice(S.c, 0, '⟨LG:', '¦', '⟩LG');
          S.c += 1;
        } else if (a === '@deriv') {
          S.t.splice(S.c, 0, '⟨DX:', '¦', '⟩DX');
          S.c += 1;
        } else if (a === '@int' || a === '@sum' || a === '@prod') {
          const openTok = a === '@int' ? '⟨IN:' : a === '@sum' ? '⟨SM:' : '⟨PR:';
          S.t.splice(S.c, 0, openTok, '¦', '¦', STRUCT_CLOSE[openTok]);
          S.c += 1;
        } else {
          const openTok = a === '@sqrt' ? '⟨SQ:' : a === '@cbrt' ? '⟨CR:' : '⟨AB:';
          S.t.splice(S.c, 0, openTok, STRUCT_CLOSE[openTok]);
          S.c += 1;
        }
        break;
      }
      case '@pow': {
        S.qrPayload = null;
        if (S.done) {
          S.t = ['Ans'];
          S.c = 1;
          S.done = 0;
          S.res = null;
          S.dms = false;
          S.factMode = false;
          S.eng = 0;
        }
        pushUndo();
        S.t.splice(S.c, 0, '⟨PW:', '⟩PW');
        S.c += 1;
        break;
      }
      case '@del':
        leaveDone();
        if (S.c > 0) {
          const prevTok = S.t[S.c - 1];
          if (CLOSE_TO_OPEN[prevTok]) {
            const openIdx = findMatchingOpen(S.t, S.c - 1);
            const { closeIdx } = findMatchingClose(S.t, openIdx);
            const innerContent = S.t.slice(openIdx + 1, closeIdx).some((tok) => tok !== '¦');
            if (!innerContent) {
              pushUndo();
              S.t.splice(openIdx, closeIdx - openIdx + 1);
              S.c = openIdx;
            } else {
              S.c--;
            }
          } else if (prevTok === '¦') {
            let depth = 0;
            let openIdx = 0;
            for (let k = S.c - 2; k >= 0; k--) {
              if (CLOSE_TO_OPEN[S.t[k]]) depth++;
              else if (STRUCT_OPEN.has(S.t[k])) {
                if (depth === 0) { openIdx = k; break; }
                depth--;
              }
            }
            const { closeIdx } = findMatchingClose(S.t, openIdx);
            const hasContent = S.t.slice(openIdx + 1, closeIdx).some((tok) => tok !== '¦');
            if (!hasContent) {
              pushUndo();
              S.t.splice(openIdx, closeIdx - openIdx + 1);
              S.c = openIdx;
            } else {
              S.c--;
            }
          } else if (STRUCT_OPEN.has(prevTok)) {
            pushUndo();
            const openIdx = S.c - 1;
            const { bars, closeIdx } = findMatchingClose(S.t, openIdx);
            const removeSet = new Set([openIdx, ...bars, closeIdx]);
            S.t = S.t.filter((_, idx) => !removeSet.has(idx));
            S.c = openIdx;
          } else {
            pushUndo();
            S.t.splice(S.c - 1, 1);
            S.c--;
          }
        }
        break;
      case '@ins':
        S.ins = !S.ins;
        break;
      case '@undo':
        if (S.undo.length) {
          const prev = S.undo.pop()!;
          S.t = prev.t;
          S.c = prev.c;
          S.res = null;
          S.done = 0;
        }
        break;
      case '@ac':
        S.t = [];
        S.c = 0;
        S.res = null;
        S.done = 0;
        S.dms = false;
        S.factMode = false;
        S.eng = 0;
        S.pend = null;
        S.qrPayload = null;
        break;
      case '@off':
        S.on = 0;
        S.ls = null;
        S.fo = null;
        S.qrPayload = null;
        break;
      case '@on':
        // Clicking ON immediately clears screen, errors, menus, forms & resets ready state
        S.on = 1;
        S.t = [];
        S.c = 0;
        S.res = null;
        S.done = 0;
        S.sh = 0;
        S.al = 0;
        S.pend = null;
        S.ls = null;
        S.fo = null;
        S.qrPayload = null;
        S.dms = false;
        S.factMode = false;
        S.eng = 0;
        S.ins = false;
        if (S.app !== 'calc' && S.app !== 'cplx' && S.app !== 'base') {
          S.app = 'calc';
        }
        break;
      case '@sd':
        if (S.res && S.res.v !== undefined) {
          S.dms = false;
          S.factMode = false;
          S.eng = 0;
          S.fm = S.fm ? 0 : 1;
        }
        break;
      case '@mx':
        if (S.res && S.res.v !== undefined) {
          S.fm = 1;
          S.mx = S.mx ? 0 : 1;
        }
        break;
      case '@eng':
        if (S.res && S.res.v !== undefined) {
          S.dms = false;
          S.factMode = false;
          S.eng = S.eng === 0 ? 1 : S.eng + 1;
        }
        break;
      case '@ang':
        if (S.res && S.res.v !== undefined && S.eng !== 0) {
          S.eng = S.eng - 1;
        } else {
          ins(['∠']);
        }
        break;
      case '@dms':
        if (S.res && S.res.v !== undefined) {
          S.dms = !S.dms;
          S.factMode = false;
        } else {
          ins(['°']);
        }
        break;
      case '@fact':
        if (S.res && S.res.v !== undefined) {
          S.factMode = !S.factMode;
          S.dms = false;
        }
        break;
      case '@optn':
        openOptnMenu();
        break;
      case '@qr':
        S.qrPayload = `${tokensToReadable(S.t) || '0'} = ${S.res?.v !== undefined ? Tfmt(S.res.v) : '0'}`;
        break;
      case '@calc':
        openCalcOrSolve(false);
        break;
      case '@solve':
        openCalcOrSolve(true);
        break;
      case '@const': {
        const openConstItems = (list: typeof SCIENTIFIC_CONSTANTS, title: string) => {
          openList(title, list.map((c) => `${c.symbol} (${c.name})`));
          S.ls!.fn = (j) => {
            S.ls = null;
            const c = list[j];
            ins([`CONST:${c.symbol}:${c.value}`]);
          };
        };
        openList('CONST', [...CONST_CATEGORIES, 'All (01-47)']);
        S.ls!.fn = (catIdx) => {
          if (catIdx < CONST_CATEGORIES.length) {
            const cat = CONST_CATEGORIES[catIdx];
            openConstItems(
              SCIENTIFIC_CONSTANTS.filter((c) => c.category === cat),
              cat.toUpperCase()
            );
          } else {
            openConstItems(SCIENTIFIC_CONSTANTS, 'CONST 01-47');
          }
        };
        break;
      }
      case '@conv': {
        const openConvItems = (list: typeof UNIT_CONVERSIONS, title: string) => {
          openList(title, list.map((u) => u.label));
          S.ls!.fn = (j) => {
            S.ls = null;
            const u = list[j];
            const convTok = `CONV:${u.code}`;
            if (S.done && S.res?.v !== undefined && !S.res.err) {
              S.t = ['Ans', convTok];
              S.c = S.t.length;
              S.done = 0;
              S.fm = 0;
              const r = executeMainExpr(true);
              if (r) {
                S.res = r;
                if (!r.err && r.v !== undefined) S.ans = r.v;
                S.done = 1;
              }
            } else if (S.t.length > 0) {
              S.t.push(convTok);
              S.c = S.t.length;
              S.fm = 0;
              const r = executeMainExpr(true);
              if (r) {
                S.res = r;
                if (!r.err && r.v !== undefined) {
                  S.ans = r.v;
                  S.hist.push(S.t.slice());
                  S.hi = S.hist.length;
                }
                S.done = 1;
              }
            } else {
              form(u.label, [u.fromUnit], (fields) => {
                const inputVal = fields[0].length ? calc(fields[0]) : 0;
                const out = u.convert(inputVal);
                S.ans = out;
                S.fm = 0;
                return [`${Tfmt(out)} ${u.toUnit}`];
              });
            }
          };
        };
        openList('CONV', [...CONV_CATEGORIES, 'All (01-40)']);
        S.ls!.fn = (catIdx) => {
          if (catIdx < CONV_CATEGORIES.length) {
            const cat = CONV_CATEGORIES[catIdx];
            openConvItems(
              UNIT_CONVERSIONS.filter((u) => u.category === cat),
              cat.toUpperCase()
            );
          } else {
            openConvItems(UNIT_CONVERSIONS, 'CONV 01-40');
          }
        };
        break;
      }
      case '@setup':
        openList('SETUP', SETUP);
        break;
      case '@menu':
        openList('MENU', APPS);
        break;
      case '@sto':
        S.pend = 'sto';
        break;
      case '@rcl':
        S.pend = 'rcl';
        break;
      case '@mp':
      case '@mm': {
        let v: number | null = S.ans;
        if (!S.done && S.t.length) {
          const r = executeMainExpr();
          if (!r || r.err || r.v === undefined) {
            if (r?.err) { S.res = r; S.done = 1; }
            break;
          }
          v = r.v;
        }
        S.v.M = (S.v.M || 0) + (a === '@mp' ? v : -v);
        S.res = { v: S.v.M };
        S.done = 1;
        break;
      }
      case '@reset':
        openList('RESET', ['Setup Data', 'Memory', 'Initialize All']);
        S.ls!.fn = (j) => {
          S.ls = null;
          if (j === 0 || j === 2) {
            S.mode = 'D';
            S.nf = { t: 'N', n: 0 };
            S.normVar = 2;
            S.mx = 0;
            S.cmplxFmt = 'RECT';
            S.statFreq = false;
            S.decComma = false;
          }
          if (j === 1 || j === 2) {
            S.v = {};
            S.vc = {};
            S.ans = 0;
            S.ansCpx = { re: 0, im: 0 };
            S.hist = [];
            S.dat = [];
          }
          if (j === 2) {
            const fresh = createInitialState();
            Object.assign(S, fresh);
            try { window.localStorage.removeItem(STORAGE_KEY); } catch { /* ignore */ }
          }
        };
        break;
    }
  };

  const press = useCallback((id: string) => {
    if (id === 'ON') {
      special('@on');
      forceDraw();
      return;
    }
    if (!S.on) {
      forceDraw();
      return;
    }
    if (modeKey(id)) {
      forceDraw();
      return;
    }
    if (id === 'L' || id === 'R' || id === 'U' || id === 'D') {
      S.sh = S.al = 0;
      if (id === 'L') {
        leaveDone();
        S.c = Math.max(0, S.c - 1);
      }
      if (id === 'R') {
        leaveDone();
        S.c = Math.min(S.t.length, S.c + 1);
      }
      if (id === 'U') {
        const vert = !S.done ? jumpVertical(S.t, S.c, 'U') : null;
        if (vert !== null) {
          S.c = vert;
        } else if (S.hist.length) {
          S.hi = Math.max(0, S.hi - 1);
          S.t = S.hist[S.hi].slice();
          S.c = S.t.length;
          S.done = 0;
          S.res = null;
        }
      }
      if (id === 'D') {
        const vert = !S.done ? jumpVertical(S.t, S.c, 'D') : null;
        if (vert !== null) {
          S.c = vert;
        } else if (S.hist.length) {
          S.hi = Math.min(S.hist.length - 1, S.hi + 1);
          S.t = S.hist[S.hi].slice();
          S.c = S.t.length;
          S.done = 0;
          S.res = null;
        }
      }
      forceDraw();
      return;
    }
    const k = KM[id];
    if (S.pend) {
      const l = k?.a;
      S.sh = S.al = 0;
      if (l && /^[A-FMxy]$/.test(l)) {
        if (S.pend === 'sto') {
          let val = S.ans;
          if (!S.done && S.t.length) {
            try { val = calc(S.t); } catch { /* keep ans */ }
          } else if (S.res?.v !== undefined) {
            val = S.res.v;
          }
          S.v[l] = val;
          if (S.res?.cpx) S.vc[l] = S.res.cpx;
        } else {
          ins([l]);
        }
      }
      S.pend = null;
      forceDraw();
      return;
    }
    const a = S.sh ? k.s : S.al ? k.a : k.m;
    if (id === 'SHIFT') {
      S.sh = S.sh ? 0 : 1;
      S.al = 0;
      forceDraw();
      return;
    }
    if (id === 'ALPHA') {
      S.al = S.al ? 0 : 1;
      S.sh = 0;
      forceDraw();
      return;
    }
    S.sh = S.al = 0;
    if (!a) {
      forceDraw();
      return;
    }
    if (a[0] === '@') special(a);
    else ins(a.split(' '));
    forceDraw();
  }, [forceDraw]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const map: Record<string, string> = {
        '0': '0', '1': '1', '2': '2', '3': '3', '4': '4',
        '5': '5', '6': '6', '7': '7', '8': '8', '9': '9',
        '.': 'DOT', ',': 'DOT',
        '+': 'ADD', '-': 'SUB', '*': 'MUL', '/': 'DIV',
        '^': 'XP', '(': 'LP', ')': 'RP',
        Enter: 'EQ', '=': 'EQ',
        Backspace: 'DEL', Delete: 'DEL', Escape: 'AC',
        ArrowLeft: 'L', ArrowRight: 'R', ArrowUp: 'U', ArrowDown: 'D',
      };
      if (map[e.key]) {
        e.preventDefault();
        press(map[e.key]);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [press]);

  useEffect(() => {
    const el = exRef.current;
    if (!el) return;
    const cur = el.querySelector('.cur, .cur-ovr') as HTMLElement | null;
    if (cur) {
      const curLeft = cur.offsetLeft;
      const curRight = curLeft + cur.offsetWidth + 10;
      if (curRight > el.scrollLeft + el.clientWidth) {
        el.scrollLeft = curRight - el.clientWidth;
      } else if (curLeft < el.scrollLeft) {
        el.scrollLeft = Math.max(0, curLeft - 10);
      }
    } else {
      el.scrollLeft = 0;
    }
  });

  const L = S.ls;
  const f = S.fo;
  const hideExRs = Boolean(L) || S.qrPayload !== null;

  const renderFmtNodes = (res: CalcResult): React.ReactNode => {
    if (res.err) return <span style={{ fontSize: '.6em' }}>{res.err}</span>;
    if (res.mat && res.mat.length <= 3 && res.mat[0]?.length <= 3) {
      return (
        <div className="mat-grid">
          <div className="mat-rows">
            {res.mat.map((row, ri) => (
              <div key={ri} className="mat-row">
                {row.map((cell, ci) => (
                  <span key={ci}>{Tfmt(cell)}</span>
                ))}
              </div>
            ))}
          </div>
        </div>
      );
    }
    if (res.text) return <span style={{ fontSize: '.66em' }}>{res.text}</span>;
    if (res.cpx && Math.abs(res.cpx.im) > 1e-11) {
      const c = res.cpx;
      if (S.cmplxFmt === 'POLAR') {
        const r = Math.hypot(c.re, c.im);
        let th = Math.atan2(c.im, c.re);
        if (S.mode === 'D') th = (th * 180) / Math.PI;
        else if (S.mode === 'G') th = (th * 200) / Math.PI;
        return <span style={{ fontSize: '.76em' }}>{Tfmt(r)}∠{Tfmt(th)}</span>;
      }
      const imAbs = Math.abs(c.im);
      const imStr = Math.abs(imAbs - 1) < 1e-11 ? 'i' : `${Tfmt(imAbs)}i`;
      if (Math.abs(c.re) < 1e-11) return `${c.im < 0 ? '−' : ''}${imStr}`;
      return <span style={{ fontSize: '.78em' }}>{Tfmt(c.re)}{c.im < 0 ? '−' : '+'}{imStr}</span>;
    }

    const v = res.v ?? 0;
    if (S.factMode) return <span style={{ fontSize: '.78em' }}>{primeFactorizeString(v)}</span>;
    if (S.dms) return <span style={{ fontSize: '.78em' }}>{formatDms(v)}</span>;

    if (S.app === 'base') {
      const n = Math.trunc(v);
      return (S.base !== 'D' && n < 0 ? n >>> 0 : n)
        .toString({ D: 10, H: 16, B: 2, O: 8 }[S.base])
        .toUpperCase();
    }
    if (S.nf.t === 'F') return (v < 0 ? '−' : '') + Math.abs(v).toFixed(S.nf.n);
    if (S.nf.t === 'S') {
      const [m, e] = Math.abs(v).toExponential(S.nf.n ? S.nf.n - 1 : 9).split('e');
      return <>{v < 0 ? '−' : ''}{m}×10<sup>{parseInt(e, 10)}</sup></>;
    }
    if (S.fm && S.eng === 0 && S.nf.t === 'N') {
      const ex = tryExactRepresentation(v, Boolean(S.mx));
      if (ex && ex.displayNum) {
        const cleanMinus = (s: string) => (s.startsWith('-') ? `−${s.slice(1)}` : s);
        const renderSurd = (s: string): React.ReactNode => {
          const rIdx = s.indexOf('√');
          if (rIdx === -1) return s;
          return (
            <>
              {s.slice(0, rIdx)}
              <span className="mp-sqrt">
                <svg className="mp-rad-svg" viewBox="0 0 12 20" preserveAspectRatio="none" aria-hidden="true">
                  <path d="M0.6 11.5 L3.4 11.5 L6.4 18.6 L11.8 0.7" fill="none" stroke="currentColor" strokeWidth="1.6" vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span className="mp-radicand">{s.slice(rIdx + 1)}</span>
              </span>
            </>
          );
        };
        const numStr = cleanMinus(ex.displayNum);
        if ((ex.kind === 'pi' || ex.kind === 'surd') && !ex.displayDen) {
          return ex.kind === 'surd' ? renderSurd(numStr) : numStr;
        }
        if ((ex.kind === 'pi' || ex.kind === 'surd') && ex.displayDen) {
          const neg = numStr.startsWith('−');
          const innerNum = neg ? numStr.slice(1) : numStr;
          return (
            <>
              {neg ? '−' : ''}
              <span className="fr">
                <i>{ex.kind === 'surd' ? renderSurd(innerNum) : innerNum}</i>
                <i>{ex.displayDen}</i>
              </span>
            </>
          );
        }
        if (ex.kind === 'mixed') {
          return (
            <>
              {cleanMinus(ex.displayWhole ?? '')}
              <span className="fr">
                <i>{numStr}</i>
                <i>{ex.displayDen}</i>
              </span>
            </>
          );
        }
        if (ex.kind === 'rational') {
          const neg = numStr.startsWith('−');
          return (
            <>
              {neg ? '−' : ''}
              <span className="fr">
                <i>{neg ? numStr.slice(1) : numStr}</i>
                <i>{ex.displayDen}</i>
              </span>
            </>
          );
        }
      }
      const fr = toFrac(v);
      if (fr) {
        const n = Math.abs(fr[0]);
        const w = S.mx && n >= fr[1] ? Math.floor(n / fr[1]) : 0;
        const q = w ? n % fr[1] : n;
        return (
          <>
            {fr[0] < 0 ? '−' : ''}
            {w || ''}
            {q ? (
              <span className="fr">
                <i>{q}</i>
                <i>{fr[1]}</i>
              </span>
            ) : null}
          </>
        );
      }
    }
    if (v === 0) return '0';
    const r = Number(v.toPrecision(10));
    const A = Math.abs(r);
    const sg = r < 0 ? '−' : '';
    if (S.eng !== 0) {
      const baseExp = Math.floor(Math.log10(A) / 3) * 3 + (S.eng > 0 ? (S.eng - 1) * 3 : S.eng * 3);
      return (
        <>
          {sg}{Number((A / Math.pow(10, baseExp)).toPrecision(10))}×10<sup>{baseExp}</sup>
        </>
      );
    }
    if (A >= 1e10 || A < 1e-9) {
      const [m, e] = A.toExponential(9).split('e');
      return <>{sg}{Number(m)}×10<sup>{parseInt(e, 10)}</sup></>;
    }
    return sg + A.toLocaleString('en-US', { useGrouping: false, maximumFractionDigits: 20 });
  };

  const renderTokenSegment = (start: number, end: number, showEmptyBox = false): React.ReactNode => {
    const showCursorAt = (pos: number) =>
      pos === S.c && !S.done && !(S.res && S.res.err) ? (
        <i key={`cur-${pos}`} className={S.ins ? 'cur-ovr' : 'cur'} />
      ) : null;

    if (start === end && showEmptyBox) {
      const hasCur = start === S.c && !S.done && !(S.res && S.res.err);
      return (
        <span className={`mp-box${hasCur ? ' has-cur' : ''}`}>
          {showCursorAt(start)}
        </span>
      );
    }

    const nodes: React.ReactNode[] = [];
    let i = start;
    while (i < end) {
      const curNode = showCursorAt(i);
      if (curNode) nodes.push(curNode);
      const tok = S.t[i];
      if (STRUCT_OPEN.has(tok)) {
        const { bars, closeIdx } = findMatchingClose(S.t, i);
        if (tok === '⟨FR:' && bars.length >= 1) {
          nodes.push(
            <span key={`fr-${i}`} className="mp-frac">
              <span className="mp-num">{renderTokenSegment(i + 1, bars[0], true)}</span>
              <span className="mp-den">{renderTokenSegment(bars[0] + 1, closeIdx, true)}</span>
            </span>
          );
        } else if (tok === '⟨MX:' && bars.length >= 2) {
          nodes.push(
            <React.Fragment key={`mx-${i}`}>
              {renderTokenSegment(i + 1, bars[0], true)}
              <span className="mp-frac">
                <span className="mp-num">{renderTokenSegment(bars[0] + 1, bars[1], true)}</span>
                <span className="mp-den">{renderTokenSegment(bars[1] + 1, closeIdx, true)}</span>
              </span>
            </React.Fragment>
          );
        } else if (tok === '⟨SQ:' || tok === '⟨CR:') {
          nodes.push(
            <span key={`rt-${i}`} className="mp-sqrt">
              {tok === '⟨CR:' && <span className="mp-root-idx">3</span>}
              <svg className="mp-rad-svg" viewBox="0 0 12 20" preserveAspectRatio="none" aria-hidden="true">
                <path d="M0.6 11.5 L3.4 11.5 L6.4 18.6 L11.8 0.7" fill="none" stroke="currentColor" strokeWidth="1.6" vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span className="mp-radicand">{renderTokenSegment(i + 1, closeIdx, true)}</span>
            </span>
          );
        } else if (tok === '⟨NR:' && bars.length >= 1) {
          nodes.push(
            <span key={`nr-${i}`} className="mp-sqrt">
              <span className="mp-root-idx">{renderTokenSegment(i + 1, bars[0], true)}</span>
              <svg className="mp-rad-svg" viewBox="0 0 12 20" preserveAspectRatio="none" aria-hidden="true">
                <path d="M0.6 11.5 L3.4 11.5 L6.4 18.6 L11.8 0.7" fill="none" stroke="currentColor" strokeWidth="1.6" vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span className="mp-radicand">{renderTokenSegment(bars[0] + 1, closeIdx, true)}</span>
            </span>
          );
        } else if (tok === '⟨PW:') {
          nodes.push(
            <span key={`pw-${i}`} className="mp-sup">
              {renderTokenSegment(i + 1, closeIdx, true)}
            </span>
          );
        } else if (tok === '⟨LG:' && bars.length >= 1) {
          nodes.push(
            <span key={`lg-${i}`} className="mp-log">
              <span>log</span>
              <span className="mp-sub">{renderTokenSegment(i + 1, bars[0], true)}</span>
              <span>({renderTokenSegment(bars[0] + 1, closeIdx, true)})</span>
            </span>
          );
        } else if (tok === '⟨AB:') {
          nodes.push(
            <span key={`ab-${i}`} className="mp-abs">
              {renderTokenSegment(i + 1, closeIdx, true)}
            </span>
          );
        } else if (tok === '⟨IN:' && bars.length >= 2) {
          nodes.push(
            <span key={`in-${i}`} className="mp-calc-op">
              <span className="mp-int-sym">∫</span>
              <span className="mp-lims">
                <span className="mp-lim">{renderTokenSegment(bars[1] + 1, closeIdx, true)}</span>
                <span className="mp-lim">{renderTokenSegment(bars[0] + 1, bars[1], true)}</span>
              </span>
              <span>({renderTokenSegment(i + 1, bars[0], true)})</span>
              <span className="mp-dx-tail">dx</span>
            </span>
          );
        } else if (tok === '⟨DX:' && bars.length >= 1) {
          nodes.push(
            <span key={`dx-${i}`} className="mp-calc-op">
              <span className="mp-frac mp-dfrac">
                <span className="mp-num">d</span>
                <span className="mp-den">dx</span>
              </span>
              <span>({renderTokenSegment(i + 1, bars[0], true)})</span>
              <span className="mp-eval-at">
                <span className="mp-eval-sub">x={renderTokenSegment(bars[0] + 1, closeIdx, true)}</span>
              </span>
            </span>
          );
        } else if ((tok === '⟨SM:' || tok === '⟨PR:') && bars.length >= 2) {
          nodes.push(
            <span key={`sp-${i}`} className="mp-calc-op">
              <span className="mp-bigop">
                <span className="mp-lim">{renderTokenSegment(bars[1] + 1, closeIdx, true)}</span>
                <span className="mp-bigsym">{tok === '⟨SM:' ? 'Σ' : 'Π'}</span>
                <span className="mp-lim">x={renderTokenSegment(bars[0] + 1, bars[1], true)}</span>
              </span>
              <span>({renderTokenSegment(i + 1, bars[0], true)})</span>
            </span>
          );
        }
        i = closeIdx + 1;
        continue;
      }

      const label = tok.startsWith('CONST:')
        ? tok.split(':')[1]
        : tok.startsWith('CONV:')
        ? (UNIT_CONVERSIONS.find((u) => u.code === tok.slice(5))?.label.replace(/\s+/g, '') || 'CONV')
        : DISP[tok] || tok;
      nodes.push(<React.Fragment key={`tk-${i}`}>{label}</React.Fragment>);
      i++;
    }
    const endCur = showCursorAt(end);
    if (endCur) nodes.push(endCur);
    return nodes;
  };

  const renderExprTokens = (): React.ReactNode => renderTokenSegment(0, S.t.length, false);

  let exNode: React.ReactNode = renderExprTokens();
  let rsNode: React.ReactNode = S.res ? renderFmtNodes(S.res) : null;

  let lsNode: React.ReactNode = null;
  if (S.qrPayload !== null) {
    const bits: boolean[] = [];
    let h = 2166136261;
    for (let i = 0; i < S.qrPayload.length; i++) {
      h ^= S.qrPayload.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    for (let r = 0; r < 15; r++) {
      for (let c = 0; c < 15; c++) {
        const finder = (r < 5 && c < 5) || (r < 5 && c >= 10) || (r >= 10 && c < 5);
        if (finder) {
          const lr = r >= 10 ? r - 10 : r;
          const lc = c >= 10 ? c - 10 : c;
          bits.push(lr === 0 || lr === 4 || lc === 0 || lc === 4 || (lr === 2 && lc === 2));
        } else {
          h ^= (r * 19 + c * 37) & 0xff;
          h = Math.imul(h, 16777619);
          bits.push((h & 1) === 1);
        }
      }
    }
    lsNode = (
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', paddingTop: '2px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(15, 3px)', gap: 0, border: '2px solid #16241b', padding: '1px' }}>
          {bits.map((on, idx) => (
            <span key={idx} style={{ width: '3px', height: '3px', background: on ? '#16241b' : 'transparent', display: 'block', padding: 0 }} />
          ))}
        </div>
        <div style={{ fontSize: '0.72em', lineHeight: 1.25, overflow: 'hidden' }}>
          <b>QR</b>
          <span>{S.qrPayload.slice(0, 18)}</span>
          <span>[AC]:Close</span>
        </div>
      </div>
    );
  } else if (L) {
    const st = Math.max(0, Math.min(L.i - 1, L.items.length - 4));
    const useTwoDigit = L.items.length > 12;
    lsNode = L.items.slice(st, st + 4).map((x, k) => {
      const n = st + k;
      const prefix = useTwoDigit ? String(n + 1).padStart(2, '0') : '123456789ABC'[n];
      const text = `${prefix}:${x}`;
      return n === L.i ? (
        <b key={n} onPointerDown={(e) => { e.preventDefault(); L.fn(n); forceDraw(); }}>{text}</b>
      ) : (
        <span key={n} onPointerDown={(e) => { e.preventDefault(); L.fn(n); forceDraw(); }}>{text}</span>
      );
    });
  } else if (f && f.out) {
    exNode = f.t + (f.out.length > 1 ? `  ${f.p + 1}/${f.out.length}` : '');
    const curOut = f.out[f.p];
    if (curOut.startsWith('TBL:')) {
      const cols = curOut.slice(4).split('|');
      rsNode = (
        <div className="tbl-row">
          <span>x={cols[0]}</span>
          <span>f={cols[1]}</span>
          {cols[2] !== undefined && <span>g={cols[2]}</span>}
        </div>
      );
    } else {
      rsNode = curOut;
    }
  } else if (f) {
    exNode = (
      <>
        <span style={{ opacity: 0.55, marginRight: '0.35em' }}>{f.n[f.i]}</span>{renderExprTokens()}
      </>
    );
  } else if (S.app === 'stat') {
    const promptLbl =
      S.statStep === 'x'
        ? `x${S.dat.length + 1}`
        : S.statStep === 'y'
        ? `y${S.dat.length + 1}`
        : `Freq${S.dat.length + 1}`;
    exNode = (
      <>
        <span style={{ opacity: 0.55, marginRight: '0.35em' }}>{promptLbl}</span>{renderExprTokens()}
      </>
    );
    rsNode = `${S.statType} n=${S.dat.length}`;
  }

  const renderShiftLabel = (id: string, raw?: string): React.ReactNode => {
    if (!raw) return null;
    if (id === 'MENU') return <><u>MENU</u> SETUP</>;
    if (id === 'ON') return <u>ON</u>;
    return raw;
  };

  const renderFace = (id: string, raw?: string): React.ReactNode => {
    if (!raw) return null;
    if (id === 'X') return <i>x</i>;
    if (id === 'X2') return <><i>x</i>²</>;
    if (id === 'XP') return <><i>x</i><sup>▪</sup></>;
    if (id === 'INV') return <><i>x</i>⁻¹</>;
    if (id === 'EXP') return <>×10<sup className="math-i">x</sup></>;
    return raw;
  };

  const renderKey = (k: KeyDef) => {
    if (k.isDp) {
      return (
        <div key="DP" id="dp">
          <button type="button" style={{ left: '35%', top: '6%' }} onPointerDown={(e) => { e.preventDefault(); press('U'); }}>▲</button>
          <button type="button" style={{ left: '35%', bottom: '6%' }} onPointerDown={(e) => { e.preventDefault(); press('D'); }}>▼</button>
          <button type="button" style={{ left: '7%', top: '33%' }} onPointerDown={(e) => { e.preventDefault(); press('L'); }}>◀</button>
          <button type="button" style={{ right: '7%', top: '33%' }} onPointerDown={(e) => { e.preventDefault(); press('R'); }}>▶</button>
        </div>
      );
    }

    const isAct = (k.id === 'SHIFT' && S.sh) || (k.id === 'ALPHA' && S.al);

    return (
      <div key={k.id} className="kw">
        <div className="lb">
          <span className="s">{renderShiftLabel(k.id, k.shiftLabel)}</span>
          <span className="a">{k.alphaLabel || ''}</span>
          <span className="b">{k.blueLabel || ''}</span>
        </div>
        <button
          type="button"
          className={`k ${k.cls}${isAct ? ' act' : ''}`}
          data-id={k.id}
          onPointerDown={(e) => { e.preventDefault(); press(k.id); }}
        >
          {renderFace(k.id, k.face)}
        </button>
      </div>
    );
  };

  return (
    <div className="flex flex-col items-center">
      <div id="calc">
        <div id="bd">
          <div id="hd">
            <div id="nm">
              <b>FARDIN</b>
              <span>FX-991F</span>
            </div>
            <div id="sol" />
          </div>
          <div id="bez">
            <div id="lcd" style={{ visibility: S.on ? 'visible' : 'hidden' }}>
              <div id="ind">
                <span id="iS" className={S.sh ? 'on' : ''}>S</span>
                <span id="iA" className={S.al ? 'on' : ''}>A</span>
                <span id="iM" className={S.v.M ? 'on' : ''}>M</span>
                <span id="iO" className={S.pend ? 'on' : ''}>STO</span>
                <span id="iD" className="on">{S.app === 'base' ? S.base : S.app === 'cplx' ? 'CMPLX' : S.mode}</span>
              </div>
              <div ref={exRef} id="ex" style={{ display: hideExRs ? 'none' : undefined }}>
                {exNode}
              </div>
              <div id="ls">{lsNode}</div>
              <div
                id="rs"
                className={S.app === 'base' ? 'base-rs' : undefined}
                style={{ display: hideExRs ? 'none' : undefined }}
              >
                <span
                  className={
                    S.app === 'base' && S.base === 'B' && typeof rsNode === 'string' && rsNode.length > 12
                      ? 'rs-val bin-long'
                      : 'rs-val'
                  }
                >
                  {rsNode}
                </span>
                {S.app === 'base' && (
                  <span className="base-tag">{{ D: 'Dec', H: 'Hex', B: 'Bin', O: 'Oct' }[S.base]}</span>
                )}
              </div>
            </div>
          </div>
          <div id="top" className="g">
            {TOP.map(renderKey)}
          </div>
          <div id="num" className="g">
            {NUM.map(renderKey)}
          </div>
        </div>
      </div>
      <PWAInstallButton />
      <OfflineIndicator />
    </div>
  );
}
