import {createRoot} from 'react-dom/client';
import {registerSW} from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';
import {initNativeFullscreen} from './utils/nativeFeedback.ts';

registerSW({
  immediate: true,
});

void initNativeFullscreen();

createRoot(document.getElementById('root')!).render(<App />);
