import React from 'react';
import {
  AngleUnit,
  BaseMode,
  CalcMode,
  CalcSettings,
  CursorPos,
  EvalResult,
  HistoryEntry,
  LcdScreen as LcdScreenState,
  MathNode,
  MatrixData,
  StatRow,
  StatType,
  VariablesMap,
  VectorData,
} from '../calculator/types';
import {
  CONST_CATEGORIES,
  CONV_CATEGORIES,
  SCIENTIFIC_CONSTANTS,
  UNIT_CONVERSIONS,
} from '../calculator/constantsData';
import { formatRealNumber } from '../calculator/exactMath';
import { computeStatistics, evalSpreadsheetCell } from '../calculator/modesSolver';
import { MathListView, ResultView } from './MathDisplay';

export const MENU_ITEMS: Array<{ id: CalcMode; keyLabel: string; title: string; glyph: string }> = [
  { id: 'COMP', keyLabel: '1', title: 'Calculate', glyph: '＋×' },
  { id: 'CMPLX', keyLabel: '2', title: 'Complex', glyph: 'a+bi' },
  { id: 'BASE', keyLabel: '3', title: 'Base-N', glyph: '01₂' },
  { id: 'MATRIX', keyLabel: '4', title: 'Matrix', glyph: '[M]' },
  { id: 'VECTOR', keyLabel: '5', title: 'Vector', glyph: 'v⃗' },
  { id: 'STAT', keyLabel: '6', title: 'Statistics', glyph: 'Σx' },
  { id: 'DIST', keyLabel: '7', title: 'Distribution', glyph: '🔔' },
  { id: 'SHEET', keyLabel: '8', title: 'Spreadsheet', glyph: '⊞' },
  { id: 'TABLE', keyLabel: '9', title: 'Table', glyph: 'f(x)' },
  { id: 'EQN', keyLabel: 'A', title: 'Equation', glyph: 'x=' },
  { id: 'INEQ', keyLabel: 'B', title: 'Inequality', glyph: 'x>' },
  { id: 'RATIO', keyLabel: 'C', title: 'Ratio', glyph: 'A:B' },
];

interface LcdProps {
  isOff: boolean;
  shift: boolean;
  alpha: boolean;
  stoMode: boolean;
  rclMode: boolean;
  overwrite: boolean;
  mode: CalcMode;
  baseMode: BaseMode;
  settings: CalcSettings;
  vars: VariablesMap;
  screen: LcdScreenState;
  expr: MathNode[];
  cursor: CursorPos;
  result: EvalResult | null;
  history: HistoryEntry[];
  historyIdx: number;
  showDecimal: boolean;
  showMixed: boolean;
  dmsView: boolean;
  engShift: number | null;
  statType: StatType;
  statRows: StatRow[];
  matrices: Record<'MatA' | 'MatB' | 'MatC' | 'MatD', MatrixData>;
  vectors: Record<'VctA' | 'VctB' | 'VctC', VectorData>;
  sheetGrid: string[][];
  onSelectMenu?: (idx: number) => void;
  onAction?: (action: string, payload?: unknown) => void;
}

function generatePseudoQrMatrix(text: string): boolean[][] {
  const size = 21;
  const grid: boolean[][] = Array.from({ length: size }, () => Array(size).fill(false));
  const drawFinder = (r0: number, c0: number) => {
    for (let r = 0; r < 7; r++) {
      for (let c = 0; c < 7; c++) {
        const border = r === 0 || r === 6 || c === 0 || c === 6;
        const inner = r >= 2 && r <= 4 && c >= 2 && c <= 4;
        grid[r0 + r][c0 + c] = border || inner;
      }
    }
  };
  drawFinder(0, 0);
  drawFinder(0, size - 7);
  drawFinder(size - 7, 0);

  let hash = 2166136261;
  for (let i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      const inFinder =
        (r < 8 && c < 8) || (r < 8 && c >= size - 8) || (r >= size - 8 && c < 8);
      if (inFinder) continue;
      if (r === 6 || c === 6) {
        grid[r][c] = (r + c) % 2 === 0;
        continue;
      }
      hash ^= (r * 31 + c * 17) & 0xff;
      hash = Math.imul(hash, 16777619);
      grid[r][c] = (hash & 1) === 1;
    }
  }
  return grid;
}

export const LcdScreen: React.FC<LcdProps> = ({
  isOff,
  shift,
  alpha,
  stoMode,
  rclMode,
  overwrite,
  mode,
  baseMode,
  settings,
  vars,
  screen,
  expr,
  cursor,
  result,
  history,
  historyIdx,
  showDecimal,
  showMixed,
  dmsView,
  engShift,
  statType,
  statRows,
  matrices,
  vectors,
  sheetGrid,
  onSelectMenu,
  onAction,
}) => {
  if (isOff) {
    return (
      <div className="calc-lcd-off w-full h-full rounded-[6px] transition-colors duration-150" />
    );
  }

  const hasMem = Math.abs(vars.M.re) > 1e-12 || Math.abs(vars.M.im) > 1e-12;
  const angleBadge = (u: AngleUnit) => (u === 'DEG' ? 'D' : u === 'RAD' ? 'R' : 'G');

  const modeBadge = () => {
    if (mode === 'BASE') return baseMode;
    if (mode === 'CMPLX') return 'i';
    if (mode === 'MATRIX') return 'MAT';
    if (mode === 'VECTOR') return 'VCT';
    if (mode === 'STAT') return 'STAT';
    if (mode === 'DIST') return 'DIST';
    if (mode === 'SHEET') return 'SHT';
    if (mode === 'TABLE') return 'TAB';
    if (mode === 'EQN') return 'EQN';
    if (mode === 'INEQ') return 'INEQ';
    if (mode === 'RATIO') return 'RATIO';
    return 'Math';
  };

  return (
    <div className="calc-lcd-screen w-full h-full rounded-[6px] flex flex-col overflow-hidden px-2 py-1 select-none">
      {/* Top Status Bar */}
      <div className="flex items-center justify-between h-[15px] border-b border-[#121713]/15 pb-[1px] shrink-0 text-[9px] font-lcd font-bold tracking-tight">
        <div className="flex items-center gap-[3px]">
          {shift && (
            <span className="bg-[#121713] text-[#d4e2d3] px-[3px] leading-[11px] rounded-[1px]">
              S
            </span>
          )}
          {alpha && (
            <span className="bg-[#121713] text-[#d4e2d3] px-[3px] leading-[11px] rounded-[1px]">
              A
            </span>
          )}
          {stoMode && <span className="border border-[#121713] px-[2px] leading-[10px]">STO</span>}
          {rclMode && <span className="border border-[#121713] px-[2px] leading-[10px]">RCL</span>}
          {hasMem && <span className="px-[2px] leading-[11px]">M</span>}
          <span className="bg-[#121713] text-[#d4e2d3] px-[3px] leading-[11px] rounded-[1px]">
            {angleBadge(settings.angleUnit)}
          </span>
          {settings.numberFormat !== 'NORM1' && settings.numberFormat !== 'NORM2' && (
            <span className="bg-[#121713] text-[#d4e2d3] px-[3px] leading-[11px] rounded-[1px]">
              {settings.numberFormat}
            </span>
          )}
          <span className="px-[2px] leading-[11px]">{modeBadge()}</span>
        </div>
        <div className="flex items-center gap-1 text-[8px] opacity-80">
          {history.length > 0 && screen.type === 'CALC' && (
            <span>{historyIdx >= 0 ? `▲▼ ${historyIdx + 1}/${history.length}` : '▲'}</span>
          )}
          <span>▼</span>
        </div>
      </div>

      {/* Main LCD Viewport */}
      <div className="flex-1 min-h-0 flex flex-col justify-between pt-1 overflow-hidden">
        {screen.type === 'CALC' && (
          <>
            <div className="flex-1 min-h-0 overflow-y-auto lcd-scroll pr-0.5 flex flex-col justify-start">
              <div className="min-h-[24px] flex items-center flex-wrap">
                <MathListView nodes={expr} cursor={cursor} path={[]} overwrite={overwrite} />
              </div>
            </div>
            <div className="shrink-0 pt-0.5 flex items-end justify-end min-h-[26px]">
              <ResultView
                result={result}
                settings={settings}
                baseMode={baseMode}
                showDecimal={showDecimal}
                showMixed={showMixed}
                dmsView={dmsView}
                engShift={engShift}
              />
            </div>
          </>
        )}

        {screen.type === 'MENU' && (
          <div className="flex flex-col h-full justify-between">
            <div className="grid grid-cols-4 gap-1 flex-1 items-center">
              {MENU_ITEMS.map((item, idx) => {
                const active = screen.selected === idx;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onSelectMenu?.(idx)}
                    className={`flex flex-col items-center justify-center rounded-[2px] py-[2px] px-0.5 border transition-colors ${
                      active
                        ? 'bg-[#121713] text-[#d4e2d3] border-[#121713]'
                        : 'border-[#121713]/25 text-[#121713] hover:bg-[#121713]/10'
                    }`}
                  >
                    <span className="text-[10px] font-lcd font-bold leading-none">
                      {item.keyLabel}:{item.glyph}
                    </span>
                  </button>
                );
              })}
            </div>
            <div className="text-[10px] font-lcd font-bold text-center border-t border-[#121713]/20 pt-[1px]">
              {MENU_ITEMS[screen.selected]?.keyLabel}: {MENU_ITEMS[screen.selected]?.title}
            </div>
          </div>
        )}

        {screen.type === 'SETUP' && (
          <div className="font-lcd text-[10px] leading-[1.35] flex flex-col justify-between h-full">
            {screen.page === 0 ? (
              <div className="grid grid-cols-1 gap-[1px]">
                <div className="font-bold border-b border-[#121713]/25 flex justify-between">
                  <span>SETUP (1/2)</span>
                  <span>▼</span>
                </div>
                <button type="button" onClick={() => onAction?.('SETUP_ITEM', 'ANGLE')} className="text-left hover:bg-[#121713]/10 px-0.5 flex justify-between">
                  <span>1:Angle Unit</span>
                  <span className="font-bold">{settings.angleUnit}</span>
                </button>
                <button type="button" onClick={() => onAction?.('SETUP_ITEM', 'FORMAT')} className="text-left hover:bg-[#121713]/10 px-0.5 flex justify-between">
                  <span>2:Number Format</span>
                  <span className="font-bold">{settings.numberFormat}</span>
                </button>
                <button type="button" onClick={() => onAction?.('SETUP_ITEM', 'FRAC')} className="text-left hover:bg-[#121713]/10 px-0.5 flex justify-between">
                  <span>3:Fraction Result</span>
                  <span className="font-bold">{settings.fractionDisplay === 'IMPROPER' ? 'd/c' : 'ab/c'}</span>
                </button>
                <button type="button" onClick={() => onAction?.('SETUP_ITEM', 'CMPLX')} className="text-left hover:bg-[#121713]/10 px-0.5 flex justify-between">
                  <span>4:Complex</span>
                  <span className="font-bold">{settings.complexFormat === 'RECT' ? 'a+bi' : 'r∠θ'}</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-[1px]">
                <div className="font-bold border-b border-[#121713]/25 flex justify-between">
                  <span>SETUP (2/2)</span>
                  <span>▲</span>
                </div>
                <button type="button" onClick={() => onAction?.('SETUP_ITEM', 'ENG')} className="text-left hover:bg-[#121713]/10 px-0.5 flex justify-between">
                  <span>5:Engineer Symbol</span>
                  <span className="font-bold">{settings.engSymbol ? 'On' : 'Off'}</span>
                </button>
                <button type="button" onClick={() => onAction?.('SETUP_ITEM', 'DECMARK')} className="text-left hover:bg-[#121713]/10 px-0.5 flex justify-between">
                  <span>6:Decimal Mark</span>
                  <span className="font-bold">{settings.decimalMark === 'DOT' ? 'Dot (.)' : 'Comma (,)'}</span>
                </button>
                <button type="button" onClick={() => onAction?.('SETUP_ITEM', 'DIGITSEP')} className="text-left hover:bg-[#121713]/10 px-0.5 flex justify-between">
                  <span>7:Digit Separator</span>
                  <span className="font-bold">{settings.digitSeparator ? 'On' : 'Off'}</span>
                </button>
                <button type="button" onClick={() => onAction?.('SETUP_ITEM', 'SOUND')} className="text-left hover:bg-[#121713]/10 px-0.5 flex justify-between">
                  <span>8:Key Click Sound</span>
                  <span className="font-bold">{settings.soundEnabled ? 'On' : 'Off'}</span>
                </button>
              </div>
            )}
          </div>
        )}

        {screen.type === 'OPTN' && (
          <div className="font-lcd text-[10px] leading-[1.3] overflow-y-auto lcd-scroll h-full">
            {mode === 'COMP' && (
              <div className="grid grid-cols-2 gap-x-2 gap-y-[1px]">
                <div className="col-span-2 font-bold border-b border-[#121713]/25">OPTION</div>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'sinh(')} className="text-left hover:bg-[#121713]/10">1:sinh(</button>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'cosh(')} className="text-left hover:bg-[#121713]/10">2:cosh(</button>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'tanh(')} className="text-left hover:bg-[#121713]/10">3:tanh(</button>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'sinh⁻¹(')} className="text-left hover:bg-[#121713]/10">4:sinh⁻¹(</button>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', '°')} className="text-left hover:bg-[#121713]/10">5:° (deg)</button>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', 'ʳ')} className="text-left hover:bg-[#121713]/10">6:ʳ (rad)</button>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', 'ᵍ')} className="text-left hover:bg-[#121713]/10">7:ᵍ (gra)</button>
                <button type="button" onClick={() => onAction?.('OPEN_KEYS_HELP')} className="text-left hover:bg-[#121713]/10">8:Key Map</button>
              </div>
            )}
            {mode === 'CMPLX' && (
              <div className="grid grid-cols-2 gap-x-2 gap-y-[2px]">
                <div className="col-span-2 font-bold border-b border-[#121713]/25">COMPLEX OPTN</div>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'Arg(')} className="text-left hover:bg-[#121713]/10">1:Arg(</button>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'Conjg(')} className="text-left hover:bg-[#121713]/10">2:Conjg(</button>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'ReP(')} className="text-left hover:bg-[#121713]/10">3:ReP(</button>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'ImP(')} className="text-left hover:bg-[#121713]/10">4:ImP(</button>
                <button type="button" onClick={() => onAction?.('SET_CMPLX_FMT', 'POLAR')} className="text-left hover:bg-[#121713]/10">5:▶r∠θ</button>
                <button type="button" onClick={() => onAction?.('SET_CMPLX_FMT', 'RECT')} className="text-left hover:bg-[#121713]/10">6:▶a+bi</button>
              </div>
            )}
            {mode === 'BASE' && (
              <div className="grid grid-cols-2 gap-x-2 gap-y-[2px]">
                <div className="col-span-2 font-bold border-b border-[#121713]/25">BASE-N OPTN</div>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', 'and')} className="text-left hover:bg-[#121713]/10">1:and</button>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', 'or')} className="text-left hover:bg-[#121713]/10">2:or</button>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', 'xor')} className="text-left hover:bg-[#121713]/10">3:xor</button>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', 'xnor')} className="text-left hover:bg-[#121713]/10">4:xnor</button>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'Not(')} className="text-left hover:bg-[#121713]/10">5:Not(</button>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'Neg(')} className="text-left hover:bg-[#121713]/10">6:Neg(</button>
              </div>
            )}
            {mode === 'MATRIX' && (
              <div className="grid grid-cols-2 gap-x-2 gap-y-[1px]">
                <div className="col-span-2 font-bold border-b border-[#121713]/25">MATRIX OPTN</div>
                <button type="button" onClick={() => onAction?.('MAT_OPTN', 'DIM')} className="text-left hover:bg-[#121713]/10">1:Define Mat</button>
                <button type="button" onClick={() => onAction?.('MAT_OPTN', 'EDIT')} className="text-left hover:bg-[#121713]/10">2:Edit Mat</button>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', 'MatA')} className="text-left hover:bg-[#121713]/10">3:MatA</button>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', 'MatB')} className="text-left hover:bg-[#121713]/10">4:MatB</button>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', 'MatC')} className="text-left hover:bg-[#121713]/10">5:MatC</button>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'Det(')} className="text-left hover:bg-[#121713]/10">6:Det(</button>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'Trn(')} className="text-left hover:bg-[#121713]/10">7:Trn(</button>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'Identity(')} className="text-left hover:bg-[#121713]/10">8:Identity(</button>
              </div>
            )}
            {mode === 'VECTOR' && (
              <div className="grid grid-cols-2 gap-x-2 gap-y-[1px]">
                <div className="col-span-2 font-bold border-b border-[#121713]/25">VECTOR OPTN</div>
                <button type="button" onClick={() => onAction?.('VCT_OPTN', 'EDIT')} className="text-left hover:bg-[#121713]/10">1:Edit Vct</button>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', 'VctA')} className="text-left hover:bg-[#121713]/10">2:VctA</button>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', 'VctB')} className="text-left hover:bg-[#121713]/10">3:VctB</button>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', 'VctC')} className="text-left hover:bg-[#121713]/10">4:VctC</button>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', 'DotP')} className="text-left hover:bg-[#121713]/10">5:DotP(·)</button>
                <button type="button" onClick={() => onAction?.('INSERT_CHAR', 'CrossP')} className="text-left hover:bg-[#121713]/10">6:CrossP(×)</button>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'Angle(')} className="text-left hover:bg-[#121713]/10">7:Angle(</button>
                <button type="button" onClick={() => onAction?.('INSERT_FUNC', 'UnitV(')} className="text-left hover:bg-[#121713]/10">8:UnitV(</button>
              </div>
            )}
            {mode === 'STAT' && (
              <div className="grid grid-cols-1 gap-[2px]">
                <div className="font-bold border-b border-[#121713]/25">STAT OPTN</div>
                <button type="button" onClick={() => onAction?.('STAT_OPTN', 'TYPE')} className="text-left hover:bg-[#121713]/10">1:Select Type</button>
                <button type="button" onClick={() => onAction?.('STAT_OPTN', 'EDITOR')} className="text-left hover:bg-[#121713]/10">2:Data Editor</button>
                <button type="button" onClick={() => onAction?.('STAT_OPTN', '1VAR')} className="text-left hover:bg-[#121713]/10">3:1-Variable Calc</button>
                <button type="button" onClick={() => onAction?.('STAT_OPTN', 'REG')} className="text-left hover:bg-[#121713]/10">4:Regression Calc</button>
              </div>
            )}
            {!['COMP', 'CMPLX', 'BASE', 'MATRIX', 'VECTOR', 'STAT'].includes(mode) && (
              <div className="text-center py-3">Press AC to return</div>
            )}
          </div>
        )}

        {screen.type === 'CONST' && (
          <div className="font-lcd text-[10px] leading-[1.3] overflow-y-auto lcd-scroll h-full">
            {screen.category === undefined ? (
              <div className="grid grid-cols-1 gap-[1px]">
                <div className="font-bold border-b border-[#121713]/25">SCIENTIFIC CONST</div>
                {CONST_CATEGORIES.map((cat, idx) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => onAction?.('CONST_CAT', idx)}
                    className="text-left hover:bg-[#121713]/10 px-0.5"
                  >
                    {idx + 1}:{cat}
                  </button>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-[1px]">
                <div className="font-bold border-b border-[#121713]/25 flex justify-between">
                  <span>{CONST_CATEGORIES[screen.category]}</span>
                  <button type="button" onClick={() => onAction?.('CONST_CAT', undefined)}>◀Back</button>
                </div>
                {SCIENTIFIC_CONSTANTS.filter((c) => c.category === CONST_CATEGORIES[screen.category!]).map((c) => (
                  <button
                    key={c.code}
                    type="button"
                    onClick={() => onAction?.('INSERT_CONST', c)}
                    className="text-left hover:bg-[#121713]/10 px-0.5 flex justify-between"
                  >
                    <span>{c.symbol} ({c.name})</span>
                    <span className="opacity-75">{c.unit}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {screen.type === 'CONV' && (
          <div className="font-lcd text-[10px] leading-[1.3] overflow-y-auto lcd-scroll h-full">
            {screen.category === undefined ? (
              <div className="grid grid-cols-2 gap-x-2 gap-y-[1px]">
                <div className="col-span-2 font-bold border-b border-[#121713]/25">CONVERSION</div>
                {CONV_CATEGORIES.map((cat, idx) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => onAction?.('CONV_CAT', idx)}
                    className="text-left hover:bg-[#121713]/10 px-0.5"
                  >
                    {idx + 1}:{cat}
                  </button>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-[1px]">
                <div className="font-bold border-b border-[#121713]/25 flex justify-between">
                  <span>{CONV_CATEGORIES[screen.category]}</span>
                  <button type="button" onClick={() => onAction?.('CONV_CAT', undefined)}>◀Back</button>
                </div>
                {UNIT_CONVERSIONS.filter((u) => u.category === CONV_CATEGORIES[screen.category!]).map((u) => (
                  <button
                    key={u.code}
                    type="button"
                    onClick={() => onAction?.('APPLY_CONV', u)}
                    className="text-left hover:bg-[#121713]/10 px-0.5 flex justify-between"
                  >
                    <span>{u.code}:{u.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {screen.type === 'RESET' && (
          <div className="font-lcd text-[10.5px] leading-[1.4]">
            {!screen.confirm ? (
              <>
                <div className="font-bold border-b border-[#121713]/25 mb-1">Reset</div>
                <button type="button" onClick={() => onAction?.('RESET_SELECT', 'SETUP')} className="block w-full text-left hover:bg-[#121713]/10">1:Setup Data</button>
                <button type="button" onClick={() => onAction?.('RESET_SELECT', 'MEM')} className="block w-full text-left hover:bg-[#121713]/10">2:Memory</button>
                <button type="button" onClick={() => onAction?.('RESET_SELECT', 'ALL')} className="block w-full text-left hover:bg-[#121713]/10">3:Initialize All</button>
              </>
            ) : (
              <div className="flex flex-col justify-between h-full py-1">
                <div className="font-bold">Reset {screen.confirm}?</div>
                <div className="flex justify-between mt-2">
                  <button type="button" onClick={() => onAction?.('RESET_CONFIRM', screen.confirm)} className="px-2 py-0.5 border border-[#121713] font-bold hover:bg-[#121713] hover:text-[#d4e2d3]">[=]:Yes</button>
                  <button type="button" onClick={() => onAction?.('RESET_CANCEL')} className="px-2 py-0.5 border border-[#121713] hover:bg-[#121713]/10">[AC]:Cancel</button>
                </div>
              </div>
            )}
          </div>
        )}

        {(screen.type === 'CALC_PROMPT' || screen.type === 'SOLVE_PROMPT') && (
          <div className="font-lcd text-[11px] flex flex-col justify-between h-full">
            <div className="font-bold border-b border-[#121713]/25">
              {screen.type === 'SOLVE_PROMPT' ? `SOLVE for ${screen.solveVar}` : 'CALC'}
            </div>
            <div className="py-1 flex justify-between items-center text-[13px]">
              <span>{screen.vars[screen.currentIdx]}?</span>
              <span className="font-bold border-b border-[#121713] min-w-[60px] text-right">
                {screen.values[screen.vars[screen.currentIdx]] ?? '0'}
                <span className="lcd-cursor-blink">|</span>
              </span>
            </div>
            <div className="text-[9px] opacity-80 flex justify-between">
              <span>Enter value & press [=]</span>
              <span>{screen.currentIdx + 1}/{screen.vars.length}</span>
            </div>
          </div>
        )}

        {screen.type === 'STAT_SELECT' && (
          <div className="font-lcd text-[10px] grid grid-cols-2 gap-x-2 gap-y-[1px] overflow-y-auto lcd-scroll">
            <div className="col-span-2 font-bold border-b border-[#121713]/25">Statistics</div>
            {(
              [
                ['1-VAR', '1:1-Variable'],
                ['LINEAR', '2:y=a+bx'],
                ['QUAD', '3:y=a+bx+cx²'],
                ['LOG', '4:y=a+b·ln(x)'],
                ['E_EXP', '5:y=a·e^(bx)'],
                ['AB_EXP', '6:y=a·b^x'],
                ['POWER', '7:y=a·x^b'],
                ['INV', '8:y=a+b/x'],
              ] as const
            ).map(([t, label]) => (
              <button
                key={t}
                type="button"
                onClick={() => onAction?.('STAT_TYPE', t)}
                className="text-left hover:bg-[#121713]/10 px-0.5"
              >
                {label}
              </button>
            ))}
          </div>
        )}

        {screen.type === 'STAT_EDITOR' && (
          <div className="font-lcd text-[10px] flex flex-col h-full">
            <div className="grid grid-cols-3 border-b border-[#121713] font-bold text-center">
              <span>#</span>
              <span>x</span>
              <span>{statType === '1-VAR' ? 'Freq' : 'y'}</span>
            </div>
            <div className="flex-1 overflow-y-auto lcd-scroll">
              {Array.from({ length: Math.max(statRows.length + 1, 4) }, (_, r) => {
                const row = statRows[r];
                const isCurX = screen.row === r && screen.col === 0;
                const isCurY = screen.row === r && screen.col === 1;
                return (
                  <div key={r} className="grid grid-cols-3 border-b border-[#121713]/15 text-right">
                    <span className="text-center opacity-70">{r + 1}</span>
                    <button
                      type="button"
                      onClick={() => onAction?.('STAT_CELL', { r, c: 0 })}
                      className={`px-1 text-right ${isCurX ? 'bg-[#121713] text-[#d4e2d3]' : ''}`}
                    >
                      {isCurX ? screen.input || (row ? row.x : '_') : row ? row.x : ''}
                    </button>
                    <button
                      type="button"
                      onClick={() => onAction?.('STAT_CELL', { r, c: 1 })}
                      className={`px-1 text-right ${isCurY ? 'bg-[#121713] text-[#d4e2d3]' : ''}`}
                    >
                      {isCurY
                        ? screen.input || (row ? (statType === '1-VAR' ? row.freq : row.y) : '_')
                        : row
                        ? statType === '1-VAR'
                          ? row.freq
                          : row.y
                        : ''}
                    </button>
                  </div>
                );
              })}
            </div>
            <div className="text-[8.5px] border-t border-[#121713]/25 flex justify-between pt-[1px]">
              <span>[=]:Set</span>
              <button type="button" onClick={() => onAction?.('STAT_OPTN', '1VAR')} className="underline font-bold">
                [OPTN]:Calc
              </button>
            </div>
          </div>
        )}

        {screen.type === 'STAT_RESULT' && (() => {
          const sum = computeStatistics(statRows, statType, settings.statFrequency);
          if (!sum) return <div className="font-lcd text-[11px] text-center py-4">Data Error (Empty)</div>;
          const lines =
            screen.mode === '1-VAR'
              ? [
                  `x̄ = ${formatRealNumber(sum.meanX, settings)}`,
                  `Σx = ${formatRealNumber(sum.sumX, settings)}`,
                  `Σx² = ${formatRealNumber(sum.sumX2, settings)}`,
                  `σx = ${formatRealNumber(sum.popStdX, settings)}`,
                  `sx = ${formatRealNumber(sum.sampStdX, settings)}`,
                  `n = ${sum.n}`,
                  `minX = ${formatRealNumber(sum.minX, settings)}`,
                  `Q1 = ${formatRealNumber(sum.q1, settings)}`,
                  `Med = ${formatRealNumber(sum.med, settings)}`,
                  `Q3 = ${formatRealNumber(sum.q3, settings)}`,
                  `maxX = ${formatRealNumber(sum.maxX, settings)}`,
                ]
              : [
                  `a = ${sum.regCoeffs ? formatRealNumber(sum.regCoeffs.a, settings) : 'ERR'}`,
                  `b = ${sum.regCoeffs ? formatRealNumber(sum.regCoeffs.b, settings) : 'ERR'}`,
                  ...(sum.regCoeffs?.c !== undefined ? [`c = ${formatRealNumber(sum.regCoeffs.c, settings)}`] : []),
                  ...(sum.regCoeffs?.r !== undefined ? [`r = ${formatRealNumber(sum.regCoeffs.r, settings)}`] : []),
                  `n = ${sum.n}`,
                ];
          const start = screen.page * 4;
          return (
            <div className="font-lcd text-[10px] leading-[1.35] flex flex-col justify-between h-full">
              <div>
                <div className="font-bold border-b border-[#121713]/25 flex justify-between">
                  <span>{screen.mode === '1-VAR' ? '1-Variable' : `Reg (${statType})`}</span>
                  <span>▲▼</span>
                </div>
                {lines.slice(start, start + 4).map((l) => (
                  <div key={l}>{l}</div>
                ))}
              </div>
              <div className="text-[8.5px] opacity-75 text-right">OPTN:Menu · AC:Back</div>
            </div>
          );
        })()}

        {screen.type === 'MATRIX_SELECT' && (
          <div className="font-lcd text-[10.5px] leading-[1.35]">
            <div className="font-bold border-b border-[#121713]/25">
              {screen.action === 'DIM' ? 'Define Matrix' : 'Edit Matrix'}
            </div>
            {(['MatA', 'MatB', 'MatC', 'MatD'] as const).map((m, i) => (
              <button
                key={m}
                type="button"
                onClick={() => onAction?.('MAT_PICK', m)}
                className="block w-full text-left hover:bg-[#121713]/10"
              >
                {i + 1}:{m} ({matrices[m].length}×{matrices[m][0]?.length ?? 0})
              </button>
            ))}
          </div>
        )}

        {screen.type === 'MATRIX_DIM' && (
          <div className="font-lcd text-[10.5px]">
            <div className="font-bold border-b border-[#121713]/25 mb-1">
              {screen.target}: {screen.step === 'ROWS' ? 'Number of Rows?' : 'Number of Cols?'} (1-4)
            </div>
            <div className="flex gap-2 mt-2">
              {[1, 2, 3, 4].map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => onAction?.('MAT_DIM_PICK', d)}
                  className="px-2 py-1 border border-[#121713] font-bold hover:bg-[#121713] hover:text-[#d4e2d3]"
                >
                  {d}
                </button>
              ))}
            </div>
          </div>
        )}

        {screen.type === 'MATRIX_EDIT' && (() => {
          const mat = matrices[screen.target];
          return (
            <div className="font-lcd text-[10px] flex flex-col h-full justify-between">
              <div className="font-bold border-b border-[#121713]/25 flex justify-between">
                <span>{screen.target} [{screen.r + 1},{screen.c + 1}]</span>
                <button type="button" onClick={() => onAction?.('TO_CALC_FROM_EDITOR')} className="underline">OPTN/AC:Calc</button>
              </div>
              <div className="grid gap-1 my-1" style={{ gridTemplateColumns: `repeat(${mat[0].length}, minmax(0, 1fr))` }}>
                {mat.map((row, r) =>
                  row.map((val, c) => {
                    const active = r === screen.r && c === screen.c;
                    return (
                      <button
                        key={`${r}-${c}`}
                        type="button"
                        onClick={() => onAction?.('MAT_CELL', { r, c })}
                        className={`border px-1 text-right truncate ${
                          active ? 'bg-[#121713] text-[#d4e2d3] border-[#121713]' : 'border-[#121713]/30'
                        }`}
                      >
                        {active ? screen.input || val : val}
                      </button>
                    );
                  })
                )}
              </div>
              <div className="text-[8.5px] opacity-80">Enter number + [=] · OPTN for ops</div>
            </div>
          );
        })()}

        {screen.type === 'VECTOR_SELECT' && (
          <div className="font-lcd text-[10.5px] leading-[1.4]">
            <div className="font-bold border-b border-[#121713]/25">Define/Edit Vector</div>
            {(['VctA', 'VctB', 'VctC'] as const).map((v, i) => (
              <button
                key={v}
                type="button"
                onClick={() => onAction?.('VCT_PICK', v)}
                className="block w-full text-left hover:bg-[#121713]/10"
              >
                {i + 1}:{v} ({vectors[v].length}D)
              </button>
            ))}
          </div>
        )}

        {screen.type === 'VECTOR_DIM' && (
          <div className="font-lcd text-[10.5px]">
            <div className="font-bold border-b border-[#121713]/25 mb-2">{screen.target}: Dimension?</div>
            <div className="flex gap-3">
              {[2, 3].map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => onAction?.('VCT_DIM_PICK', d)}
                  className="px-3 py-1 border border-[#121713] font-bold hover:bg-[#121713] hover:text-[#d4e2d3]"
                >
                  {d}D
                </button>
              ))}
            </div>
          </div>
        )}

        {screen.type === 'VECTOR_EDIT' && (() => {
          const v = vectors[screen.target];
          return (
            <div className="font-lcd text-[10.5px] flex flex-col h-full justify-between">
              <div className="font-bold border-b border-[#121713]/25 flex justify-between">
                <span>{screen.target} [{screen.idx + 1}]</span>
                <button type="button" onClick={() => onAction?.('TO_CALC_FROM_EDITOR')} className="underline">AC:Calc</button>
              </div>
              <div className="grid grid-cols-3 gap-1 my-1">
                {v.map((val, i) => {
                  const active = i === screen.idx;
                  return (
                    <button
                      key={i}
                      type="button"
                      onClick={() => onAction?.('VCT_CELL', i)}
                      className={`border px-1 py-0.5 text-right ${
                        active ? 'bg-[#121713] text-[#d4e2d3] border-[#121713]' : 'border-[#121713]/30'
                      }`}
                    >
                      {active ? screen.input || val : val}
                    </button>
                  );
                })}
              </div>
              <div className="text-[8.5px] opacity-80">Enter value + [=] · OPTN for Dot/Cross</div>
            </div>
          );
        })()}

        {screen.type === 'TABLE_SETUP' && (
          <div className="font-lcd text-[11px] flex flex-col justify-between h-full">
            <div className="font-bold border-b border-[#121713]/25">
              Table: {screen.step === 'F' ? 'f(x) =' : screen.step === 'G' ? 'g(x) =' : `Table Range (${screen.step})`}
            </div>
            {(screen.step === 'F' || screen.step === 'G') ? (
              <div className="flex-1 flex items-center">
                <span className="mr-1 font-bold">{screen.step === 'F' ? 'f(x)=' : 'g(x)='}</span>
                <MathListView
                  nodes={screen.step === 'F' ? screen.fExpr : screen.gExpr}
                  cursor={cursor}
                  path={[]}
                  overwrite={overwrite}
                />
              </div>
            ) : (
              <div className="space-y-0.5 text-[10.5px]">
                <div className={screen.step === 'START' ? 'font-bold bg-[#121713]/10 px-1' : 'px-1'}>Start: {screen.start}</div>
                <div className={screen.step === 'END' ? 'font-bold bg-[#121713]/10 px-1' : 'px-1'}>End: {screen.end}</div>
                <div className={screen.step === 'STEP' ? 'font-bold bg-[#121713]/10 px-1' : 'px-1'}>Step: {screen.stepVal}</div>
              </div>
            )}
            <div className="text-[8.5px] opacity-75 text-right">[=]:Next</div>
          </div>
        )}

        {screen.type === 'TABLE_VIEW' && (
          <div className="font-lcd text-[10px] flex flex-col h-full">
            <div className={`grid ${screen.showG ? 'grid-cols-3' : 'grid-cols-2'} border-b border-[#121713] font-bold text-right px-1`}>
              <span>x</span>
              <span>f(x)</span>
              {screen.showG && <span>g(x)</span>}
            </div>
            <div className="flex-1 overflow-y-auto lcd-scroll">
              {screen.rows.slice(screen.scroll, screen.scroll + 4).map((r, i) => (
                <div key={i} className={`grid ${screen.showG ? 'grid-cols-3' : 'grid-cols-2'} border-b border-[#121713]/15 text-right px-1`}>
                  <span>{formatRealNumber(r.x, settings)}</span>
                  <span>{r.fx}</span>
                  {screen.showG && <span>{r.gx}</span>}
                </div>
              ))}
            </div>
          </div>
        )}

        {screen.type === 'EQN_MENU' && (
          <div className="font-lcd text-[11px] leading-[1.5]">
            <div className="font-bold border-b border-[#121713]/25 mb-1">Equation/Func</div>
            <button type="button" onClick={() => onAction?.('EQN_KIND', 'SIMUL')} className="block w-full text-left hover:bg-[#121713]/10">1:Simul Equation</button>
            <button type="button" onClick={() => onAction?.('EQN_KIND', 'POLY')} className="block w-full text-left hover:bg-[#121713]/10">2:Polynomial</button>
          </div>
        )}

        {screen.type === 'EQN_DIM' && (
          <div className="font-lcd text-[10.5px]">
            <div className="font-bold border-b border-[#121713]/25 mb-2">
              {screen.kind === 'SIMUL' ? 'Number of Unknowns?' : 'Polynomial Degree?'}
            </div>
            <div className="flex gap-2">
              {[2, 3, 4].map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => onAction?.('EQN_DEGREE', d)}
                  className="px-2.5 py-1 border border-[#121713] font-bold hover:bg-[#121713] hover:text-[#d4e2d3]"
                >
                  {d}
                </button>
              ))}
            </div>
          </div>
        )}

        {screen.type === 'EQN_INPUT' && (
          <div className="font-lcd text-[10px] flex flex-col h-full justify-between">
            <div className="font-bold border-b border-[#121713]/25">
              {screen.kind === 'SIMUL' ? `Eqn ${screen.r + 1}, Coeff ${screen.c < screen.degree ? ['x', 'y', 'z', 't'][screen.c] : 'const'}` : `Poly Deg ${screen.degree}`}
            </div>
            <div className="overflow-x-auto">
              {screen.kind === 'SIMUL' ? (
                <div className="space-y-0.5">
                  {screen.coeffs.map((row, r) => (
                    <div key={r} className="flex gap-1">
                      {row.map((val, c) => {
                        const active = r === screen.r && c === screen.c;
                        return (
                          <button
                            key={c}
                            type="button"
                            onClick={() => onAction?.('EQN_CELL', { r, c })}
                            className={`border px-1 min-w-[26px] text-right ${
                              active ? 'bg-[#121713] text-[#d4e2d3] border-[#121713]' : 'border-[#121713]/30'
                            }`}
                          >
                            {active ? screen.input || val : val}
                          </button>
                        );
                      })}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-wrap gap-1 items-center">
                  {screen.coeffs[0].map((val, c) => {
                    const active = screen.c === c;
                    const pwr = screen.degree - c;
                    return (
                      <div key={c} className="flex items-center gap-0.5">
                        <button
                          type="button"
                          onClick={() => onAction?.('EQN_CELL', { r: 0, c })}
                          className={`border px-1 min-w-[26px] text-right ${
                            active ? 'bg-[#121713] text-[#d4e2d3] border-[#121713]' : 'border-[#121713]/30'
                          }`}
                        >
                          {active ? screen.input || val : val}
                        </button>
                        {pwr > 0 && <span>x{pwr > 1 ? `^${pwr}` : ''}</span>}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
            <div className="text-[8.5px] opacity-80">Enter coeff + [=]</div>
          </div>
        )}

        {screen.type === 'EQN_RESULT' && (
          <div className="font-lcd text-[10.5px] flex flex-col justify-between h-full">
            <div>
              <div className="font-bold border-b border-[#121713]/25">Solution</div>
              {screen.lines.slice(screen.scroll, screen.scroll + 3).map((l) => (
                <div key={l.label} className="flex justify-between py-[1px]">
                  <span>{l.label} =</span>
                  <span className="font-bold">{l.value}</span>
                </div>
              ))}
            </div>
            <div className="text-[8.5px] opacity-75 text-right">▲▼ Scroll · [=]:Re-edit</div>
          </div>
        )}

        {screen.type === 'INEQ_DEGREE' && (
          <div className="font-lcd text-[10.5px]">
            <div className="font-bold border-b border-[#121713]/25 mb-2">Inequality Degree?</div>
            <div className="flex gap-3">
              {[2, 3].map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => onAction?.('INEQ_DEG', d)}
                  className="px-3 py-1 border border-[#121713] font-bold hover:bg-[#121713] hover:text-[#d4e2d3]"
                >
                  Deg {d}
                </button>
              ))}
            </div>
          </div>
        )}

        {screen.type === 'INEQ_OP' && (
          <div className="font-lcd text-[10.5px]">
            <div className="font-bold border-b border-[#121713]/25 mb-1">Select Inequality</div>
            <div className="grid grid-cols-2 gap-1">
              {(['>', '<', '≥', '≤'] as const).map((op, i) => (
                <button
                  key={op}
                  type="button"
                  onClick={() => onAction?.('INEQ_OP_PICK', op)}
                  className="border border-[#121713]/40 px-1 py-0.5 text-left hover:bg-[#121713] hover:text-[#d4e2d3]"
                >
                  {i + 1}: P(x) {op} 0
                </button>
              ))}
            </div>
          </div>
        )}

        {screen.type === 'INEQ_INPUT' && (
          <div className="font-lcd text-[10px] flex flex-col justify-between h-full">
            <div className="font-bold border-b border-[#121713]/25">Inequality (P(x) {screen.op} 0)</div>
            <div className="flex gap-1 items-center flex-wrap">
              {screen.coeffs.map((v, i) => {
                const active = i === screen.idx;
                return (
                  <button
                    key={i}
                    type="button"
                    onClick={() => onAction?.('INEQ_CELL', i)}
                    className={`border px-1.5 py-0.5 ${
                      active ? 'bg-[#121713] text-[#d4e2d3] border-[#121713]' : 'border-[#121713]/30'
                    }`}
                  >
                    {active ? screen.input || v : v}
                  </button>
                );
              })}
            </div>
            <div className="text-[8.5px] opacity-80">Enter coeff + [=]</div>
          </div>
        )}

        {screen.type === 'INEQ_RESULT' && (
          <div className="font-lcd text-[11px] flex flex-col justify-between h-full">
            <div className="font-bold border-b border-[#121713]/25">Solution</div>
            <div className="text-[12px] font-bold py-2 text-center break-words">{screen.text}</div>
            <div className="text-[8.5px] opacity-75 text-right">[AC]:New</div>
          </div>
        )}

        {screen.type === 'RATIO_TYPE' && (
          <div className="font-lcd text-[11px] leading-[1.6]">
            <div className="font-bold border-b border-[#121713]/25 mb-1">Ratio</div>
            <button type="button" onClick={() => onAction?.('RATIO_PICK', 'AB_XC')} className="block w-full text-left hover:bg-[#121713]/10">1: A : B = X : C</button>
            <button type="button" onClick={() => onAction?.('RATIO_PICK', 'AB_CX')} className="block w-full text-left hover:bg-[#121713]/10">2: A : B = C : X</button>
          </div>
        )}

        {screen.type === 'RATIO_INPUT' && (
          <div className="font-lcd text-[10.5px] flex flex-col justify-between h-full">
            <div className="font-bold border-b border-[#121713]/25">
              {screen.form === 'AB_XC' ? 'A : B = X : C' : 'A : B = C : X'}
            </div>
            <div className="grid grid-cols-3 gap-1">
              {(['A', 'B', 'C'] as const).map((lbl, i) => (
                <div key={lbl} className={`border px-1 py-0.5 ${screen.idx === i ? 'bg-[#121713] text-[#d4e2d3]' : 'border-[#121713]/30'}`}>
                  <div className="text-[8px]">{lbl}</div>
                  <div className="text-right font-bold">{screen.vals[i] || '0'}</div>
                </div>
              ))}
            </div>
            <div className="text-[8.5px] opacity-80">Enter value + [=]</div>
          </div>
        )}

        {screen.type === 'RATIO_RESULT' && (
          <div className="font-lcd text-[12px] flex flex-col justify-between h-full">
            <div className="font-bold border-b border-[#121713]/25">Ratio Result</div>
            <div className="text-right text-[16px] font-bold">X = {screen.x}</div>
            <div className="text-[8.5px] opacity-75 text-right">[=]:Re-edit</div>
          </div>
        )}

        {screen.type === 'DIST_MENU' && (
          <div className="font-lcd text-[10px] grid grid-cols-2 gap-x-2 gap-y-[1px] overflow-y-auto lcd-scroll">
            <div className="col-span-2 font-bold border-b border-[#121713]/25">Distribution</div>
            {(
              [
                ['NORMAL_PD', '1:Normal PD'],
                ['NORMAL_CD', '2:Normal CD'],
                ['INV_NORMAL', '3:Inverse Normal'],
                ['BINOMIAL_PD', '4:Binomial PD'],
                ['BINOMIAL_CD', '5:Binomial CD'],
                ['POISSON_PD', '6:Poisson PD'],
                ['POISSON_CD', '7:Poisson CD'],
              ] as const
            ).map(([d, label]) => (
              <button key={d} type="button" onClick={() => onAction?.('DIST_PICK', d)} className="text-left hover:bg-[#121713]/10">
                {label}
              </button>
            ))}
          </div>
        )}

        {screen.type === 'DIST_INPUT' && (
          <div className="font-lcd text-[10px] flex flex-col justify-between h-full">
            <div className="font-bold border-b border-[#121713]/25">{screen.dist.replace('_', ' ')}</div>
            <div className="space-y-0.5 overflow-y-auto lcd-scroll">
              {screen.fields.map((f, i) => (
                <div key={f.label} className={`flex justify-between px-1 ${i === screen.idx ? 'bg-[#121713] text-[#d4e2d3]' : ''}`}>
                  <span>{f.label}:</span>
                  <span className="font-bold">{f.value || '0'}</span>
                </div>
              ))}
            </div>
            <div className="text-[8.5px] opacity-80">Enter value + [=]</div>
          </div>
        )}

        {screen.type === 'DIST_RESULT' && (
          <div className="font-lcd text-[12px] flex flex-col justify-between h-full">
            <div className="font-bold border-b border-[#121713]/25">{screen.label}</div>
            <div className="text-right text-[16px] font-bold">p = {screen.value}</div>
            <div className="text-[8.5px] opacity-75 text-right">[=]:Re-edit</div>
          </div>
        )}

        {screen.type === 'SHEET_GRID' && (
          <div className="font-lcd text-[9.5px] flex flex-col h-full">
            <div className="grid grid-cols-5 border-b border-[#121713] font-bold text-center">
              <span>#</span>
              <span>A</span>
              <span>B</span>
              <span>C</span>
              <span>D</span>
            </div>
            <div className="flex-1 overflow-y-auto lcd-scroll">
              {sheetGrid.slice(Math.max(0, screen.r - 2), Math.max(0, screen.r - 2) + 4).map((row, idx) => {
                const r = Math.max(0, screen.r - 2) + idx;
                return (
                  <div key={r} className="grid grid-cols-5 border-b border-[#121713]/15 text-right">
                    <span className="text-center opacity-70">{r + 1}</span>
                    {[0, 1, 2, 3].map((c) => {
                      const active = r === screen.r && c === screen.c;
                      const evaluated = evalSpreadsheetCell(row[c], sheetGrid);
                      return (
                        <button
                          key={c}
                          type="button"
                          onClick={() => onAction?.('SHEET_CELL', { r, c })}
                          className={`px-0.5 truncate text-right ${active ? 'bg-[#121713] text-[#d4e2d3]' : ''}`}
                        >
                          {active && screen.editing ? screen.input || '_' : String(evaluated)}
                        </button>
                      );
                    })}
                  </div>
                );
              })}
            </div>
            <div className="text-[8.5px] border-t border-[#121713]/25 flex justify-between">
              <span>{String.fromCharCode(65 + screen.c)}{screen.r + 1}: {sheetGrid[screen.r]?.[screen.c] || '(empty)'}</span>
              <span>[=]:Set</span>
            </div>
          </div>
        )}

        {screen.type === 'QR_VIEW' && (() => {
          const qr = generatePseudoQrMatrix(screen.payload);
          return (
            <div className="flex items-center justify-between h-full px-1 gap-2">
              <div className="bg-white/75 p-1 border border-[#121713]">
                <div className="grid gap-0" style={{ gridTemplateColumns: `repeat(${qr.length}, 2.5px)` }}>
                  {qr.flatMap((row, r) =>
                    row.map((on, c) => (
                      <div key={`${r}-${c}`} className={`w-[2.5px] h-[2.5px] ${on ? 'bg-[#121713]' : 'bg-transparent'}`} />
                    ))
                  )}
                </div>
              </div>
              <div className="font-lcd text-[9px] flex-1 overflow-hidden">
                <div className="font-bold border-b border-[#121713]/30 mb-0.5">QR Code</div>
                <div className="break-all line-clamp-3 opacity-85">{screen.payload || 'fx-991EX'}</div>
                <div className="mt-1 opacity-70">Press AC/ESC</div>
              </div>
            </div>
          );
        })()}

        {screen.type === 'HELP_KEYS' && (
          <div className="font-lcd text-[9px] leading-[1.3] overflow-y-auto lcd-scroll">
            <div className="font-bold border-b border-[#121713]/25">PC Keyboard Shortcuts</div>
            <div>0-9 + - * / ^ ( ) : Numbers & Ops</div>
            <div>Enter / = : Execute · Esc : AC</div>
            <div>Backspace : DEL · Arrows : D-Pad</div>
            <div>Shift+S : SHIFT · Alt+A : ALPHA</div>
            <div>p : π · e : e · s/c/t : sin/cos/tan</div>
          </div>
        )}
      </div>
    </div>
  );
};
