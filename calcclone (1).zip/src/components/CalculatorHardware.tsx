import React from 'react';

export type KeyId =
  | 'SHIFT' | 'ALPHA' | 'MENU' | 'ON'
  | 'UP' | 'DOWN' | 'LEFT' | 'RIGHT'
  | 'OPTN' | 'CALC' | 'INTEGRAL' | 'VAR_X'
  | 'FRAC' | 'SQRT' | 'X2' | 'XPOW' | 'LOGBOX' | 'LN'
  | 'NEG' | 'DMS' | 'XINV' | 'SIN' | 'COS' | 'TAN'
  | 'STO' | 'ENG' | 'LPAREN' | 'RPAREN' | 'SD' | 'MPLUS'
  | '7' | '8' | '9' | 'DEL' | 'AC'
  | '4' | '5' | '6' | 'MUL' | 'DIV'
  | '1' | '2' | '3' | 'ADD' | 'SUB'
  | '0' | 'COMMA' | 'EXP10' | 'ANS' | 'EQ';

interface HardwareProps {
  onKey: (key: KeyId) => void;
  pressedKey?: KeyId | null;
  lcd: React.ReactNode;
}

const GOLD = '#d7a43b';
const RED = '#df4a64';
const BLUE = '#4aa7e0';

/* Tiny authentic math template glyphs for faceplate legends & keycaps */
const FracGlyph: React.FC<{ mixed?: boolean; small?: boolean }> = ({ mixed, small }) => (
  <span className={`inline-flex items-center justify-center leading-none ${small ? 'scale-[0.82]' : ''}`}>
    {mixed && <span className="inline-block w-[4px] h-[5px] bg-current mr-[1.5px] rounded-[0.5px]" />}
    <span className="inline-flex flex-col items-center">
      <span className={`inline-block border border-current rounded-[0.5px] ${small ? 'w-[5px] h-[4px]' : 'w-[8px] h-[5px] bg-current'}`} />
      <span className={`block bg-current my-[1.5px] ${small ? 'w-[8px] h-[1px]' : 'w-[12px] h-[1.2px]'}`} />
      <span className={`inline-block border border-current rounded-[0.5px] ${small ? 'w-[5px] h-[4px]' : 'w-[8px] h-[5px]'}`} />
    </span>
  </span>
);

const RootGlyph: React.FC<{ prefix?: '3' | 'box' | null; small?: boolean }> = ({ prefix, small }) => (
  <span className={`inline-flex items-end leading-none ${small ? 'text-[8px]' : 'text-[12px]'}`}>
    {prefix === '3' && <span className="text-[0.65em] font-bold -mr-[1px] mb-[4px]">3</span>}
    {prefix === 'box' && (
      <span className="inline-block w-[4px] h-[4px] border border-current mb-[5px] -mr-[1px]" />
    )}
    <span className="font-math leading-none">√</span>
    <span
      className={`border-t border-current inline-block mb-[1px] ${
        small ? 'w-[5px] h-[5px] pt-[1px]' : 'w-[8px] h-[8px] pt-[1.5px]'
      }`}
    >
      <span
        className={`block ${
          prefix === 'box' ? 'border border-current' : 'bg-current'
        } ${small ? 'w-[4px] h-[4px]' : 'w-[6px] h-[6px]'}`}
      />
    </span>
  </span>
);

interface LegendSpec {
  gold?: React.ReactNode;
  red?: React.ReactNode;
  blue?: React.ReactNode;
}

const KeyLegend: React.FC<{ legend?: LegendSpec; compact?: boolean }> = ({ legend, compact }) => {
  if (!legend) return <div className="h-[11px]" />;
  return (
    <div
      className={`h-[11px] w-full flex items-end justify-between px-[1px] leading-none font-semibold tracking-tight whitespace-nowrap ${
        compact ? 'text-[8px]' : 'text-[8.5px]'
      }`}
    >
      <span style={{ color: GOLD }} className="flex items-center">
        {legend.gold}
      </span>
      {legend.blue ? (
        <span style={{ color: BLUE }} className="flex items-center">
          {legend.blue}
        </span>
      ) : (
        <span style={{ color: RED }} className="flex items-center">
          {legend.red}
        </span>
      )}
    </div>
  );
};

export const CalculatorHardware: React.FC<HardwareProps> = ({ onKey, pressedKey, lcd }) => {
  const isDown = (id: KeyId) => (pressedKey === id ? 'is-pressed' : '');

  const SciButton: React.FC<{
    id: KeyId;
    legend?: LegendSpec;
    label: React.ReactNode;
    ariaLabel: string;
  }> = ({ id, legend, label, ariaLabel }) => (
    <div className="flex flex-col items-center">
      <KeyLegend legend={legend} />
      <button
        type="button"
        aria-label={ariaLabel}
        onClick={() => onKey(id)}
        className={`calc-btn-sci ${isDown(id)} w-full h-[27px] rounded-[5px] text-white flex items-center justify-center text-[11.5px] font-medium tracking-tight cursor-pointer`}
      >
        {label}
      </button>
    </div>
  );

  const MainButton: React.FC<{
    id: KeyId;
    legend?: LegendSpec;
    label: React.ReactNode;
    variant?: 'num' | 'blue';
    ariaLabel: string;
  }> = ({ id, legend, label, variant = 'num', ariaLabel }) => (
    <div className="flex flex-col items-center">
      <KeyLegend legend={legend} />
      <button
        type="button"
        aria-label={ariaLabel}
        onClick={() => onKey(id)}
        className={`${
          variant === 'blue' ? 'calc-btn-blue' : 'calc-btn-num'
        } ${isDown(id)} w-full h-[33px] rounded-[6px] flex items-center justify-center font-bold cursor-pointer`}
      >
        {label}
      </button>
    </div>
  );

  return (
    <div className="calc-outer-shell relative p-[5px] pb-[15px] rounded-[36px] w-[364px] select-none">
      {/* Main dark carbon-weave faceplate */}
      <div className="calc-carbon-faceplate relative rounded-[31px] px-[14px] pt-[12px] pb-[14px] overflow-hidden border border-black/80 shadow-inner">
        {/* Top Row: Empty left space + Right Solar Cell */}
        <div className="flex items-center justify-end mb-[9px] px-[2px]">
          <div className="calc-solar-cell w-[49%] h-[42px] rounded-[5px] border border-black/80" />
        </div>

        {/* Recessed Gloss Black LCD Bezel */}
        <div className="calc-lcd-bezel rounded-t-[11px] rounded-b-[18px] p-[9px] mb-[10px]">
          <div className="w-full h-[106px]">{lcd}</div>
        </div>

        {/* Upper Control Zone: Metallic Silver Buttons + Central 4-Way D-Pad + Row 1 Sci Keys */}
        <div className="relative grid grid-cols-6 gap-x-[7px] gap-y-[3px] items-end mb-[3px]">
          {/* Col 1, Top: SHIFT */}
          <div className="flex flex-col items-center pb-[3px]">
            <span style={{ color: GOLD }} className="text-[8.5px] font-bold tracking-tight mb-[4px] leading-none">
              SHIFT
            </span>
            <button
              type="button"
              aria-label="SHIFT"
              onClick={() => onKey('SHIFT')}
              className={`calc-btn-metallic ${isDown('SHIFT')} w-[26px] h-[26px] rounded-full border border-black/80 cursor-pointer`}
            />
          </div>

          {/* Col 2, Top: ALPHA */}
          <div className="flex flex-col items-center pb-[3px]">
            <span style={{ color: RED }} className="text-[8.5px] font-bold tracking-tight mb-[4px] leading-none">
              ALPHA
            </span>
            <button
              type="button"
              aria-label="ALPHA"
              onClick={() => onKey('ALPHA')}
              className={`calc-btn-metallic ${isDown('ALPHA')} w-[26px] h-[26px] rounded-full border border-black/80 cursor-pointer`}
            />
          </div>

          {/* Col 3-4, Spanning 2 rows: Central 4-Way Metallic D-Pad */}
          <div className="col-span-2 row-span-2 flex items-center justify-center self-center py-[2px]">
            <div className="relative w-[108px] h-[72px] rounded-[46%] bg-[#141518] shadow-[inset_0_2px_6px_rgba(0,0,0,0.95),0_1px_0_rgba(255,255,255,0.12)] flex items-center justify-center p-[3px]">
              <svg viewBox="0 0 120 80" className="w-full h-full overflow-visible">
                <defs>
                  <linearGradient id="dpadTop" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#a6aab2" />
                    <stop offset="45%" stopColor="#5c6068" />
                    <stop offset="100%" stopColor="#35383e" />
                  </linearGradient>
                  <linearGradient id="dpadBottom" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#35383e" />
                    <stop offset="55%" stopColor="#5c6068" />
                    <stop offset="100%" stopColor="#b0b4bc" />
                  </linearGradient>
                  <linearGradient id="dpadLeft" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#9fa3ab" />
                    <stop offset="50%" stopColor="#555860" />
                    <stop offset="100%" stopColor="#2f3238" />
                  </linearGradient>
                  <linearGradient id="dpadRight" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#2f3238" />
                    <stop offset="50%" stopColor="#555860" />
                    <stop offset="100%" stopColor="#a6aab2" />
                  </linearGradient>
                </defs>

                {/* UP */}
                <path
                  d="M27,19 C43,4 77,4 93,19 L74,31 C65,26 55,26 46,31 Z"
                  fill="url(#dpadTop)"
                  stroke="#0e0f12"
                  strokeWidth="1.5"
                  className={`cursor-pointer hover:brightness-110 active:brightness-90 ${pressedKey === 'UP' ? 'brightness-90' : ''}`}
                  onClick={() => onKey('UP')}
                />
                {/* DOWN */}
                <path
                  d="M27,61 C43,76 77,76 93,61 L74,49 C65,54 55,54 46,49 Z"
                  fill="url(#dpadBottom)"
                  stroke="#0e0f12"
                  strokeWidth="1.5"
                  className={`cursor-pointer hover:brightness-110 active:brightness-90 ${pressedKey === 'DOWN' ? 'brightness-90' : ''}`}
                  onClick={() => onKey('DOWN')}
                />
                {/* LEFT */}
                <path
                  d="M23,22 C6,32 6,48 23,58 L42,46 C37,42 37,38 42,34 Z"
                  fill="url(#dpadLeft)"
                  stroke="#0e0f12"
                  strokeWidth="1.5"
                  className={`cursor-pointer hover:brightness-110 active:brightness-90 ${pressedKey === 'LEFT' ? 'brightness-90' : ''}`}
                  onClick={() => onKey('LEFT')}
                />
                {/* RIGHT */}
                <path
                  d="M97,22 C114,32 114,48 97,58 L78,46 C83,42 83,38 78,34 Z"
                  fill="url(#dpadRight)"
                  stroke="#0e0f12"
                  strokeWidth="1.5"
                  className={`cursor-pointer hover:brightness-110 active:brightness-90 ${pressedKey === 'RIGHT' ? 'brightness-90' : ''}`}
                  onClick={() => onKey('RIGHT')}
                />
                {/* Center dark recess */}
                <ellipse cx="60" cy="40" rx="17" ry="11" fill="#18191d" stroke="#0c0d10" strokeWidth="1" />
              </svg>
            </div>
          </div>

          {/* Col 5, Top: MENU SETUP */}
          <div className="flex flex-col items-center pb-[3px]">
            <div className="text-[8px] font-bold tracking-tight mb-[4px] leading-none whitespace-nowrap">
              <span className="text-white/90 mr-[2px]">MENU</span>
              <span style={{ color: GOLD }}>SETUP</span>
            </div>
            <button
              type="button"
              aria-label="MENU SETUP"
              onClick={() => onKey('MENU')}
              className={`calc-btn-metallic ${isDown('MENU')} w-[26px] h-[26px] rounded-full border border-black/80 cursor-pointer`}
            />
          </div>

          {/* Col 6, Top: ON */}
          <div className="flex flex-col items-center pb-[3px]">
            <span className="text-white/90 text-[8.5px] font-bold tracking-tight mb-[4px] leading-none">
              ON
            </span>
            <button
              type="button"
              aria-label="ON"
              onClick={() => onKey('ON')}
              className={`calc-btn-metallic ${isDown('ON')} w-[26px] h-[26px] rounded-full border border-black/80 cursor-pointer`}
            />
          </div>

          {/* Row 1 Sci Flanking D-Pad: Col 1 OPTN, Col 2 CALC, Col 5 ∫, Col 6 x */}
          <SciButton
            id="OPTN"
            ariaLabel="OPTN / QR"
            legend={{ gold: <span className="mx-auto">QR</span> }}
            label={<span className="text-[11px] font-semibold">OPTN</span>}
          />
          <SciButton
            id="CALC"
            ariaLabel="CALC / SOLVE / ="
            legend={{ gold: 'SOLVE', red: '=' }}
            label={<span className="text-[11px] font-semibold">CALC</span>}
          />
          {/* Col 3-4 occupied by D-Pad row-span-2 */}
          <SciButton
            id="INTEGRAL"
            ariaLabel="Integral / Derivative"
            legend={{
              gold: (
                <span className="inline-flex flex-col items-center leading-[0.8] text-[7px]">
                  <span className="border-b border-current px-[1px]">d</span>
                  <span>dx</span>
                </span>
              ),
              red: ':',
            }}
            label={
              <span className="inline-flex items-center">
                <span className="font-math text-[16px] leading-none mr-[1px]">∫</span>
                <span className="inline-flex flex-col justify-between h-[14px] mr-[1.5px]">
                  <span className="w-[4px] h-[4px] border border-white/85" />
                  <span className="w-[4px] h-[4px] border border-white/85" />
                </span>
                <span className="w-[6px] h-[8px] bg-white/90 rounded-[0.5px]" />
              </span>
            }
          />
          <SciButton
            id="VAR_X"
            ariaLabel="x variable / Sum / Product"
            legend={{ gold: 'Σ', red: 'Π' }}
            label={<span className="font-math italic text-[16px] leading-none">x</span>}
          />
        </div>

        {/* Scientific Grid Rows 2, 3, 4 (6 columns) */}
        <div className="grid grid-cols-6 gap-x-[7px] gap-y-[3px] mb-[7px]">
          {/* Row 2 */}
          <SciButton
            id="FRAC"
            ariaLabel="Fraction / Mixed Fraction / Remainder"
            legend={{ gold: <FracGlyph mixed small />, red: '÷R' }}
            label={<FracGlyph />}
          />
          <SciButton
            id="SQRT"
            ariaLabel="Square Root / Cube Root"
            legend={{ gold: <RootGlyph prefix="3" small />, red: <span className="inline-block w-[5px] h-[6px] bg-current" /> }}
            label={<RootGlyph />}
          />
          <SciButton
            id="X2"
            ariaLabel="x squared / x cubed / DEC"
            legend={{
              gold: (
                <span>
                  <span className="font-math italic">x</span>³
                </span>
              ),
              blue: 'DEC',
            }}
            label={
              <span>
                <span className="font-math italic text-[14px]">x</span>
                <sup className="text-[9px]">2</sup>
              </span>
            }
          />
          <SciButton
            id="XPOW"
            ariaLabel="Power / nth root / HEX"
            legend={{ gold: <RootGlyph prefix="box" small />, blue: 'HEX' }}
            label={
              <span className="inline-flex items-start">
                <span className="font-math italic text-[14px] leading-none">x</span>
                <span className="w-[5px] h-[6px] bg-white/90 ml-[1px] -mt-[1px] rounded-[0.5px]" />
              </span>
            }
          />
          <SciButton
            id="LOGBOX"
            ariaLabel="log base / 10^x / BIN"
            legend={{ gold: '10■', blue: 'BIN' }}
            label={
              <span className="inline-flex items-baseline text-[11px]">
                <span>log</span>
                <span className="w-[5px] h-[5px] bg-white/90 mx-[1px] translate-y-[2px]" />
                <span className="w-[5px] h-[7px] border border-white/90" />
              </span>
            }
          />
          <SciButton
            id="LN"
            ariaLabel="Natural log / e^x / OCT"
            legend={{
              gold: (
                <span>
                  <span className="font-math italic">e</span>■
                </span>
              ),
              blue: 'OCT',
            }}
            label={<span className="text-[12px]">ln</span>}
          />

          {/* Row 3 */}
          <SciButton
            id="NEG"
            ariaLabel="Negative / log10 / A"
            legend={{ gold: 'log', red: 'A' }}
            label={<span className="text-[12px]">(−)</span>}
          />
          <SciButton
            id="DMS"
            ariaLabel="Degrees Minutes Seconds / FACT / B"
            legend={{ gold: 'FACT', red: 'B' }}
            label={<span className="text-[11px] tracking-tight">° , ”</span>}
          />
          <SciButton
            id="XINV"
            ariaLabel="Inverse / Factorial / C"
            legend={{
              gold: (
                <span>
                  <span className="font-math italic">x</span>!
                </span>
              ),
              red: 'C',
            }}
            label={
              <span>
                <span className="font-math italic text-[14px]">x</span>
                <sup className="text-[9px]">−1</sup>
              </span>
            }
          />
          <SciButton
            id="SIN"
            ariaLabel="sin / arcsin / D"
            legend={{ gold: 'sin⁻¹', red: 'D' }}
            label={<span className="text-[12px]">sin</span>}
          />
          <SciButton
            id="COS"
            ariaLabel="cos / arccos / E"
            legend={{ gold: 'cos⁻¹', red: 'E' }}
            label={<span className="text-[12px]">cos</span>}
          />
          <SciButton
            id="TAN"
            ariaLabel="tan / arctan / F"
            legend={{ gold: 'tan⁻¹', red: 'F' }}
            label={<span className="text-[12px]">tan</span>}
          />

          {/* Row 4 */}
          <SciButton
            id="STO"
            ariaLabel="Store / Recall"
            legend={{ gold: 'RECALL' }}
            label={<span className="text-[11.5px]">STO</span>}
          />
          <SciButton
            id="ENG"
            ariaLabel="ENG / angle / i"
            legend={{ gold: '∠ ←', blue: <span className="font-math italic text-[9.5px]">i</span> }}
            label={<span className="text-[11.5px]">ENG</span>}
          />
          <SciButton
            id="LPAREN"
            ariaLabel="Open Parenthesis / Abs"
            legend={{ gold: <span className="mx-auto">Abs</span> }}
            label={<span className="text-[13px]">(</span>}
          />
          <SciButton
            id="RPAREN"
            ariaLabel="Close Parenthesis / semicolon / x"
            legend={{ gold: ';', red: <span className="font-math italic">x</span> }}
            label={<span className="text-[13px]">)</span>}
          />
          <SciButton
            id="SD"
            ariaLabel="Standard to Decimal / Mixed-Improper / y"
            legend={{ gold: 'aᵇ⁄c⇔d⁄c', red: <span className="font-math italic">y</span> }}
            label={<span className="text-[11px]">S⇔D</span>}
          />
          <SciButton
            id="MPLUS"
            ariaLabel="M+ / M- / M"
            legend={{ gold: 'M−', red: 'M' }}
            label={<span className="text-[11.5px]">M+</span>}
          />
        </div>

        {/* Main 5-Column Lower Keypad (Rows 5-8) */}
        <div className="grid grid-cols-5 gap-x-[9px] gap-y-[4px]">
          {/* Row 5 */}
          <MainButton
            id="7"
            ariaLabel="7 / CONST"
            legend={{ gold: <span className="mx-auto">CONST</span> }}
            label={<span className="text-[18px]">7</span>}
          />
          <MainButton
            id="8"
            ariaLabel="8 / CONV"
            legend={{ gold: <span className="mx-auto">CONV</span> }}
            label={<span className="text-[18px]">8</span>}
          />
          <MainButton
            id="9"
            ariaLabel="9 / RESET"
            legend={{ gold: <span className="mx-auto">RESET</span> }}
            label={<span className="text-[18px]">9</span>}
          />
          <MainButton
            id="DEL"
            variant="blue"
            ariaLabel="DEL / INS / UNDO"
            legend={{ gold: 'INS', red: 'UNDO' }}
            label={<span className="text-[15px] tracking-tight font-semibold">DEL</span>}
          />
          <MainButton
            id="AC"
            variant="blue"
            ariaLabel="AC / OFF"
            legend={{ gold: <span className="mx-auto">OFF</span> }}
            label={<span className="text-[15px] tracking-tight font-semibold">AC</span>}
          />

          {/* Row 6 */}
          <MainButton id="4" ariaLabel="4" label={<span className="text-[18px]">4</span>} />
          <MainButton id="5" ariaLabel="5" label={<span className="text-[18px]">5</span>} />
          <MainButton id="6" ariaLabel="6" label={<span className="text-[18px]">6</span>} />
          <MainButton
            id="MUL"
            ariaLabel="Multiply / nPr / GCD"
            legend={{ gold: 'nPr', red: 'GCD' }}
            label={<span className="text-[20px] font-normal">×</span>}
          />
          <MainButton
            id="DIV"
            ariaLabel="Divide / nCr / LCM"
            legend={{ gold: 'nCr', red: 'LCM' }}
            label={<span className="text-[20px] font-normal">÷</span>}
          />

          {/* Row 7 */}
          <MainButton id="1" ariaLabel="1" label={<span className="text-[18px]">1</span>} />
          <MainButton id="2" ariaLabel="2" label={<span className="text-[18px]">2</span>} />
          <MainButton id="3" ariaLabel="3" label={<span className="text-[18px]">3</span>} />
          <MainButton
            id="ADD"
            ariaLabel="Add / Pol / Int"
            legend={{ gold: 'Pol', red: 'Int' }}
            label={<span className="text-[20px] font-normal">+</span>}
          />
          <MainButton
            id="SUB"
            ariaLabel="Subtract / Rec / Intg"
            legend={{ gold: 'Rec', red: 'Intg' }}
            label={<span className="text-[20px] font-normal">−</span>}
          />

          {/* Row 8 */}
          <MainButton
            id="0"
            ariaLabel="0 / Rnd / RndFix"
            legend={{ gold: 'Rnd', red: 'RndFix' }}
            label={<span className="text-[18px]">0</span>}
          />
          <MainButton
            id="COMMA"
            ariaLabel="Decimal Comma / Ran# / RanInt"
            legend={{ gold: 'Ran#', red: 'RanInt' }}
            label={<span className="text-[20px] leading-none -mt-[3px]">,</span>}
          />
          <MainButton
            id="EXP10"
            ariaLabel="x10^x / pi / e"
            legend={{ gold: 'π', red: <span className="font-math italic">e</span> }}
            label={
              <span className="text-[13.5px] font-bold tracking-tight">
                ×10<sup className="font-math italic text-[10px]">x</sup>
              </span>
            }
          />
          <MainButton
            id="ANS"
            ariaLabel="Ans / %"
            legend={{ gold: <span className="mx-auto">%</span> }}
            label={<span className="text-[15px]">Ans</span>}
          />
          <MainButton
            id="EQ"
            ariaLabel="Equals / Approximate"
            legend={{ gold: <span className="mx-auto">≈</span> }}
            label={<span className="text-[20px] font-normal">=</span>}
          />
        </div>
      </div>
    </div>
  );
};
