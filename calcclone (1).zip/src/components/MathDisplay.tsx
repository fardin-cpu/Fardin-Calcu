import React from 'react';
import {
  BaseMode,
  CalcSettings,
  ComplexVal,
  CursorPos,
  EvalResult,
  MathNode,
  PathStep,
} from '../calculator/types';
import { formatDms, formatEng, formatRealNumber } from '../calculator/exactMath';

interface MathListProps {
  nodes: MathNode[];
  cursor?: CursorPos;
  path: PathStep[];
  overwrite?: boolean;
  compact?: boolean;
}

function pathsEqual(a: PathStep[], b: PathStep[]): boolean {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (a[i].nodeId !== b[i].nodeId || a[i].slot !== b[i].slot) return false;
  }
  return true;
}

const CursorCaret: React.FC<{ overwrite?: boolean }> = ({ overwrite }) => (
  <span
    className={`lcd-cursor-blink inline-block align-middle ${
      overwrite
        ? 'w-[7px] h-[14px] bg-[#121713]/80 -mx-[1px]'
        : 'w-[1.5px] h-[15px] bg-[#121713] -mx-[0.5px]'
    }`}
  />
);

const EmptySlotBox: React.FC<{ hasCursor: boolean; overwrite?: boolean }> = ({
  hasCursor,
  overwrite,
}) => (
  <span className="inline-flex items-center justify-center relative min-w-[9px] h-[12px] border border-dashed border-[#121713]/65 mx-[1px]">
    {hasCursor && <CursorCaret overwrite={overwrite} />}
  </span>
);

export const MathListView: React.FC<MathListProps> = ({
  nodes,
  cursor,
  path,
  overwrite,
  compact,
}) => {
  const isHere = cursor ? pathsEqual(cursor.path, path) : false;

  if (nodes.length === 0) {
    if (path.length === 0) {
      return isHere ? <CursorCaret overwrite={overwrite} /> : <span className="inline-block w-1" />;
    }
    return <EmptySlotBox hasCursor={isHere} overwrite={overwrite} />;
  }

  return (
    <span className={`inline-flex items-center flex-wrap leading-none ${compact ? 'text-[11px]' : 'text-[15px]'}`}>
      {nodes.map((node, idx) => {
        const showBefore = isHere && cursor?.index === idx;
        return (
          <React.Fragment key={node.id}>
            {showBefore && <CursorCaret overwrite={overwrite} />}
            <MathNodeView
              node={node}
              cursor={cursor}
              path={path}
              overwrite={overwrite}
              compact={compact}
            />
          </React.Fragment>
        );
      })}
      {isHere && cursor?.index === nodes.length && <CursorCaret overwrite={overwrite} />}
    </span>
  );
};

const MathNodeView: React.FC<{
  node: MathNode;
  cursor?: CursorPos;
  path: PathStep[];
  overwrite?: boolean;
  compact?: boolean;
}> = ({ node, cursor, path, overwrite, compact }) => {
  switch (node.type) {
    case 'char': {
      const v = node.value;
      if (v === '²' || v === '³' || v === '⁻¹') {
        return <sup className="text-[0.68em] leading-none font-lcd ml-[0.5px] -top-[0.45em]">{v === '⁻¹' ? '⁻¹' : v}</sup>;
      }
      if (v === '×10^') {
        return <span className="font-lcd mx-[1px] text-[0.88em]">×10^</span>;
      }
      if (v === 'x' || v === 'y') {
        return <span className="font-math italic px-[0.5px]">{v}</span>;
      }
      if (v === 'π' || v === 'e' || v === 'i') {
        return <span className="font-math italic px-[0.5px]">{v}</span>;
      }
      return <span className="font-lcd">{v}</span>;
    }

    case 'func':
      return <span className="font-lcd tracking-tight">{node.name}</span>;

    case 'const':
      return <span className="font-lcd font-semibold px-[1px]">{node.symbol}</span>;

    case 'fraction':
      return (
        <span className="inline-flex flex-col items-center justify-center align-middle mx-[2px] my-[1px]">
          <span className="px-[3px] pb-[1px] border-b border-[#121713] flex items-center justify-center min-w-[12px]">
            <MathListView
              nodes={node.num}
              cursor={cursor}
              path={[...path, { nodeId: node.id, slot: 'num' }]}
              overwrite={overwrite}
              compact
            />
          </span>
          <span className="px-[3px] pt-[1px] flex items-center justify-center min-w-[12px]">
            <MathListView
              nodes={node.den}
              cursor={cursor}
              path={[...path, { nodeId: node.id, slot: 'den' }]}
              overwrite={overwrite}
              compact
            />
          </span>
        </span>
      );

    case 'mixedFraction':
      return (
        <span className="inline-flex items-center align-middle mx-[1px]">
          <span className="mr-[2px]">
            <MathListView
              nodes={node.whole}
              cursor={cursor}
              path={[...path, { nodeId: node.id, slot: 'whole' }]}
              overwrite={overwrite}
              compact={compact}
            />
          </span>
          <span className="inline-flex flex-col items-center justify-center">
            <span className="px-[2px] pb-[1px] border-b border-[#121713] flex items-center justify-center">
              <MathListView
                nodes={node.num}
                cursor={cursor}
                path={[...path, { nodeId: node.id, slot: 'num' }]}
                overwrite={overwrite}
                compact
              />
            </span>
            <span className="px-[2px] pt-[1px] flex items-center justify-center">
              <MathListView
                nodes={node.den}
                cursor={cursor}
                path={[...path, { nodeId: node.id, slot: 'den' }]}
                overwrite={overwrite}
                compact
              />
            </span>
          </span>
        </span>
      );

    case 'sqrt':
    case 'cbrt':
      return (
        <span className="inline-flex items-stretch align-middle mx-[1px]">
          {node.type === 'cbrt' && (
            <span className="text-[9px] font-lcd self-start -mr-[3px] mt-[1px]">3</span>
          )}
          <span className="font-math text-[1.15em] leading-none self-end mr-[1px]">√</span>
          <span className="border-t border-[#121713] pt-[1.5px] pl-[1px] pr-[2px] inline-flex items-center">
            <MathListView
              nodes={node.body}
              cursor={cursor}
              path={[...path, { nodeId: node.id, slot: 'body' }]}
              overwrite={overwrite}
              compact={compact}
            />
          </span>
        </span>
      );

    case 'nroot':
      return (
        <span className="inline-flex items-stretch align-middle mx-[1px]">
          <span className="text-[9px] self-start -mr-[2px] mt-[1px]">
            <MathListView
              nodes={node.index}
              cursor={cursor}
              path={[...path, { nodeId: node.id, slot: 'index' }]}
              overwrite={overwrite}
              compact
            />
          </span>
          <span className="font-math text-[1.15em] leading-none self-end mr-[1px]">√</span>
          <span className="border-t border-[#121713] pt-[1.5px] pl-[1px] pr-[2px] inline-flex items-center">
            <MathListView
              nodes={node.body}
              cursor={cursor}
              path={[...path, { nodeId: node.id, slot: 'body' }]}
              overwrite={overwrite}
              compact={compact}
            />
          </span>
        </span>
      );

    case 'sup':
      return (
        <span className="inline-flex items-center align-super -translate-y-[5px] text-[0.74em] ml-[0.5px]">
          <MathListView
            nodes={node.body}
            cursor={cursor}
            path={[...path, { nodeId: node.id, slot: 'body' }]}
            overwrite={overwrite}
            compact
          />
        </span>
      );

    case 'logBase':
      return (
        <span className="inline-flex items-baseline align-middle mx-[1px]">
          <span className="font-lcd">log</span>
          <span className="translate-y-[3px] text-[0.72em] mx-[1px]">
            <MathListView
              nodes={node.base}
              cursor={cursor}
              path={[...path, { nodeId: node.id, slot: 'base' }]}
              overwrite={overwrite}
              compact
            />
          </span>
          <span className="font-lcd">(</span>
          <MathListView
            nodes={node.body}
            cursor={cursor}
            path={[...path, { nodeId: node.id, slot: 'body' }]}
            overwrite={overwrite}
            compact={compact}
          />
          <span className="font-lcd">)</span>
        </span>
      );

    case 'abs':
      return (
        <span className="inline-flex items-center align-middle mx-[1px]">
          <span className="border-l-[1.5px] border-r-[1.5px] border-[#121713] px-[2.5px] inline-flex items-center">
            <MathListView
              nodes={node.body}
              cursor={cursor}
              path={[...path, { nodeId: node.id, slot: 'body' }]}
              overwrite={overwrite}
              compact={compact}
            />
          </span>
        </span>
      );

    case 'integral':
      return (
        <span className="inline-flex items-center align-middle mx-[1px]">
          <span className="font-math text-[1.45em] leading-none mr-[1px]">∫</span>
          <span className="inline-flex flex-col justify-between text-[0.68em] mr-[2px] gap-[2px]">
            <MathListView
              nodes={node.upper}
              cursor={cursor}
              path={[...path, { nodeId: node.id, slot: 'upper' }]}
              overwrite={overwrite}
              compact
            />
            <MathListView
              nodes={node.lower}
              cursor={cursor}
              path={[...path, { nodeId: node.id, slot: 'lower' }]}
              overwrite={overwrite}
              compact
            />
          </span>
          <span className="font-lcd">(</span>
          <MathListView
            nodes={node.expr}
            cursor={cursor}
            path={[...path, { nodeId: node.id, slot: 'expr' }]}
            overwrite={overwrite}
            compact
          />
          <span className="font-lcd text-[0.88em]">)d<span className="font-math italic">x</span></span>
        </span>
      );

    case 'derivative':
      return (
        <span className="inline-flex items-center align-middle mx-[1px]">
          <span className="inline-flex flex-col items-center text-[0.68em] leading-none mr-[2px]">
            <span className="border-b border-[#121713] px-[1px]">d</span>
            <span>d<span className="font-math italic">x</span></span>
          </span>
          <span className="font-lcd">(</span>
          <MathListView
            nodes={node.expr}
            cursor={cursor}
            path={[...path, { nodeId: node.id, slot: 'expr' }]}
            overwrite={overwrite}
            compact
          />
          <span className="font-lcd">)|</span>
          <span className="translate-y-[4px] text-[0.7em] inline-flex items-center">
            <span className="font-math italic">x</span>=
            <MathListView
              nodes={node.at}
              cursor={cursor}
              path={[...path, { nodeId: node.id, slot: 'at' }]}
              overwrite={overwrite}
              compact
            />
          </span>
        </span>
      );

    case 'sum':
    case 'prod':
      return (
        <span className="inline-flex items-center align-middle mx-[1px]">
          <span className="inline-flex flex-col items-center mr-[2px] leading-none">
            <span className="text-[0.65em]">
              <MathListView
                nodes={node.upper}
                cursor={cursor}
                path={[...path, { nodeId: node.id, slot: 'upper' }]}
                overwrite={overwrite}
                compact
              />
            </span>
            <span className="font-math text-[1.25em] leading-none">{node.type === 'sum' ? 'Σ' : 'Π'}</span>
            <span className="text-[0.65em] inline-flex items-center">
              <span className="font-math italic">x</span>=
              <MathListView
                nodes={node.lower}
                cursor={cursor}
                path={[...path, { nodeId: node.id, slot: 'lower' }]}
                overwrite={overwrite}
                compact
              />
            </span>
          </span>
          <span className="font-lcd">(</span>
          <MathListView
            nodes={node.expr}
            cursor={cursor}
            path={[...path, { nodeId: node.id, slot: 'expr' }]}
            overwrite={overwrite}
            compact
          />
          <span className="font-lcd">)</span>
        </span>
      );
  }
};

// ---------- Result View ----------
export function formatComplexResult(c: ComplexVal, settings: CalcSettings): string {
  const { complexFormat, angleUnit } = settings;
  if (complexFormat === 'POLAR') {
    const r = Math.hypot(c.re, c.im);
    let theta = Math.atan2(c.im, c.re);
    if (angleUnit === 'DEG') theta = (theta * 180) / Math.PI;
    else if (angleUnit === 'GRA') theta = (theta * 200) / Math.PI;
    return `${formatRealNumber(r, settings)}∠${formatRealNumber(theta, settings)}`;
  }

  const hasRe = Math.abs(c.re) >= 1e-12;
  const hasIm = Math.abs(c.im) >= 1e-12;
  if (!hasRe && !hasIm) return '0';
  if (!hasIm) return formatRealNumber(c.re, settings);
  const imAbs = Math.abs(c.im);
  const imUnit = Math.abs(imAbs - 1) < 1e-12 ? 'i' : `${formatRealNumber(imAbs, settings)}i`;
  if (!hasRe) return c.im < 0 ? `-${imUnit}` : imUnit;
  return `${formatRealNumber(c.re, settings)}${c.im < 0 ? '−' : '+'}${imUnit}`;
}

export function formatBaseInt(val: number, baseMode: BaseMode): string {
  const n32 = val | 0;
  if (baseMode === 'DEC') return `${n32}`;
  const u32 = n32 >>> 0;
  if (baseMode === 'HEX') return u32.toString(16).toUpperCase().padStart(8, '0').replace(/(.{4})/g, '$1 ').trim();
  if (baseMode === 'OCT') return u32.toString(8).padStart(11, '0');
  // BIN: show 16 or 32 bits cleanly grouped by 4
  const bits = u32.toString(2).padStart(16, '0');
  const trimmed = bits.length > 16 ? bits.padStart(32, '0') : bits;
  return trimmed.replace(/(.{4})/g, '$1 ').trim();
}

export const ResultView: React.FC<{
  result: EvalResult | null;
  settings: CalcSettings;
  baseMode: BaseMode;
  showDecimal: boolean;
  showMixed: boolean;
  dmsView: boolean;
  engShift: number | null;
}> = ({ result, settings, baseMode, showDecimal, showMixed, dmsView, engShift }) => {
  if (!result) return null;
  if (!result.ok) {
    return (
      <div className="font-lcd text-[14px] font-bold text-[#121713] text-right">
        {result.error}
      </div>
    );
  }

  if (result.type === 'fact' && result.factStr) {
    return <div className="font-lcd text-[16px] font-semibold text-[#121713] text-right">{result.factStr}</div>;
  }

  if (result.type === 'base' && result.baseInt !== undefined) {
    return (
      <div className="font-lcd text-[13px] font-semibold text-[#121713] text-right tracking-tight break-all">
        {formatBaseInt(result.baseInt, baseMode)}
      </div>
    );
  }

  if (result.type === 'polrec' && result.polRec) {
    return (
      <div className="font-lcd text-[13px] font-semibold text-[#121713] text-right leading-tight">
        <div>{result.polRec.label1}={formatRealNumber(result.polRec.val1, settings)}</div>
        <div>{result.polRec.label2}={formatRealNumber(result.polRec.val2, settings)}</div>
      </div>
    );
  }

  if (result.type === 'divrem' && result.divRem) {
    return (
      <div className="font-lcd text-[15px] font-semibold text-[#121713] text-right">
        Q={result.divRem.quotient} , R={result.divRem.remainder}
      </div>
    );
  }

  if (result.type === 'matrix' && result.matrix) {
    return (
      <div className="inline-flex items-center font-lcd text-[11px] font-semibold text-[#121713] border-l-2 border-r-2 border-[#121713] px-1.5 py-0.5 ml-auto">
        <div className="grid gap-x-2 gap-y-0.5" style={{ gridTemplateColumns: `repeat(${result.matrix[0].length}, minmax(0, 1fr))` }}>
          {result.matrix.flatMap((row, r) =>
            row.map((v, c) => (
              <span key={`${r}-${c}`} className="text-right">
                {formatRealNumber(v, settings)}
              </span>
            ))
          )}
        </div>
      </div>
    );
  }

  if (result.type === 'vector' && result.vector) {
    return (
      <div className="inline-flex items-center font-lcd text-[12px] font-semibold text-[#121713] border-l-2 border-r-2 border-[#121713] px-1.5 py-0.5 ml-auto">
        <span>[ {result.vector.map((v) => formatRealNumber(v, settings)).join('  ')} ]</span>
      </div>
    );
  }

  if (result.type === 'complex' && result.complex) {
    return (
      <div className="font-lcd text-[16px] font-semibold text-[#121713] text-right">
        {formatComplexResult(result.complex, settings)}
      </div>
    );
  }

  const realVal = result.real ?? 0;

  if (dmsView) {
    return (
      <div className="font-lcd text-[16px] font-semibold text-[#121713] text-right">
        {formatDms(realVal)}
      </div>
    );
  }

  if (engShift !== null) {
    return (
      <div className="font-lcd text-[16px] font-semibold text-[#121713] text-right">
        {formatEng(realVal, engShift, settings.engSymbol, settings.decimalMark)}
      </div>
    );
  }

  if (!showDecimal && result.exact) {
    const ex = result.exact;
    if (ex.kind === 'rational' || ex.kind === 'surd' || ex.kind === 'pi') {
      if (showMixed && ex.kind === 'rational' && ex.displayNum && ex.displayDen) {
        const n = parseInt(ex.displayNum, 10);
        const d = parseInt(ex.displayDen, 10);
        if (Math.abs(n) > d) {
          const sign = n < 0 ? '-' : '';
          const w = Math.floor(Math.abs(n) / d);
          const rem = Math.abs(n) % d;
          return (
            <div className="inline-flex items-center justify-end font-lcd text-[15px] font-semibold text-[#121713] ml-auto">
              <span className="mr-1">{sign}{w}</span>
              <span className="inline-flex flex-col items-center leading-tight text-[12px]">
                <span className="border-b border-[#121713] px-1">{rem}</span>
                <span className="px-1">{d}</span>
              </span>
            </div>
          );
        }
      }
      if (!ex.displayDen) {
        return (
          <div className="font-lcd text-[17px] font-semibold text-[#121713] text-right">
            {ex.displayNum}
          </div>
        );
      }
      return (
        <div className="inline-flex flex-col items-center justify-end font-lcd text-[13px] font-semibold text-[#121713] ml-auto leading-tight">
          <span className="border-b border-[#121713] px-1.5 pb-[1px]">{ex.displayNum}</span>
          <span className="px-1.5 pt-[1px]">{ex.displayDen}</span>
        </div>
      );
    }
  }

  return (
    <div className="font-lcd text-[17px] font-semibold text-[#121713] text-right tracking-tight">
      {formatRealNumber(realVal, settings)}
    </div>
  );
};
