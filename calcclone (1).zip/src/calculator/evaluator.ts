import {
  AngleUnit,
  BaseMode,
  CalcMode,
  CalcSettings,
  ComplexVal,
  EvalResult,
  MathNode,
  MatrixData,
  VariablesMap,
  VarName,
  VectorData,
} from './types';
import { gcdInt, lcmInt, tryExactRepresentation } from './exactMath';

export interface EvalContext {
  mode: CalcMode;
  baseMode: BaseMode;
  settings: CalcSettings;
  vars: VariablesMap;
  ans: EvalResult | null;
  matrices: Record<'MatA' | 'MatB' | 'MatC' | 'MatD', MatrixData>;
  vectors: Record<'VctA' | 'VctB' | 'VctC', VectorData>;
}

// ---------- Complex helpers ----------
const cAdd = (a: ComplexVal, b: ComplexVal): ComplexVal => ({ re: a.re + b.re, im: a.im + b.im });
const cSub = (a: ComplexVal, b: ComplexVal): ComplexVal => ({ re: a.re - b.re, im: a.im - b.im });
const cMul = (a: ComplexVal, b: ComplexVal): ComplexVal => ({
  re: a.re * b.re - a.im * b.im,
  im: a.re * b.im + a.im * b.re,
});
const cDiv = (a: ComplexVal, b: ComplexVal): ComplexVal => {
  const denom = b.re * b.re + b.im * b.im;
  if (denom === 0) throw new Error('Math ERROR');
  return {
    re: (a.re * b.re + a.im * b.im) / denom,
    im: (a.im * b.re - a.re * b.im) / denom,
  };
};
const cAbs = (a: ComplexVal): number => Math.hypot(a.re, a.im);
const cArgRad = (a: ComplexVal): number => Math.atan2(a.im, a.re);
const cExp = (a: ComplexVal): ComplexVal => {
  const er = Math.exp(a.re);
  return { re: er * Math.cos(a.im), im: er * Math.sin(a.im) };
};
const cLn = (a: ComplexVal): ComplexVal => {
  const r = cAbs(a);
  if (r === 0) throw new Error('Math ERROR');
  return { re: Math.log(r), im: cArgRad(a) };
};
const cPow = (a: ComplexVal, b: ComplexVal): ComplexVal => {
  if (a.im === 0 && b.im === 0) {
    if (a.re === 0 && b.re < 0) throw new Error('Math ERROR');
    if (a.re === 0 && b.re === 0) return { re: 1, im: 0 };
    if (a.re > 0) return { re: Math.pow(a.re, b.re), im: 0 };
    if (Number.isInteger(b.re)) return { re: Math.pow(a.re, b.re), im: 0 };
  }
  if (a.re === 0 && a.im === 0) {
    if (b.re > 0 && b.im === 0) return { re: 0, im: 0 };
    throw new Error('Math ERROR');
  }
  return cExp(cMul(b, cLn(a)));
};
const cSin = (z: ComplexVal): ComplexVal => ({
  re: Math.sin(z.re) * Math.cosh(z.im),
  im: Math.cos(z.re) * Math.sinh(z.im),
});
const cCos = (z: ComplexVal): ComplexVal => ({
  re: Math.cos(z.re) * Math.cosh(z.im),
  im: -Math.sin(z.re) * Math.sinh(z.im),
});
const cTan = (z: ComplexVal): ComplexVal => cDiv(cSin(z), cCos(z));

function toRad(angle: number, unit: AngleUnit): number {
  if (unit === 'DEG') return (angle * Math.PI) / 180;
  if (unit === 'GRA') return (angle * Math.PI) / 200;
  return angle;
}

function fromRad(rad: number, unit: AngleUnit): number {
  if (unit === 'DEG') return (rad * 180) / Math.PI;
  if (unit === 'GRA') return (rad * 200) / Math.PI;
  return rad;
}

function factorial(n: number): number {
  if (!Number.isFinite(n) || n < 0 || !Number.isInteger(n)) throw new Error('Math ERROR');
  if (n > 170) throw new Error('Math ERROR');
  let res = 1;
  for (let i = 2; i <= n; i++) res *= i;
  return res;
}

function nPr(n: number, r: number): number {
  if (!Number.isInteger(n) || !Number.isInteger(r) || n < 0 || r < 0 || r > n) {
    throw new Error('Math ERROR');
  }
  let res = 1;
  for (let i = 0; i < r; i++) res *= n - i;
  return res;
}

function nCr(n: number, r: number): number {
  if (!Number.isInteger(n) || !Number.isInteger(r) || n < 0 || r < 0 || r > n) {
    throw new Error('Math ERROR');
  }
  const k = Math.min(r, n - r);
  let res = 1;
  for (let i = 0; i < k; i++) {
    res = (res * (n - i)) / (i + 1);
  }
  return Math.round(res);
}

// ---------- Matrix & Vector Helpers ----------
function matDet(m: MatrixData): number {
  const n = m.length;
  if (n === 0 || m[0].length !== n) throw new Error('Dimension ERROR');
  const a = m.map((r) => [...r]);
  let det = 1;
  for (let i = 0; i < n; i++) {
    let pivot = i;
    for (let j = i + 1; j < n; j++) {
      if (Math.abs(a[j][i]) > Math.abs(a[pivot][i])) pivot = j;
    }
    if (Math.abs(a[pivot][i]) < 1e-13) return 0;
    if (pivot !== i) {
      [a[i], a[pivot]] = [a[pivot], a[i]];
      det = -det;
    }
    det *= a[i][i];
    for (let j = i + 1; j < n; j++) {
      const f = a[j][i] / a[i][i];
      for (let k = i; k < n; k++) a[j][k] -= f * a[i][k];
    }
  }
  return det;
}

function matInv(m: MatrixData): MatrixData {
  const n = m.length;
  if (n === 0 || m[0].length !== n) throw new Error('Dimension ERROR');
  const aug = m.map((r, i) => [
    ...r,
    ...Array.from({ length: n }, (_, j) => (i === j ? 1 : 0)),
  ]);
  for (let i = 0; i < n; i++) {
    let pivot = i;
    for (let j = i + 1; j < n; j++) {
      if (Math.abs(aug[j][i]) > Math.abs(aug[pivot][i])) pivot = j;
    }
    if (Math.abs(aug[pivot][i]) < 1e-13) throw new Error('Math ERROR');
    if (pivot !== i) [aug[i], aug[pivot]] = [aug[pivot], aug[i]];
    const div = aug[i][i];
    for (let k = 0; k < 2 * n; k++) aug[i][k] /= div;
    for (let j = 0; j < n; j++) {
      if (j === i) continue;
      const f = aug[j][i];
      for (let k = 0; k < 2 * n; k++) aug[j][k] -= f * aug[i][k];
    }
  }
  return aug.map((r) => r.slice(n));
}

function matMul(a: MatrixData, b: MatrixData): MatrixData {
  if (a[0].length !== b.length) throw new Error('Dimension ERROR');
  const res: MatrixData = Array.from({ length: a.length }, () => Array(b[0].length).fill(0));
  for (let i = 0; i < a.length; i++) {
    for (let k = 0; k < b.length; k++) {
      for (let j = 0; j < b[0].length; j++) {
        res[i][j] += a[i][k] * b[k][j];
      }
    }
  }
  return res;
}

function matTrn(m: MatrixData): MatrixData {
  return m[0].map((_, j) => m.map((r) => r[j]));
}

// ---------- Tokenizer over MathNode[] ----------
type RuntimeVal =
  | { kind: 'num'; c: ComplexVal }
  | { kind: 'mat'; m: MatrixData }
  | { kind: 'vct'; v: VectorData };

const asComplex = (v: RuntimeVal): ComplexVal => {
  if (v.kind !== 'num') throw new Error('Syntax ERROR');
  return v.c;
};

const asReal = (v: RuntimeVal): number => {
  const c = asComplex(v);
  if (Math.abs(c.im) > 1e-11) throw new Error('Math ERROR');
  return c.re;
};

type Token =
  | { type: 'number'; value: number }
  | { type: 'imag'; value: number }
  | { type: 'var'; name: string }
  | { type: 'mat'; name: 'MatA' | 'MatB' | 'MatC' | 'MatD' }
  | { type: 'vct'; name: 'VctA' | 'VctB' | 'VctC' }
  | { type: 'ans' }
  | { type: 'ran' }
  | { type: 'func'; name: string }
  | { type: 'op'; value: string }
  | { type: 'postfix'; value: string }
  | { type: 'lparen' }
  | { type: 'rparen' }
  | { type: 'sep' } // ; or ,
  | { type: 'node'; node: MathNode };

function isHexDigit(ch: string, baseMode: BaseMode, mode: CalcMode): boolean {
  if (mode !== 'BASE') return false;
  if (baseMode === 'HEX') return /^[0-9A-F]$/.test(ch);
  if (baseMode === 'DEC') return /^[0-9]$/.test(ch);
  if (baseMode === 'OCT') return /^[0-7]$/.test(ch);
  if (baseMode === 'BIN') return /^[01]$/.test(ch);
  return false;
}

function tokenizeNodes(nodes: MathNode[], ctx: EvalContext): Token[] {
  const tokens: Token[] = [];
  let i = 0;

  const isDecChar = (ch: string) =>
    (ch >= '0' && ch <= '9') || ch === '.' || ch === ',';

  while (i < nodes.length) {
    const n = nodes[i];

    if (n.type === 'char') {
      const ch = n.value;
      if (ch === ' ') {
        i++;
        continue;
      }

      // Multi-char tokens that might be stored as single char nodes
      if (ch === 'Ans' || ch === 'PreAns') {
        tokens.push({ type: 'ans' });
        i++;
        continue;
      }
      if (ch === 'Ran#') {
        tokens.push({ type: 'ran' });
        i++;
        continue;
      }
      if (ch === 'MatA' || ch === 'MatB' || ch === 'MatC' || ch === 'MatD') {
        tokens.push({ type: 'mat', name: ch });
        i++;
        continue;
      }
      if (ch === 'VctA' || ch === 'VctB' || ch === 'VctC') {
        tokens.push({ type: 'vct', name: ch });
        i++;
        continue;
      }
      if (ch === 'π') {
        tokens.push({ type: 'number', value: Math.PI });
        i++;
        continue;
      }
      if (ch === 'e') {
        tokens.push({ type: 'number', value: Math.E });
        i++;
        continue;
      }
      if (ch === 'i') {
        tokens.push({ type: 'imag', value: 1 });
        i++;
        continue;
      }

      // Numbers in Base-N mode
      if (ctx.mode === 'BASE' && isHexDigit(ch, ctx.baseMode, ctx.mode)) {
        let numStr = '';
        while (
          i < nodes.length &&
          nodes[i].type === 'char' &&
          isHexDigit((nodes[i] as { value: string }).value, ctx.baseMode, ctx.mode)
        ) {
          numStr += (nodes[i] as { value: string }).value;
          i++;
        }
        const radix =
          ctx.baseMode === 'HEX' ? 16 : ctx.baseMode === 'OCT' ? 8 : ctx.baseMode === 'BIN' ? 2 : 10;
        const parsed = parseInt(numStr, radix);
        if (Number.isNaN(parsed)) throw new Error('Syntax ERROR');
        tokens.push({ type: 'number', value: parsed | 0 });
        continue;
      }

      // Standard numbers (and DMS like 12°30'45")
      if (isDecChar(ch)) {
        let raw = '';
        let dots = 0;
        while (
          i < nodes.length &&
          nodes[i].type === 'char' &&
          isDecChar((nodes[i] as { value: string }).value)
        ) {
          const c = (nodes[i] as { value: string }).value;
          if (c === '.' || c === ',') {
            dots++;
            if (dots > 1) throw new Error('Syntax ERROR');
            raw += '.';
          } else {
            raw += c;
          }
          i++;
        }
        const numVal = raw === '.' ? 0 : parseFloat(raw);
        if (Number.isNaN(numVal)) throw new Error('Syntax ERROR');

        // Check for DMS degrees/minutes/seconds chain: e.g. 12°30′45″
        if (
          i < nodes.length &&
          nodes[i].type === 'char' &&
          (nodes[i] as { value: string }).value === '°'
        ) {
          i++; // consume °
          let totalDeg = numVal;
          const readPart = (): number | null => {
            if (i >= nodes.length || nodes[i].type !== 'char') return null;
            let s = '';
            while (
              i < nodes.length &&
              nodes[i].type === 'char' &&
              isDecChar((nodes[i] as { value: string }).value)
            ) {
              const c = (nodes[i] as { value: string }).value;
              s += c === ',' ? '.' : c;
              i++;
            }
            if (!s) return null;
            if (
              i < nodes.length &&
              nodes[i].type === 'char' &&
              ['°', '′', '″', "'", '"'].includes((nodes[i] as { value: string }).value)
            ) {
              i++;
            }
            return parseFloat(s);
          };
          const min = readPart();
          if (min !== null) {
            totalDeg += min / 60;
            const sec = readPart();
            if (sec !== null) totalDeg += sec / 3600;
          }
          tokens.push({ type: 'number', value: totalDeg });
          continue;
        }

        tokens.push({ type: 'number', value: numVal });
        continue;
      }

      if (ch === '(') {
        tokens.push({ type: 'lparen' });
        i++;
        continue;
      }
      if (ch === ')') {
        tokens.push({ type: 'rparen' });
        i++;
        continue;
      }
      if (ch === ';') {
        tokens.push({ type: 'sep' });
        i++;
        continue;
      }
      if (['²', '³', '⁻¹', '!', '%', '°', 'ʳ', 'ᵍ'].includes(ch)) {
        tokens.push({ type: 'postfix', value: ch });
        i++;
        continue;
      }
      if (
        ['+', '-', '−', '×', '÷', '^', '∠', 'nPr', 'nCr', '÷R', '×10^', 'and', 'or', 'xor', 'xnor', 'DotP', 'CrossP'].includes(ch)
      ) {
        tokens.push({ type: 'op', value: ch === '−' ? '-' : ch });
        i++;
        continue;
      }
      if (['A', 'B', 'C', 'D', 'E', 'F', 'x', 'y', 'M'].includes(ch)) {
        tokens.push({ type: 'var', name: ch });
        i++;
        continue;
      }
      throw new Error('Syntax ERROR');
    }

    if (n.type === 'const') {
      tokens.push({ type: 'number', value: n.value });
      i++;
      continue;
    }

    if (n.type === 'func') {
      tokens.push({ type: 'func', name: n.name });
      i++;
      continue;
    }

    tokens.push({ type: 'node', node: n });
    i++;
  }

  return tokens;
}

// ---------- Parser / Evaluator ----------
function evalTokens(tokens: Token[], ctx: EvalContext, localVars?: Partial<VariablesMap>): RuntimeVal {
  if (tokens.length === 0) throw new Error('Syntax ERROR');
  let pos = 0;

  const peek = () => tokens[pos];
  const consume = () => tokens[pos++];

  const isImplicitMulStart = (tok: Token | undefined): boolean => {
    if (!tok) return false;
    return (
      tok.type === 'number' ||
      tok.type === 'imag' ||
      tok.type === 'var' ||
      tok.type === 'mat' ||
      tok.type === 'vct' ||
      tok.type === 'ans' ||
      tok.type === 'ran' ||
      tok.type === 'func' ||
      tok.type === 'lparen' ||
      (tok.type === 'node' && tok.node.type !== 'sup')
    );
  };

  // Precedence levels (lowest to highest):
  // 1: Base-N bitwise OR/XOR/XNOR
  // 2: Base-N bitwise AND
  // 3: + -
  // 4: × ÷ ÷R DotP CrossP
  // 5: Unary + -
  // 6: Implicit multiplication (2π, 3sin(30), 2x)
  // 7: Polar ∠, nPr, nCr
  // 8: ×10^
  // 9: Power ^ and sup node
  // 10: Postfix (², ³, ⁻¹, !, %, °, ʳ, ᵍ)
  // 11: Primary

  const parseExpr = (): RuntimeVal => parseBitwiseOr();

  const parseBitwiseOr = (): RuntimeVal => {
    let left = parseBitwiseAnd();
    while (
      peek()?.type === 'op' &&
      ['or', 'xor', 'xnor'].includes((peek() as { value: string }).value)
    ) {
      const op = (consume() as { value: string }).value;
      const right = parseBitwiseAnd();
      const a = Math.trunc(asReal(left)) | 0;
      const b = Math.trunc(asReal(right)) | 0;
      let res = 0;
      if (op === 'or') res = a | b;
      else if (op === 'xor') res = a ^ b;
      else res = ~(a ^ b);
      left = { kind: 'num', c: { re: res | 0, im: 0 } };
    }
    return left;
  };

  const parseBitwiseAnd = (): RuntimeVal => {
    let left = parseAddSub();
    while (peek()?.type === 'op' && (peek() as { value: string }).value === 'and') {
      consume();
      const right = parseAddSub();
      const a = Math.trunc(asReal(left)) | 0;
      const b = Math.trunc(asReal(right)) | 0;
      left = { kind: 'num', c: { re: (a & b) | 0, im: 0 } };
    }
    return left;
  };

  const parseAddSub = (): RuntimeVal => {
    let left = parseMulDiv();
    while (peek()?.type === 'op' && ['+', '-'].includes((peek() as { value: string }).value)) {
      const op = (consume() as { value: string }).value;
      const right = parseMulDiv();
      if (left.kind === 'mat' && right.kind === 'mat') {
        if (left.m.length !== right.m.length || left.m[0].length !== right.m[0].length) {
          throw new Error('Dimension ERROR');
        }
        left = {
          kind: 'mat',
          m: left.m.map((row, r) => row.map((val, c) => (op === '+' ? val + right.m[r][c] : val - right.m[r][c]))),
        };
      } else if (left.kind === 'vct' && right.kind === 'vct') {
        if (left.v.length !== right.v.length) throw new Error('Dimension ERROR');
        left = {
          kind: 'vct',
          v: left.v.map((val, idx) => (op === '+' ? val + right.v[idx] : val - right.v[idx])),
        };
      } else {
        const a = asComplex(left);
        const b = asComplex(right);
        left = { kind: 'num', c: op === '+' ? cAdd(a, b) : cSub(a, b) };
      }
    }
    return left;
  };

  const parseMulDiv = (): RuntimeVal => {
    let left = parseUnary();
    while (
      peek()?.type === 'op' &&
      ['×', '÷', 'DotP', 'CrossP'].includes((peek() as { value: string }).value)
    ) {
      const op = (consume() as { value: string }).value;
      const right = parseUnary();
      if (op === 'DotP') {
        if (left.kind !== 'vct' || right.kind !== 'vct' || left.v.length !== right.v.length) {
          throw new Error('Dimension ERROR');
        }
        const dot = left.v.reduce((acc, v, idx) => acc + v * right.v[idx], 0);
        left = { kind: 'num', c: { re: dot, im: 0 } };
      } else if (op === 'CrossP') {
        if (left.kind !== 'vct' || right.kind !== 'vct') throw new Error('Dimension ERROR');
        const a = left.v.length === 2 ? [...left.v, 0] : left.v;
        const b = right.v.length === 2 ? [...right.v, 0] : right.v;
        if (a.length !== 3 || b.length !== 3) throw new Error('Dimension ERROR');
        left = {
          kind: 'vct',
          v: [
            a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0],
          ],
        };
      } else if (op === '×') {
        if (left.kind === 'mat' && right.kind === 'mat') {
          left = { kind: 'mat', m: matMul(left.m, right.m) };
        } else if (left.kind === 'mat' && right.kind === 'num') {
          const s = asReal(right);
          left = { kind: 'mat', m: left.m.map((r) => r.map((v) => v * s)) };
        } else if (left.kind === 'num' && right.kind === 'mat') {
          const s = asReal(left);
          left = { kind: 'mat', m: right.m.map((r) => r.map((v) => v * s)) };
        } else if (left.kind === 'vct' && right.kind === 'num') {
          const s = asReal(right);
          left = { kind: 'vct', v: left.v.map((v) => v * s) };
        } else if (left.kind === 'num' && right.kind === 'vct') {
          const s = asReal(left);
          left = { kind: 'vct', v: right.v.map((v) => v * s) };
        } else {
          left = { kind: 'num', c: cMul(asComplex(left), asComplex(right)) };
        }
      } else {
        left = { kind: 'num', c: cDiv(asComplex(left), asComplex(right)) };
      }
    }
    return left;
  };

  const parseUnary = (): RuntimeVal => {
    if (peek()?.type === 'op' && ['+', '-'].includes((peek() as { value: string }).value)) {
      const op = (consume() as { value: string }).value;
      const val = parseUnary();
      if (op === '+') return val;
      if (val.kind === 'mat') {
        return { kind: 'mat', m: val.m.map((r) => r.map((v) => -v)) };
      }
      if (val.kind === 'vct') {
        return { kind: 'vct', v: val.v.map((v) => -v) };
      }
      return { kind: 'num', c: { re: -val.c.re, im: -val.c.im } };
    }
    return parseImplicitMul();
  };

  const parseImplicitMul = (): RuntimeVal => {
    let left = parseSpecialBinary();
    while (isImplicitMulStart(peek())) {
      const right = parseSpecialBinary();
      if (left.kind === 'mat' && right.kind === 'mat') {
        left = { kind: 'mat', m: matMul(left.m, right.m) };
      } else if (left.kind === 'num' && right.kind === 'mat') {
        const s = asReal(left);
        left = { kind: 'mat', m: right.m.map((r) => r.map((v) => v * s)) };
      } else if (left.kind === 'num' && right.kind === 'vct') {
        const s = asReal(left);
        left = { kind: 'vct', v: right.v.map((v) => v * s) };
      } else {
        left = { kind: 'num', c: cMul(asComplex(left), asComplex(right)) };
      }
    }
    return left;
  };

  const parseSpecialBinary = (): RuntimeVal => {
    let left = parseSciTen();
    while (
      peek()?.type === 'op' &&
      ['∠', 'nPr', 'nCr'].includes((peek() as { value: string }).value)
    ) {
      const op = (consume() as { value: string }).value;
      const right = parseSciTen();
      if (op === '∠') {
        const r = asReal(left);
        const theta = toRad(asReal(right), ctx.settings.angleUnit);
        left = { kind: 'num', c: { re: r * Math.cos(theta), im: r * Math.sin(theta) } };
      } else if (op === 'nPr') {
        left = { kind: 'num', c: { re: nPr(asReal(left), asReal(right)), im: 0 } };
      } else {
        left = { kind: 'num', c: { re: nCr(asReal(left), asReal(right)), im: 0 } };
      }
    }
    return left;
  };

  const parseSciTen = (): RuntimeVal => {
    let left = parsePower();
    while (peek()?.type === 'op' && (peek() as { value: string }).value === '×10^') {
      consume();
      const right = parseUnary();
      const factor = cPow({ re: 10, im: 0 }, asComplex(right));
      left = { kind: 'num', c: cMul(asComplex(left), factor) };
    }
    return left;
  };

  const parsePower = (): RuntimeVal => {
    let left = parsePostfix();
    while (
      (peek()?.type === 'op' && (peek() as { value: string }).value === '^') ||
      (peek()?.type === 'node' && (peek() as { node: MathNode }).node.type === 'sup')
    ) {
      const tok = consume();
      let expVal: RuntimeVal;
      if (tok.type === 'node' && tok.node.type === 'sup') {
        expVal = evalNodesInternal(tok.node.body, ctx, localVars);
      } else {
        expVal = parseUnary();
      }
      if (left.kind === 'mat') {
        const p = asReal(expVal);
        if (p === -1) {
          left = { kind: 'mat', m: matInv(left.m) };
        } else if (Number.isInteger(p) && p >= 1 && p <= 20) {
          let res = left.m;
          for (let k = 1; k < p; k++) res = matMul(res, left.m);
          left = { kind: 'mat', m: res };
        } else {
          throw new Error('Math ERROR');
        }
      } else {
        left = { kind: 'num', c: cPow(asComplex(left), asComplex(expVal)) };
      }
    }
    return left;
  };

  const parsePostfix = (): RuntimeVal => {
    let val = parsePrimary();
    while (peek()?.type === 'postfix') {
      const op = (consume() as { value: string }).value;
      if (val.kind === 'mat') {
        if (op === '⁻¹') val = { kind: 'mat', m: matInv(val.m) };
        else if (op === '²') val = { kind: 'mat', m: matMul(val.m, val.m) };
        else if (op === '³') val = { kind: 'mat', m: matMul(matMul(val.m, val.m), val.m) };
        else throw new Error('Syntax ERROR');
        continue;
      }
      const c = asComplex(val);
      if (op === '²') val = { kind: 'num', c: cMul(c, c) };
      else if (op === '³') val = { kind: 'num', c: cMul(cMul(c, c), c) };
      else if (op === '⁻¹') val = { kind: 'num', c: cDiv({ re: 1, im: 0 }, c) };
      else if (op === '!') val = { kind: 'num', c: { re: factorial(asReal(val)), im: 0 } };
      else if (op === '%') val = { kind: 'num', c: cDiv(c, { re: 100, im: 0 }) };
      else if (op === '°') {
        const rad = (asReal(val) * Math.PI) / 180;
        val = { kind: 'num', c: { re: fromRad(rad, ctx.settings.angleUnit), im: 0 } };
      } else if (op === 'ʳ') {
        const rad = asReal(val);
        val = { kind: 'num', c: { re: fromRad(rad, ctx.settings.angleUnit), im: 0 } };
      } else if (op === 'ᵍ') {
        const rad = (asReal(val) * Math.PI) / 200;
        val = { kind: 'num', c: { re: fromRad(rad, ctx.settings.angleUnit), im: 0 } };
      }
    }
    return val;
  };

  const parseArgs = (): RuntimeVal[] => {
    const args: RuntimeVal[] = [];
    if (peek()?.type === 'rparen') {
      consume();
      return args;
    }
    args.push(parseExpr());
    while (peek()?.type === 'sep') {
      consume();
      args.push(parseExpr());
    }
    if (peek()?.type === 'rparen') {
      consume();
    }
    return args;
  };

  const parsePrimary = (): RuntimeVal => {
    const tok = peek();
    if (!tok) throw new Error('Syntax ERROR');

    if (tok.type === 'number') {
      consume();
      return { kind: 'num', c: { re: tok.value, im: 0 } };
    }
    if (tok.type === 'imag') {
      consume();
      if (ctx.mode !== 'CMPLX') throw new Error('Syntax ERROR');
      return { kind: 'num', c: { re: 0, im: tok.value } };
    }
    if (tok.type === 'ran') {
      consume();
      return { kind: 'num', c: { re: Math.random(), im: 0 } };
    }
    if (tok.type === 'ans') {
      consume();
      if (!ctx.ans || !ctx.ans.ok) return { kind: 'num', c: { re: 0, im: 0 } };
      if (ctx.ans.type === 'complex' && ctx.ans.complex) return { kind: 'num', c: ctx.ans.complex };
      if (ctx.ans.type === 'matrix' && ctx.ans.matrix) return { kind: 'mat', m: ctx.ans.matrix };
      if (ctx.ans.type === 'vector' && ctx.ans.vector) return { kind: 'vct', v: ctx.ans.vector };
      if (ctx.ans.type === 'base' && ctx.ans.baseInt !== undefined) {
        return { kind: 'num', c: { re: ctx.ans.baseInt, im: 0 } };
      }
      return { kind: 'num', c: { re: ctx.ans.real ?? 0, im: 0 } };
    }
    if (tok.type === 'var') {
      consume();
      const name = tok.name as VarName;
      const c = localVars?.[name] ?? ctx.vars[name] ?? { re: 0, im: 0 };
      return { kind: 'num', c };
    }
    if (tok.type === 'mat') {
      consume();
      const m = ctx.matrices[tok.name];
      if (!m || m.length === 0) throw new Error('Dimension ERROR');
      return { kind: 'mat', m };
    }
    if (tok.type === 'vct') {
      consume();
      const v = ctx.vectors[tok.name];
      if (!v || v.length === 0) throw new Error('Dimension ERROR');
      return { kind: 'vct', v };
    }
    if (tok.type === 'lparen') {
      consume();
      const val = parseExpr();
      if (peek()?.type === 'rparen') consume();
      return val;
    }
    if (tok.type === 'func') {
      consume();
      const args = parseArgs();
      return evalFunctionCall(tok.name, args, ctx);
    }
    if (tok.type === 'node') {
      consume();
      return evalSingleNode(tok.node, ctx, localVars);
    }
    throw new Error('Syntax ERROR');
  };

  const result = parseExpr();
  if (pos < tokens.length) throw new Error('Syntax ERROR');
  return result;
}

function evalFunctionCall(name: string, args: RuntimeVal[], ctx: EvalContext): RuntimeVal {
  const fn = name.replace(/\($/, '');
  const u = ctx.settings.angleUnit;

  if (args.length === 0) throw new Error('Argument ERROR');

  // Matrix / Vector functions
  if (fn === 'Det') {
    if (args[0].kind !== 'mat') throw new Error('Syntax ERROR');
    return { kind: 'num', c: { re: matDet(args[0].m), im: 0 } };
  }
  if (fn === 'Trn') {
    if (args[0].kind !== 'mat') throw new Error('Syntax ERROR');
    return { kind: 'mat', m: matTrn(args[0].m) };
  }
  if (fn === 'Identity') {
    const n = asReal(args[0]);
    if (!Number.isInteger(n) || n < 1 || n > 4) throw new Error('Dimension ERROR');
    return {
      kind: 'mat',
      m: Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))),
    };
  }
  if (fn === 'UnitV') {
    if (args[0].kind !== 'vct') throw new Error('Syntax ERROR');
    const mag = Math.hypot(...args[0].v);
    if (mag === 0) throw new Error('Math ERROR');
    return { kind: 'vct', v: args[0].v.map((x) => x / mag) };
  }
  if (fn === 'Angle') {
    if (args.length < 2 || args[0].kind !== 'vct' || args[1].kind !== 'vct') {
      throw new Error('Argument ERROR');
    }
    const a = args[0].v;
    const b = args[1].v;
    if (a.length !== b.length) throw new Error('Dimension ERROR');
    const dot = a.reduce((s, v, i) => s + v * b[i], 0);
    const ma = Math.hypot(...a);
    const mb = Math.hypot(...b);
    if (ma === 0 || mb === 0) throw new Error('Math ERROR');
    const cosT = Math.max(-1, Math.min(1, dot / (ma * mb)));
    return { kind: 'num', c: { re: fromRad(Math.acos(cosT), u), im: 0 } };
  }
  if (fn === 'Abs') {
    if (args[0].kind === 'vct') {
      return { kind: 'num', c: { re: Math.hypot(...args[0].v), im: 0 } };
    }
    return { kind: 'num', c: { re: cAbs(asComplex(args[0])), im: 0 } };
  }

  // Base-N bitwise unary functions
  if (fn === 'Not') {
    const a = Math.trunc(asReal(args[0])) | 0;
    return { kind: 'num', c: { re: ~a | 0, im: 0 } };
  }
  if (fn === 'Neg') {
    const a = Math.trunc(asReal(args[0])) | 0;
    return { kind: 'num', c: { re: -a | 0, im: 0 } };
  }

  // Complex-specific functions
  if (fn === 'Arg') {
    const c = asComplex(args[0]);
    if (c.re === 0 && c.im === 0) throw new Error('Math ERROR');
    return { kind: 'num', c: { re: fromRad(cArgRad(c), u), im: 0 } };
  }
  if (fn === 'Conjg') {
    const c = asComplex(args[0]);
    return { kind: 'num', c: { re: c.re, im: -c.im } };
  }
  if (fn === 'ReP') {
    return { kind: 'num', c: { re: asComplex(args[0]).re, im: 0 } };
  }
  if (fn === 'ImP') {
    return { kind: 'num', c: { re: asComplex(args[0]).im, im: 0 } };
  }

  // Multi-arg numeric functions
  if (fn === 'GCD') {
    if (args.length < 2) throw new Error('Argument ERROR');
    return { kind: 'num', c: { re: gcdInt(asReal(args[0]), asReal(args[1])), im: 0 } };
  }
  if (fn === 'LCM') {
    if (args.length < 2) throw new Error('Argument ERROR');
    return { kind: 'num', c: { re: lcmInt(asReal(args[0]), asReal(args[1])), im: 0 } };
  }
  if (fn === 'RanInt') {
    if (args.length < 2) throw new Error('Argument ERROR');
    const a = Math.ceil(asReal(args[0]));
    const b = Math.floor(asReal(args[1]));
    if (a > b) throw new Error('Math ERROR');
    return { kind: 'num', c: { re: Math.floor(Math.random() * (b - a + 1)) + a, im: 0 } };
  }
  if (fn === 'RndFix') {
    if (args.length < 2) throw new Error('Argument ERROR');
    const x = asReal(args[0]);
    const d = Math.max(0, Math.min(9, Math.round(asReal(args[1]))));
    const f = Math.pow(10, d);
    return { kind: 'num', c: { re: Math.round(x * f) / f, im: 0 } };
  }
  if (fn === 'Rnd') {
    const x = asReal(args[0]);
    const d = ctx.settings.numberFormat === 'FIX' ? ctx.settings.formatDigits : 10;
    const f = Math.pow(10, d);
    return { kind: 'num', c: { re: Math.round(x * f) / f, im: 0 } };
  }
  if (fn === 'Int') {
    return { kind: 'num', c: { re: Math.trunc(asReal(args[0])), im: 0 } };
  }
  if (fn === 'Intg') {
    return { kind: 'num', c: { re: Math.floor(asReal(args[0])), im: 0 } };
  }

  // Standard 1-arg math functions (with complex support)
  const c = asComplex(args[0]);
  if (fn === 'sin') {
    if (Math.abs(c.im) < 1e-13) return { kind: 'num', c: { re: Math.sin(toRad(c.re, u)), im: 0 } };
    return { kind: 'num', c: cSin({ re: toRad(c.re, u), im: toRad(c.im, u) }) };
  }
  if (fn === 'cos') {
    if (Math.abs(c.im) < 1e-13) return { kind: 'num', c: { re: Math.cos(toRad(c.re, u)), im: 0 } };
    return { kind: 'num', c: cCos({ re: toRad(c.re, u), im: toRad(c.im, u) }) };
  }
  if (fn === 'tan') {
    if (Math.abs(c.im) < 1e-13) {
      const r = toRad(c.re, u);
      if (Math.abs(Math.cos(r)) < 1e-14) throw new Error('Math ERROR');
      return { kind: 'num', c: { re: Math.tan(r), im: 0 } };
    }
    return { kind: 'num', c: cTan({ re: toRad(c.re, u), im: toRad(c.im, u) }) };
  }
  if (fn === 'sin⁻¹') {
    const x = asReal(args[0]);
    if (x < -1 || x > 1) throw new Error('Math ERROR');
    return { kind: 'num', c: { re: fromRad(Math.asin(x), u), im: 0 } };
  }
  if (fn === 'cos⁻¹') {
    const x = asReal(args[0]);
    if (x < -1 || x > 1) throw new Error('Math ERROR');
    return { kind: 'num', c: { re: fromRad(Math.acos(x), u), im: 0 } };
  }
  if (fn === 'tan⁻¹') {
    const x = asReal(args[0]);
    return { kind: 'num', c: { re: fromRad(Math.atan(x), u), im: 0 } };
  }
  if (fn === 'sinh') {
    const x = asReal(args[0]);
    return { kind: 'num', c: { re: Math.sinh(x), im: 0 } };
  }
  if (fn === 'cosh') {
    const x = asReal(args[0]);
    return { kind: 'num', c: { re: Math.cosh(x), im: 0 } };
  }
  if (fn === 'tanh') {
    const x = asReal(args[0]);
    return { kind: 'num', c: { re: Math.tanh(x), im: 0 } };
  }
  if (fn === 'sinh⁻¹') {
    return { kind: 'num', c: { re: Math.asinh(asReal(args[0])), im: 0 } };
  }
  if (fn === 'cosh⁻¹') {
    const x = asReal(args[0]);
    if (x < 1) throw new Error('Math ERROR');
    return { kind: 'num', c: { re: Math.acosh(x), im: 0 } };
  }
  if (fn === 'tanh⁻¹') {
    const x = asReal(args[0]);
    if (x <= -1 || x >= 1) throw new Error('Math ERROR');
    return { kind: 'num', c: { re: Math.atanh(x), im: 0 } };
  }
  if (fn === 'ln') {
    if (c.im === 0 && c.re > 0) return { kind: 'num', c: { re: Math.log(c.re), im: 0 } };
    if (ctx.mode === 'CMPLX') return { kind: 'num', c: cLn(c) };
    throw new Error('Math ERROR');
  }
  if (fn === 'log') {
    if (c.im === 0 && c.re > 0) return { kind: 'num', c: { re: Math.log10(c.re), im: 0 } };
    if (ctx.mode === 'CMPLX') {
      const l = cLn(c);
      return { kind: 'num', c: { re: l.re / Math.LN10, im: l.im / Math.LN10 } };
    }
    throw new Error('Math ERROR');
  }

  throw new Error('Syntax ERROR');
}

function evalSingleNode(node: MathNode, ctx: EvalContext, localVars?: Partial<VariablesMap>): RuntimeVal {
  switch (node.type) {
    case 'fraction': {
      const num = evalNodesInternal(node.num, ctx, localVars);
      const den = evalNodesInternal(node.den, ctx, localVars);
      return { kind: 'num', c: cDiv(asComplex(num), asComplex(den)) };
    }
    case 'mixedFraction': {
      const w = asReal(evalNodesInternal(node.whole, ctx, localVars));
      const n = asReal(evalNodesInternal(node.num, ctx, localVars));
      const d = asReal(evalNodesInternal(node.den, ctx, localVars));
      if (d === 0) throw new Error('Math ERROR');
      const sign = w < 0 ? -1 : 1;
      return { kind: 'num', c: { re: sign * (Math.abs(w) + n / d), im: 0 } };
    }
    case 'sqrt': {
      const c = asComplex(evalNodesInternal(node.body, ctx, localVars));
      if (c.im === 0 && c.re >= 0) return { kind: 'num', c: { re: Math.sqrt(c.re), im: 0 } };
      if (ctx.mode === 'CMPLX') return { kind: 'num', c: cPow(c, { re: 0.5, im: 0 }) };
      throw new Error('Math ERROR');
    }
    case 'cbrt': {
      const c = asComplex(evalNodesInternal(node.body, ctx, localVars));
      if (c.im === 0) return { kind: 'num', c: { re: Math.cbrt(c.re), im: 0 } };
      return { kind: 'num', c: cPow(c, { re: 1 / 3, im: 0 }) };
    }
    case 'nroot': {
      const idx = asReal(evalNodesInternal(node.index, ctx, localVars));
      if (idx === 0) throw new Error('Math ERROR');
      const body = asComplex(evalNodesInternal(node.body, ctx, localVars));
      if (body.im === 0 && body.re < 0 && Number.isInteger(idx) && Math.abs(idx % 2) === 1) {
        return { kind: 'num', c: { re: -Math.pow(-body.re, 1 / idx), im: 0 } };
      }
      if (body.im === 0 && body.re < 0 && ctx.mode !== 'CMPLX') throw new Error('Math ERROR');
      return { kind: 'num', c: cPow(body, { re: 1 / idx, im: 0 }) };
    }
    case 'logBase': {
      const base = asReal(evalNodesInternal(node.base, ctx, localVars));
      const body = asReal(evalNodesInternal(node.body, ctx, localVars));
      if (base <= 0 || base === 1 || body <= 0) throw new Error('Math ERROR');
      return { kind: 'num', c: { re: Math.log(body) / Math.log(base), im: 0 } };
    }
    case 'abs': {
      const val = evalNodesInternal(node.body, ctx, localVars);
      if (val.kind === 'vct') return { kind: 'num', c: { re: Math.hypot(...val.v), im: 0 } };
      return { kind: 'num', c: { re: cAbs(asComplex(val)), im: 0 } };
    }
    case 'integral': {
      const a = asReal(evalNodesInternal(node.lower, ctx, localVars));
      const b = asReal(evalNodesInternal(node.upper, ctx, localVars));
      const f = (xVal: number) =>
        asReal(evalNodesInternal(node.expr, ctx, { ...localVars, x: { re: xVal, im: 0 } }));
      return { kind: 'num', c: { re: adaptiveSimpson(f, a, b), im: 0 } };
    }
    case 'derivative': {
      const at = asReal(evalNodesInternal(node.at, ctx, localVars));
      const f = (xVal: number) =>
        asReal(evalNodesInternal(node.expr, ctx, { ...localVars, x: { re: xVal, im: 0 } }));
      const h = Math.max(1e-5, Math.abs(at) * 1e-5);
      // 5-point central stencil for high accuracy
      const deriv = (-f(at + 2 * h) + 8 * f(at + h) - 8 * f(at - h) + f(at - 2 * h)) / (12 * h);
      return { kind: 'num', c: { re: deriv, im: 0 } };
    }
    case 'sum': {
      const lo = Math.round(asReal(evalNodesInternal(node.lower, ctx, localVars)));
      const hi = Math.round(asReal(evalNodesInternal(node.upper, ctx, localVars)));
      if (hi - lo > 10000) throw new Error('Math ERROR');
      let acc = 0;
      for (let k = lo; k <= hi; k++) {
        acc += asReal(evalNodesInternal(node.expr, ctx, { ...localVars, x: { re: k, im: 0 } }));
      }
      return { kind: 'num', c: { re: acc, im: 0 } };
    }
    case 'prod': {
      const lo = Math.round(asReal(evalNodesInternal(node.lower, ctx, localVars)));
      const hi = Math.round(asReal(evalNodesInternal(node.upper, ctx, localVars)));
      if (hi - lo > 2000) throw new Error('Math ERROR');
      let acc = 1;
      for (let k = lo; k <= hi; k++) {
        acc *= asReal(evalNodesInternal(node.expr, ctx, { ...localVars, x: { re: k, im: 0 } }));
      }
      return { kind: 'num', c: { re: acc, im: 0 } };
    }
    default:
      throw new Error('Syntax ERROR');
  }
}

function adaptiveSimpson(f: (x: number) => number, a: number, b: number): number {
  if (a === b) return 0;
  const sign = a > b ? -1 : 1;
  if (a > b) [a, b] = [b, a];

  const simpson = (l: number, r: number, fl: number, fm: number, fr: number) =>
    ((r - l) / 6) * (fl + 4 * fm + fr);

  const recurse = (
    l: number,
    r: number,
    eps: number,
    whole: number,
    fl: number,
    fm: number,
    fr: number,
    depth: number
  ): number => {
    const m = (l + r) / 2;
    const lm = (l + m) / 2;
    const rm = (m + r) / 2;
    const flm = f(lm);
    const frm = f(rm);
    const left = simpson(l, m, fl, flm, fm);
    const right = simpson(m, r, fm, frm, fr);
    const delta = left + right - whole;
    if (depth <= 0 || Math.abs(delta) <= 15 * eps) {
      return left + right + delta / 15;
    }
    return (
      recurse(l, m, eps / 2, left, fl, flm, fm, depth - 1) +
      recurse(m, r, eps / 2, right, fm, frm, fr, depth - 1)
    );
  };

  const m = (a + b) / 2;
  const fa = f(a);
  const fm = f(m);
  const fb = f(b);
  const whole = simpson(a, b, fa, fm, fb);
  return sign * recurse(a, b, 1e-8, whole, fa, fm, fb, 12);
}

function evalNodesInternal(
  nodes: MathNode[],
  ctx: EvalContext,
  localVars?: Partial<VariablesMap>
): RuntimeVal {
  const tokens = tokenizeNodes(nodes, ctx);
  return evalTokens(tokens, ctx, localVars);
}

// ---------- Public Evaluation Entry Point ----------
export function evaluateExpression(nodes: MathNode[], ctx: EvalContext, forceDecimal = false): EvalResult {
  try {
    if (nodes.length === 0) {
      return { ok: false, error: 'Syntax ERROR', type: 'real' };
    }

    // Check top-level multi-statement ':'
    const colonIndices: number[] = [];
    nodes.forEach((n, idx) => {
      if (n.type === 'char' && n.value === ':') colonIndices.push(idx);
    });
    if (colonIndices.length > 0) {
      let start = 0;
      let lastRes: EvalResult = { ok: false, error: 'Syntax ERROR', type: 'real' };
      for (const idx of [...colonIndices, nodes.length]) {
        const sub = nodes.slice(start, idx);
        start = idx + 1;
        if (sub.length === 0) continue;
        lastRes = evaluateExpression(sub, ctx, forceDecimal);
        if (!lastRes.ok) return lastRes;
      }
      return lastRes;
    }

    // Check top-level Pol(x;y) or Rec(r;θ)
    if (nodes[0].type === 'func' && (nodes[0].name === 'Pol(' || nodes[0].name === 'Rec(')) {
      const lastNode = nodes[nodes.length - 1];
      const inner = nodes.slice(1, lastNode?.type === 'char' && lastNode.value === ')' ? -1 : undefined);
      const sepIdx = inner.findIndex((n) => n.type === 'char' && n.value === ';');
      if (sepIdx <= 0) throw new Error('Argument ERROR');
      const arg1 = asReal(evalNodesInternal(inner.slice(0, sepIdx), ctx));
      const arg2 = asReal(evalNodesInternal(inner.slice(sepIdx + 1), ctx));
      if (nodes[0].name === 'Pol(') {
        const r = Math.hypot(arg1, arg2);
        const theta = fromRad(Math.atan2(arg2, arg1), ctx.settings.angleUnit);
        ctx.vars.x = { re: r, im: 0 };
        ctx.vars.y = { re: theta, im: 0 };
        return {
          ok: true,
          type: 'polrec',
          real: r,
          polRec: { label1: 'r', val1: r, label2: 'θ', val2: theta },
        };
      } else {
        const rad = toRad(arg2, ctx.settings.angleUnit);
        const x = arg1 * Math.cos(rad);
        const y = arg1 * Math.sin(rad);
        ctx.vars.x = { re: x, im: 0 };
        ctx.vars.y = { re: y, im: 0 };
        return {
          ok: true,
          type: 'polrec',
          real: x,
          polRec: { label1: 'x', val1: x, label2: 'y', val2: y },
        };
      }
    }

    // Check top-level ÷R (integer division with remainder)
    const divRemIdx = nodes.findIndex((n) => n.type === 'char' && n.value === '÷R');
    if (divRemIdx > 0) {
      const a = Math.trunc(asReal(evalNodesInternal(nodes.slice(0, divRemIdx), ctx)));
      const b = Math.trunc(asReal(evalNodesInternal(nodes.slice(divRemIdx + 1), ctx)));
      if (b === 0) throw new Error('Math ERROR');
      const q = Math.trunc(a / b);
      const r = a - q * b;
      return {
        ok: true,
        type: 'divrem',
        real: q,
        divRem: { quotient: q, remainder: r },
      };
    }

    const val = evalNodesInternal(nodes, ctx);

    if (val.kind === 'mat') {
      return { ok: true, type: 'matrix', matrix: val.m };
    }
    if (val.kind === 'vct') {
      return { ok: true, type: 'vector', vector: val.v };
    }

    const c = val.c;
    if (!Number.isFinite(c.re) || !Number.isFinite(c.im)) {
      throw new Error('Math ERROR');
    }

    if (ctx.mode === 'BASE') {
      if (Math.abs(c.im) > 1e-11) throw new Error('Math ERROR');
      return { ok: true, type: 'base', baseInt: Math.trunc(c.re) | 0, real: Math.trunc(c.re) | 0 };
    }

    if (ctx.mode === 'CMPLX' && Math.abs(c.im) > 1e-12) {
      return {
        ok: true,
        type: 'complex',
        complex: {
          re: Math.abs(c.re) < 1e-13 ? 0 : c.re,
          im: Math.abs(c.im) < 1e-13 ? 0 : c.im,
        },
        real: c.re,
      };
    }

    if (Math.abs(c.im) > 1e-11) {
      throw new Error('Math ERROR');
    }

    const real = Math.abs(c.re) < 1e-13 ? 0 : c.re;
    const exact = !forceDecimal
      ? tryExactRepresentation(real, ctx.settings.fractionDisplay === 'MIXED')
      : undefined;

    return {
      ok: true,
      type: 'real',
      real,
      complex: { re: real, im: 0 },
      exact,
      preferExact: Boolean(exact) && !forceDecimal,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Syntax ERROR';
    return {
      ok: false,
      error: msg.includes('ERROR') ? msg : 'Syntax ERROR',
      type: 'real',
    };
  }
}

export function evaluateWithLocalVars(
  nodes: MathNode[],
  ctx: EvalContext,
  overrides: Partial<VariablesMap>
): number {
  const res = evalNodesInternal(nodes, ctx, overrides);
  return asReal(res);
}

/**
 * Newton-Raphson + Secant numerical equation solver for SHIFT + CALC (SOLVE)
 */
export function solveEquationNodes(
  nodes: MathNode[],
  ctx: EvalContext,
  solveVar: VarName,
  initialGuess: number,
  fixedVars: Partial<VariablesMap>
): { ok: boolean; value?: number; error?: string } {
  try {
    const eqIdx = nodes.findIndex((n) => n.type === 'char' && n.value === '=');
    const lhs = eqIdx >= 0 ? nodes.slice(0, eqIdx) : nodes;
    const rhs = eqIdx >= 0 ? nodes.slice(eqIdx + 1) : [];

    const evalAt = (v: number): number => {
      const vars = { ...fixedVars, [solveVar]: { re: v, im: 0 } };
      const l = asReal(evalNodesInternal(lhs, ctx, vars));
      const r = rhs.length > 0 ? asReal(evalNodesInternal(rhs, ctx, vars)) : 0;
      return l - r;
    };

    let x = Number.isFinite(initialGuess) ? initialGuess : 0;
    for (let iter = 0; iter < 80; iter++) {
      const fx = evalAt(x);
      if (!Number.isFinite(fx)) {
        x += 0.37;
        continue;
      }
      if (Math.abs(fx) < 1e-11) return { ok: true, value: x };
      const h = Math.max(1e-7, Math.abs(x) * 1e-7);
      const dfx = (evalAt(x + h) - evalAt(x - h)) / (2 * h);
      if (!Number.isFinite(dfx) || Math.abs(dfx) < 1e-14) {
        x += 0.13;
        continue;
      }
      const step = fx / dfx;
      const nextX = x - Math.max(-1e4, Math.min(1e4, step));
      if (Math.abs(nextX - x) < 1e-11 && Math.abs(evalAt(nextX)) < 1e-7) {
        return { ok: true, value: nextX };
      }
      x = nextX;
    }

    if (Math.abs(evalAt(x)) < 1e-6) return { ok: true, value: x };
    return { ok: false, error: 'Can’t Solve' };
  } catch {
    return { ok: false, error: 'Math ERROR' };
  }
}
