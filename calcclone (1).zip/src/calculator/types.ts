export type AngleUnit = 'DEG' | 'RAD' | 'GRA';

export type CalcMode =
  | 'COMP'
  | 'CMPLX'
  | 'BASE'
  | 'MATRIX'
  | 'VECTOR'
  | 'STAT'
  | 'DIST'
  | 'SHEET'
  | 'TABLE'
  | 'EQN'
  | 'INEQ'
  | 'RATIO';

export type BaseMode = 'DEC' | 'HEX' | 'BIN' | 'OCT';

export type NumberFormatType = 'NORM1' | 'NORM2' | 'FIX' | 'SCI';

export type ComplexFormat = 'RECT' | 'POLAR';

export type FractionDisplay = 'IMPROPER' | 'MIXED';

export type DecimalMark = 'DOT' | 'COMMA';

export interface CalcSettings {
  angleUnit: AngleUnit;
  numberFormat: NumberFormatType;
  formatDigits: number;
  complexFormat: ComplexFormat;
  fractionDisplay: FractionDisplay;
  decimalMark: DecimalMark;
  digitSeparator: boolean;
  engSymbol: boolean;
  statFrequency: boolean;
  tableTwoFuncs: boolean;
  soundEnabled: boolean;
}

export type MathNode =
  | { id: string; type: 'char'; value: string }
  | { id: string; type: 'func'; name: string }
  | { id: string; type: 'const'; symbol: string; value: number; unit?: string }
  | { id: string; type: 'fraction'; num: MathNode[]; den: MathNode[] }
  | { id: string; type: 'mixedFraction'; whole: MathNode[]; num: MathNode[]; den: MathNode[] }
  | { id: string; type: 'sqrt'; body: MathNode[] }
  | { id: string; type: 'cbrt'; body: MathNode[] }
  | { id: string; type: 'nroot'; index: MathNode[]; body: MathNode[] }
  | { id: string; type: 'sup'; body: MathNode[] }
  | { id: string; type: 'logBase'; base: MathNode[]; body: MathNode[] }
  | { id: string; type: 'abs'; body: MathNode[] }
  | { id: string; type: 'integral'; expr: MathNode[]; lower: MathNode[]; upper: MathNode[] }
  | { id: string; type: 'derivative'; expr: MathNode[]; at: MathNode[] }
  | { id: string; type: 'sum'; expr: MathNode[]; lower: MathNode[]; upper: MathNode[] }
  | { id: string; type: 'prod'; expr: MathNode[]; lower: MathNode[]; upper: MathNode[] };

export interface PathStep {
  nodeId: string;
  slot: string;
}

export interface CursorPos {
  path: PathStep[];
  index: number;
}

export interface ComplexVal {
  re: number;
  im: number;
}

export type MatrixData = number[][];
export type VectorData = number[];

export interface ExactResult {
  kind: 'rational' | 'surd' | 'pi' | 'mixed';
  displayNum?: string;
  displayDen?: string;
  displayWhole?: string;
  decimalValue: number;
  texLike: string;
}

export interface EvalResult {
  ok: boolean;
  error?: string;
  type: 'real' | 'complex' | 'base' | 'matrix' | 'vector' | 'polrec' | 'divrem' | 'fact';
  real?: number;
  complex?: ComplexVal;
  baseInt?: number;
  matrix?: MatrixData;
  vector?: VectorData;
  polRec?: { label1: string; val1: number; label2: string; val2: number };
  divRem?: { quotient: number; remainder: number };
  factStr?: string;
  exact?: ExactResult;
  /** True if result is displayed as exact symbolic/fraction by default */
  preferExact?: boolean;
}

export interface HistoryEntry {
  expr: MathNode[];
  result: EvalResult;
}

export type VarName = 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'x' | 'y' | 'M';

export type VariablesMap = Record<VarName, ComplexVal>;

export interface StatRow {
  x: number;
  y: number;
  freq: number;
}

export type StatType =
  | '1-VAR'
  | 'LINEAR'
  | 'QUAD'
  | 'LOG'
  | 'E_EXP'
  | 'AB_EXP'
  | 'POWER'
  | 'INV';

export type DistType =
  | 'NORMAL_PD'
  | 'NORMAL_CD'
  | 'INV_NORMAL'
  | 'BINOMIAL_PD'
  | 'BINOMIAL_CD'
  | 'POISSON_PD'
  | 'POISSON_CD';

export type LcdScreen =
  | { type: 'CALC' }
  | { type: 'MENU'; selected: number }
  | { type: 'SETUP'; page: number }
  | { type: 'OPTN'; category?: string }
  | { type: 'CONST'; category?: number }
  | { type: 'CONV'; category?: number }
  | { type: 'RESET'; confirm?: string }
  | { type: 'CALC_PROMPT'; vars: VarName[]; currentIdx: number; values: Record<string, string>; targetExpr: MathNode[] }
  | { type: 'SOLVE_PROMPT'; vars: VarName[]; currentIdx: number; values: Record<string, string>; solveVar: VarName; targetExpr: MathNode[] }
  | { type: 'STAT_SELECT' }
  | { type: 'STAT_EDITOR'; row: number; col: number; input: string }
  | { type: 'STAT_RESULT'; mode: '1-VAR' | 'REG'; page: number }
  | { type: 'MATRIX_SELECT'; action: 'EDIT' | 'DIM' }
  | { type: 'MATRIX_DIM'; target: 'MatA' | 'MatB' | 'MatC' | 'MatD'; rows: number; cols: number; step: 'ROWS' | 'COLS' }
  | { type: 'MATRIX_EDIT'; target: 'MatA' | 'MatB' | 'MatC' | 'MatD'; r: number; c: number; input: string }
  | { type: 'VECTOR_SELECT' }
  | { type: 'VECTOR_DIM'; target: 'VctA' | 'VctB' | 'VctC' }
  | { type: 'VECTOR_EDIT'; target: 'VctA' | 'VctB' | 'VctC'; idx: number; input: string }
  | { type: 'TABLE_SETUP'; step: 'F' | 'G' | 'START' | 'END' | 'STEP'; fExpr: MathNode[]; gExpr: MathNode[]; start: string; end: string; stepVal: string }
  | { type: 'TABLE_VIEW'; rows: Array<{ x: number; fx: string; gx?: string }>; scroll: number; showG: boolean }
  | { type: 'EQN_MENU' }
  | { type: 'EQN_DIM'; kind: 'SIMUL' | 'POLY' }
  | { type: 'EQN_INPUT'; kind: 'SIMUL' | 'POLY'; degree: number; coeffs: number[][]; r: number; c: number; input: string }
  | { type: 'EQN_RESULT'; lines: Array<{ label: string; value: string }>; scroll: number }
  | { type: 'INEQ_DEGREE' }
  | { type: 'INEQ_OP'; degree: number }
  | { type: 'INEQ_INPUT'; degree: number; op: '<' | '>' | '≤' | '≥'; coeffs: number[]; idx: number; input: string }
  | { type: 'INEQ_RESULT'; text: string }
  | { type: 'RATIO_TYPE' }
  | { type: 'RATIO_INPUT'; form: 'AB_XC' | 'AB_CX'; vals: [string, string, string]; idx: number }
  | { type: 'RATIO_RESULT'; x: string }
  | { type: 'DIST_MENU' }
  | { type: 'DIST_INPUT'; dist: DistType; fields: Array<{ label: string; value: string }>; idx: number }
  | { type: 'DIST_RESULT'; label: string; value: string }
  | { type: 'SHEET_GRID'; r: number; c: number; input: string; editing: boolean }
  | { type: 'QR_VIEW'; payload: string }
  | { type: 'HELP_KEYS' };
