export interface ScientificConstant {
  code: string;
  symbol: string;
  name: string;
  value: number;
  unit: string;
  category: string;
}

export interface UnitConversion {
  code: string;
  label: string;
  fromUnit: string;
  toUnit: string;
  category: string;
  convert: (x: number) => number;
}

export const CONST_CATEGORIES = [
  'Universal',
  'Electromagnetic',
  'Atomic & Nuclear',
  'Physico-chem',
  'Adopted & Other',
] as const;

export const SCIENTIFIC_CONSTANTS: ScientificConstant[] = [
  // Universal (11)
  { code: '01', symbol: 'h', name: 'Planck constant', value: 6.62607015e-34, unit: 'J·s', category: 'Universal' },
  { code: '02', symbol: 'ħ', name: 'Reduced Planck', value: 1.054571817e-34, unit: 'J·s', category: 'Universal' },
  { code: '03', symbol: 'c0', name: 'Speed of light', value: 299792458, unit: 'm/s', category: 'Universal' },
  { code: '04', symbol: 'ε0', name: 'Electric constant', value: 8.8541878128e-12, unit: 'F/m', category: 'Universal' },
  { code: '05', symbol: 'μ0', name: 'Magnetic constant', value: 1.25663706212e-6, unit: 'N/A²', category: 'Universal' },
  { code: '06', symbol: 'Z0', name: 'Impedance of vac', value: 376.730313668, unit: 'Ω', category: 'Universal' },
  { code: '07', symbol: 'G', name: 'Newtonian grav.', value: 6.6743e-11, unit: 'm³/(kg·s²)', category: 'Universal' },
  { code: '08', symbol: 'ℓP', name: 'Planck length', value: 1.616255e-35, unit: 'm', category: 'Universal' },
  { code: '09', symbol: 'mP', name: 'Planck mass', value: 2.176434e-8, unit: 'kg', category: 'Universal' },
  { code: '10', symbol: 'tP', name: 'Planck time', value: 5.391247e-44, unit: 's', category: 'Universal' },
  { code: '11', symbol: 'TP', name: 'Planck temp.', value: 1.416784e32, unit: 'K', category: 'Universal' },

  // Electromagnetic (7)
  { code: '12', symbol: 'μN', name: 'Nuclear magneton', value: 5.0507837461e-27, unit: 'J/T', category: 'Electromagnetic' },
  { code: '13', symbol: 'μB', name: 'Bohr magneton', value: 9.2740100783e-24, unit: 'J/T', category: 'Electromagnetic' },
  { code: '14', symbol: 'e', name: 'Elementary charge', value: 1.602176634e-19, unit: 'C', category: 'Electromagnetic' },
  { code: '15', symbol: 'Φ0', name: 'Mag. flux quantum', value: 2.067833848e-15, unit: 'Wb', category: 'Electromagnetic' },
  { code: '16', symbol: 'G0', name: 'Conductance quant.', value: 7.748091729e-5, unit: 'S', category: 'Electromagnetic' },
  { code: '17', symbol: 'KJ', name: 'Josephson const', value: 4.835978484e14, unit: 'Hz/V', category: 'Electromagnetic' },
  { code: '18', symbol: 'RK', name: 'von Klitzing const', value: 25812.80745, unit: 'Ω', category: 'Electromagnetic' },

  // Atomic & Nuclear (17)
  { code: '19', symbol: 'mp', name: 'Proton mass', value: 1.67262192369e-27, unit: 'kg', category: 'Atomic & Nuclear' },
  { code: '20', symbol: 'mn', name: 'Neutron mass', value: 1.67492749804e-27, unit: 'kg', category: 'Atomic & Nuclear' },
  { code: '21', symbol: 'me', name: 'Electron mass', value: 9.1093837015e-31, unit: 'kg', category: 'Atomic & Nuclear' },
  { code: '22', symbol: 'mμ', name: 'Muon mass', value: 1.883531627e-28, unit: 'kg', category: 'Atomic & Nuclear' },
  { code: '23', symbol: 'mτ', name: 'Tau mass', value: 3.16754e-27, unit: 'kg', category: 'Atomic & Nuclear' },
  { code: '24', symbol: 'a0', name: 'Bohr radius', value: 5.29177210903e-11, unit: 'm', category: 'Atomic & Nuclear' },
  { code: '25', symbol: 'α', name: 'Fine-structure', value: 7.2973525693e-3, unit: '', category: 'Atomic & Nuclear' },
  { code: '26', symbol: 're', name: 'Classical e radius', value: 2.8179403262e-15, unit: 'm', category: 'Atomic & Nuclear' },
  { code: '27', symbol: 'λc', name: 'Compton wavelength', value: 2.42631023867e-12, unit: 'm', category: 'Atomic & Nuclear' },
  { code: '28', symbol: 'γp', name: 'Proton gyromag.', value: 2.6752218744e8, unit: 's⁻¹·T⁻¹', category: 'Atomic & Nuclear' },
  { code: '29', symbol: 'λcp', name: 'Proton Compton λ', value: 1.32140985539e-15, unit: 'm', category: 'Atomic & Nuclear' },
  { code: '30', symbol: 'λcn', name: 'Neutron Compton λ', value: 1.31959090581e-15, unit: 'm', category: 'Atomic & Nuclear' },
  { code: '31', symbol: 'R∞', name: 'Rydberg constant', value: 10973731.56816, unit: 'm⁻¹', category: 'Atomic & Nuclear' },
  { code: '32', symbol: 'μp', name: 'Proton mag. mom.', value: 1.41060679736e-26, unit: 'J/T', category: 'Atomic & Nuclear' },
  { code: '33', symbol: 'μe', name: 'Electron mag. mom.', value: -9.2847647043e-24, unit: 'J/T', category: 'Atomic & Nuclear' },
  { code: '34', symbol: 'μn', name: 'Neutron mag. mom.', value: -9.6623651e-27, unit: 'J/T', category: 'Atomic & Nuclear' },
  { code: '35', symbol: 'μμ', name: 'Muon mag. mom.', value: -4.4904483e-26, unit: 'J/T', category: 'Atomic & Nuclear' },

  // Physico-chem (9)
  { code: '36', symbol: 'u', name: 'Atomic mass const', value: 1.6605390666e-27, unit: 'kg', category: 'Physico-chem' },
  { code: '37', symbol: 'F', name: 'Faraday constant', value: 96485.33212, unit: 'C/mol', category: 'Physico-chem' },
  { code: '38', symbol: 'NA', name: 'Avogadro constant', value: 6.02214076e23, unit: 'mol⁻¹', category: 'Physico-chem' },
  { code: '39', symbol: 'k', name: 'Boltzmann const', value: 1.380649e-23, unit: 'J/K', category: 'Physico-chem' },
  { code: '40', symbol: 'Vm', name: 'Molar volume (273K)', value: 0.02271095464, unit: 'm³/mol', category: 'Physico-chem' },
  { code: '41', symbol: 'R', name: 'Molar gas constant', value: 8.314462618, unit: 'J/(mol·K)', category: 'Physico-chem' },
  { code: '42', symbol: 'c1', name: 'First radiation', value: 3.741771852e-16, unit: 'W·m²', category: 'Physico-chem' },
  { code: '43', symbol: 'c2', name: 'Second radiation', value: 0.01438776877, unit: 'm·K', category: 'Physico-chem' },
  { code: '44', symbol: 'σ', name: 'Stefan-Boltzmann', value: 5.670374419e-8, unit: 'W/(m²·K⁴)', category: 'Physico-chem' },

  // Adopted & Other (3)
  { code: '45', symbol: 'g', name: 'Standard gravity', value: 9.80665, unit: 'm/s²', category: 'Adopted & Other' },
  { code: '46', symbol: 'atm', name: 'Standard atm', value: 101325, unit: 'Pa', category: 'Adopted & Other' },
  { code: '47', symbol: 't', name: 'Celsius temp (273.15)', value: 273.15, unit: 'K', category: 'Adopted & Other' },
];

export const CONV_CATEGORIES = [
  'Length',
  'Area',
  'Volume',
  'Mass',
  'Velocity',
  'Pressure',
  'Energy',
  'Power',
  'Temperature',
] as const;

export const UNIT_CONVERSIONS: UnitConversion[] = [
  // Official Casio fx-991EX 01-40 conversions
  { code: '01', label: 'in ▶ cm', fromUnit: 'in', toUnit: 'cm', category: 'Length', convert: (x) => x * 2.54 },
  { code: '02', label: 'cm ▶ in', fromUnit: 'cm', toUnit: 'in', category: 'Length', convert: (x) => x / 2.54 },
  { code: '03', label: 'ft ▶ m', fromUnit: 'ft', toUnit: 'm', category: 'Length', convert: (x) => x * 0.3048 },
  { code: '04', label: 'm ▶ ft', fromUnit: 'm', toUnit: 'ft', category: 'Length', convert: (x) => x / 0.3048 },
  { code: '05', label: 'yd ▶ m', fromUnit: 'yd', toUnit: 'm', category: 'Length', convert: (x) => x * 0.9144 },
  { code: '06', label: 'm ▶ yd', fromUnit: 'm', toUnit: 'yd', category: 'Length', convert: (x) => x / 0.9144 },
  { code: '07', label: 'mile ▶ km', fromUnit: 'mile', toUnit: 'km', category: 'Length', convert: (x) => x * 1.609344 },
  { code: '08', label: 'km ▶ mile', fromUnit: 'km', toUnit: 'mile', category: 'Length', convert: (x) => x / 1.609344 },
  { code: '09', label: 'n mile ▶ m', fromUnit: 'n mile', toUnit: 'm', category: 'Length', convert: (x) => x * 1852 },
  { code: '10', label: 'm ▶ n mile', fromUnit: 'm', toUnit: 'n mile', category: 'Length', convert: (x) => x / 1852 },
  { code: '11', label: 'acre ▶ m²', fromUnit: 'acre', toUnit: 'm²', category: 'Area', convert: (x) => x * 4046.8564224 },
  { code: '12', label: 'm² ▶ acre', fromUnit: 'm²', toUnit: 'acre', category: 'Area', convert: (x) => x / 4046.8564224 },
  { code: '13', label: 'gal(US) ▶ ℓ', fromUnit: 'gal(US)', toUnit: 'ℓ', category: 'Volume', convert: (x) => x * 3.785411784 },
  { code: '14', label: 'ℓ ▶ gal(US)', fromUnit: 'ℓ', toUnit: 'gal(US)', category: 'Volume', convert: (x) => x / 3.785411784 },
  { code: '15', label: 'gal(UK) ▶ ℓ', fromUnit: 'gal(UK)', toUnit: 'ℓ', category: 'Volume', convert: (x) => x * 4.54609 },
  { code: '16', label: 'ℓ ▶ gal(UK)', fromUnit: 'ℓ', toUnit: 'gal(UK)', category: 'Volume', convert: (x) => x / 4.54609 },
  { code: '17', label: 'pc ▶ km', fromUnit: 'pc', toUnit: 'km', category: 'Length', convert: (x) => x * 3.08567758149e13 },
  { code: '18', label: 'km ▶ pc', fromUnit: 'km', toUnit: 'pc', category: 'Length', convert: (x) => x / 3.08567758149e13 },
  { code: '19', label: 'km/h ▶ m/s', fromUnit: 'km/h', toUnit: 'm/s', category: 'Velocity', convert: (x) => x / 3.6 },
  { code: '20', label: 'm/s ▶ km/h', fromUnit: 'm/s', toUnit: 'km/h', category: 'Velocity', convert: (x) => x * 3.6 },
  { code: '21', label: 'oz ▶ g', fromUnit: 'oz', toUnit: 'g', category: 'Mass', convert: (x) => x * 28.349523125 },
  { code: '22', label: 'g ▶ oz', fromUnit: 'g', toUnit: 'oz', category: 'Mass', convert: (x) => x / 28.349523125 },
  { code: '23', label: 'lb ▶ kg', fromUnit: 'lb', toUnit: 'kg', category: 'Mass', convert: (x) => x * 0.45359237 },
  { code: '24', label: 'kg ▶ lb', fromUnit: 'kg', toUnit: 'lb', category: 'Mass', convert: (x) => x / 0.45359237 },
  { code: '25', label: 'atm ▶ Pa', fromUnit: 'atm', toUnit: 'Pa', category: 'Pressure', convert: (x) => x * 101325 },
  { code: '26', label: 'Pa ▶ atm', fromUnit: 'Pa', toUnit: 'atm', category: 'Pressure', convert: (x) => x / 101325 },
  { code: '27', label: 'mmHg ▶ Pa', fromUnit: 'mmHg', toUnit: 'Pa', category: 'Pressure', convert: (x) => x * 133.322387415 },
  { code: '28', label: 'Pa ▶ mmHg', fromUnit: 'Pa', toUnit: 'mmHg', category: 'Pressure', convert: (x) => x / 133.322387415 },
  { code: '29', label: 'hp ▶ kW', fromUnit: 'hp', toUnit: 'kW', category: 'Power', convert: (x) => x * 0.745699871582 },
  { code: '30', label: 'kW ▶ hp', fromUnit: 'kW', toUnit: 'hp', category: 'Power', convert: (x) => x / 0.745699871582 },
  { code: '31', label: 'kgf/cm² ▶ Pa', fromUnit: 'kgf/cm²', toUnit: 'Pa', category: 'Pressure', convert: (x) => x * 98066.5 },
  { code: '32', label: 'Pa ▶ kgf/cm²', fromUnit: 'Pa', toUnit: 'kgf/cm²', category: 'Pressure', convert: (x) => x / 98066.5 },
  { code: '33', label: 'kgf·m ▶ J', fromUnit: 'kgf·m', toUnit: 'J', category: 'Energy', convert: (x) => x * 9.80665 },
  { code: '34', label: 'J ▶ kgf·m', fromUnit: 'J', toUnit: 'kgf·m', category: 'Energy', convert: (x) => x / 9.80665 },
  { code: '35', label: 'lbf/in² ▶ kPa', fromUnit: 'lbf/in²', toUnit: 'kPa', category: 'Pressure', convert: (x) => x * 6.89475729317 },
  { code: '36', label: 'kPa ▶ lbf/in²', fromUnit: 'kPa', toUnit: 'lbf/in²', category: 'Pressure', convert: (x) => x / 6.89475729317 },
  { code: '37', label: '°F ▶ °C', fromUnit: '°F', toUnit: '°C', category: 'Temperature', convert: (x) => (x - 32) * (5 / 9) },
  { code: '38', label: '°C ▶ °F', fromUnit: '°C', toUnit: '°F', category: 'Temperature', convert: (x) => x * (9 / 5) + 32 },
  { code: '39', label: 'J ▶ cal', fromUnit: 'J', toUnit: 'cal', category: 'Energy', convert: (x) => x / 4.184 },
  { code: '40', label: 'cal ▶ J', fromUnit: 'cal', toUnit: 'J', category: 'Energy', convert: (x) => x * 4.184 },
];
