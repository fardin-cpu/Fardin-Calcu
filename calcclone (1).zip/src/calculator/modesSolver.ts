import { ComplexVal, DistType, StatRow, StatType } from './types';

// ---------- Simultaneous Linear Solver (Gaussian Elimination) ----------
export function solveSimultaneous(matrix: number[][]): { ok: boolean; values?: number[]; msg?: string } {
  const n = matrix.length;
  const a = matrix.map((r) => [...r]);

  for (let i = 0; i < n; i++) {
    let pivot = i;
    for (let j = i + 1; j < n; j++) {
      if (Math.abs(a[j][i]) > Math.abs(a[pivot][i])) pivot = j;
    }
    if (Math.abs(a[pivot][i]) < 1e-12) {
      return { ok: false, msg: 'No Solution / Inf. Sol' };
    }
    if (pivot !== i) [a[i], a[pivot]] = [a[pivot], a[i]];
    const div = a[i][i];
    for (let k = i; k <= n; k++) a[i][k] /= div;
    for (let j = 0; j < n; j++) {
      if (j === i) continue;
      const factor = a[j][i];
      for (let k = i; k <= n; k++) a[j][k] -= factor * a[i][k];
    }
  }
  return { ok: true, values: a.map((r) => (Math.abs(r[n]) < 1e-13 ? 0 : r[n])) };
}

// ---------- Polynomial Root Finder (Degree 2-4, Durand-Kerner) ----------
export function solvePolynomial(coeffs: number[]): ComplexVal[] {
  // coeffs[0]*x^n + coeffs[1]*x^(n-1) + ... + coeffs[n]
  let c = [...coeffs];
  while (c.length > 1 && Math.abs(c[0]) < 1e-14) c.shift();
  const deg = c.length - 1;
  if (deg <= 0) return [];
  if (deg === 1) return [{ re: -c[1] / c[0], im: 0 }];
  if (deg === 2) {
    const [a, b, d] = c;
    const disc = b * b - 4 * a * d;
    if (disc >= 0) {
      const sd = Math.sqrt(disc);
      return [
        { re: (-b + sd) / (2 * a), im: 0 },
        { re: (-b - sd) / (2 * a), im: 0 },
      ];
    }
    const sd = Math.sqrt(-disc);
    return [
      { re: -b / (2 * a), im: sd / (2 * a) },
      { re: -b / (2 * a), im: -sd / (2 * a) },
    ];
  }

  // Normalize monic
  const lead = c[0];
  const p = c.map((v) => v / lead);

  const evalPoly = (z: ComplexVal): ComplexVal => {
    let acc: ComplexVal = { re: 1, im: 0 };
    for (let i = 1; i < p.length; i++) {
      acc = {
        re: acc.re * z.re - acc.im * z.im + p[i],
        im: acc.re * z.im + acc.im * z.re,
      };
    }
    return acc;
  };

  let roots: ComplexVal[] = Array.from({ length: deg }, (_, k) => {
    const angle = (2 * Math.PI * k) / deg + 0.13;
    const radius = 1 + 0.3 * k;
    return { re: radius * Math.cos(angle), im: radius * Math.sin(angle) };
  });

  for (let iter = 0; iter < 160; iter++) {
    let maxStep = 0;
    for (let i = 0; i < deg; i++) {
      const pz = evalPoly(roots[i]);
      let denom: ComplexVal = { re: 1, im: 0 };
      for (let j = 0; j < deg; j++) {
        if (i === j) continue;
        const dr = roots[i].re - roots[j].re;
        const di = roots[i].im - roots[j].im;
        denom = {
          re: denom.re * dr - denom.im * di,
          im: denom.re * di + denom.im * dr,
        };
      }
      const d2 = denom.re * denom.re + denom.im * denom.im || 1e-30;
      const deltaRe = (pz.re * denom.re + pz.im * denom.im) / d2;
      const deltaIm = (pz.im * denom.re - pz.re * denom.im) / d2;
      roots[i] = { re: roots[i].re - deltaRe, im: roots[i].im - deltaIm };
      maxStep = Math.max(maxStep, Math.hypot(deltaRe, deltaIm));
    }
    if (maxStep < 1e-12) break;
  }

  return roots.map((r) => ({
    re: Math.abs(r.re) < 1e-10 ? 0 : r.re,
    im: Math.abs(r.im) < 1e-9 ? 0 : r.im,
  }));
}

// ---------- Inequality Solver (Degree 2-3) ----------
export function solveInequality(coeffs: number[], op: '<' | '>' | '≤' | '≥'): string {
  const realRoots = solvePolynomial(coeffs)
    .filter((r) => Math.abs(r.im) < 1e-8)
    .map((r) => r.re)
    .sort((a, b) => a - b);

  // Deduplicate close roots
  const uniqRoots: number[] = [];
  for (const r of realRoots) {
    if (uniqRoots.length === 0 || Math.abs(r - uniqRoots[uniqRoots.length - 1]) > 1e-7) {
      uniqRoots.push(r);
    }
  }

  const evalAt = (x: number) =>
    coeffs.reduce((acc, c) => acc * x + c, 0);

  const satisfies = (val: number) => {
    if (op === '<') return val < -1e-11;
    if (op === '>') return val > 1e-11;
    if (op === '≤') return val <= 1e-11;
    return val >= -1e-11;
  };

  const inclusive = op === '≤' || op === '≥';
  const pts = [-Infinity, ...uniqRoots, Infinity];
  const intervals: string[] = [];

  const fmt = (v: number) => Number(v.toPrecision(6)).toString();

  for (let i = 0; i < pts.length - 1; i++) {
    const l = pts[i];
    const r = pts[i + 1];
    const mid =
      l === -Infinity && r === Infinity
        ? 0
        : l === -Infinity
        ? r - 1
        : r === Infinity
        ? l + 1
        : (l + r) / 2;

    if (satisfies(evalAt(mid))) {
      const symL = inclusive ? '≤' : '<';
      const symR = inclusive ? '≤' : '<';
      if (l === -Infinity && r === Infinity) return 'All Real Numbers';
      if (l === -Infinity) intervals.push(`x ${symR} ${fmt(r)}`);
      else if (r === Infinity) intervals.push(`x ${inclusive ? '≥' : '>'} ${fmt(l)}`);
      else intervals.push(`${fmt(l)} ${symL} x ${symR} ${fmt(r)}`);
    }
  }

  if (intervals.length === 0 && inclusive && uniqRoots.length > 0) {
    return uniqRoots.map((r) => `x = ${fmt(r)}`).join(', ');
  }
  return intervals.length > 0 ? intervals.join(' , ') : 'No Solution';
}

// ---------- Statistics Engine ----------
export interface StatSummary {
  n: number;
  meanX: number;
  sumX: number;
  sumX2: number;
  popStdX: number;
  sampStdX: number;
  minX: number;
  q1: number;
  med: number;
  q3: number;
  maxX: number;
  meanY?: number;
  sumY?: number;
  sumY2?: number;
  sumXY?: number;
  regCoeffs?: { a: number; b: number; c?: number; r?: number };
}

export function computeStatistics(rows: StatRow[], statType: StatType, useFreq: boolean): StatSummary | null {
  const expandedX: number[] = [];
  const expandedY: number[] = [];
  let n = 0;

  for (const row of rows) {
    const f = useFreq ? Math.max(0, Math.round(row.freq)) : 1;
    for (let k = 0; k < f; k++) {
      expandedX.push(row.x);
      expandedY.push(row.y);
      n++;
    }
  }
  if (n === 0) return null;

  const sumX = expandedX.reduce((s, v) => s + v, 0);
  const sumX2 = expandedX.reduce((s, v) => s + v * v, 0);
  const meanX = sumX / n;
  const varPopX = Math.max(0, sumX2 / n - meanX * meanX);
  const popStdX = Math.sqrt(varPopX);
  const sampStdX = n > 1 ? Math.sqrt((varPopX * n) / (n - 1)) : 0;

  const sorted = [...expandedX].sort((a, b) => a - b);
  const medianOf = (arr: number[]) => {
    const m = arr.length;
    if (m === 0) return 0;
    const mid = Math.floor(m / 2);
    return m % 2 === 1 ? arr[mid] : (arr[mid - 1] + arr[mid]) / 2;
  };
  const midIdx = Math.floor(n / 2);
  const lowerHalf = sorted.slice(0, midIdx);
  const upperHalf = n % 2 === 1 ? sorted.slice(midIdx + 1) : sorted.slice(midIdx);

  const summary: StatSummary = {
    n,
    meanX,
    sumX,
    sumX2,
    popStdX,
    sampStdX,
    minX: sorted[0],
    q1: n === 1 ? sorted[0] : medianOf(lowerHalf),
    med: medianOf(sorted),
    q3: n === 1 ? sorted[0] : medianOf(upperHalf),
    maxX: sorted[n - 1],
  };

  if (statType === '1-VAR' || n < 2) return summary;

  const sumY = expandedY.reduce((s, v) => s + v, 0);
  const sumY2 = expandedY.reduce((s, v) => s + v * v, 0);
  const sumXY = expandedX.reduce((s, x, i) => s + x * expandedY[i], 0);
  summary.meanY = sumY / n;
  summary.sumY = sumY;
  summary.sumY2 = sumY2;
  summary.sumXY = sumXY;

  const linReg = (xs: number[], ys: number[]) => {
    const sx = xs.reduce((a, b) => a + b, 0);
    const sy = ys.reduce((a, b) => a + b, 0);
    const sxx = xs.reduce((a, x) => a + x * x, 0);
    const syy = ys.reduce((a, y) => a + y * y, 0);
    const sxy = xs.reduce((a, x, i) => a + x * ys[i], 0);
    const denom = n * sxx - sx * sx;
    if (Math.abs(denom) < 1e-14) return null;
    const b = (n * sxy - sx * sy) / denom;
    const a = (sy - b * sx) / n;
    const rDenom = Math.sqrt((n * sxx - sx * sx) * (n * syy - sy * sy));
    const r = rDenom > 1e-14 ? (n * sxy - sx * sy) / rDenom : 0;
    return { a, b, r };
  };

  if (statType === 'LINEAR') {
    summary.regCoeffs = linReg(expandedX, expandedY) ?? undefined;
  } else if (statType === 'LOG') {
    if (expandedX.every((x) => x > 0)) {
      summary.regCoeffs = linReg(expandedX.map(Math.log), expandedY) ?? undefined;
    }
  } else if (statType === 'E_EXP') {
    if (expandedY.every((y) => y > 0)) {
      const lr = linReg(expandedX, expandedY.map(Math.log));
      if (lr) summary.regCoeffs = { a: Math.exp(lr.a), b: lr.b, r: lr.r };
    }
  } else if (statType === 'AB_EXP') {
    if (expandedY.every((y) => y > 0)) {
      const lr = linReg(expandedX, expandedY.map(Math.log));
      if (lr) summary.regCoeffs = { a: Math.exp(lr.a), b: Math.exp(lr.b), r: lr.r };
    }
  } else if (statType === 'POWER') {
    if (expandedX.every((x) => x > 0) && expandedY.every((y) => y > 0)) {
      const lr = linReg(expandedX.map(Math.log), expandedY.map(Math.log));
      if (lr) summary.regCoeffs = { a: Math.exp(lr.a), b: lr.b, r: lr.r };
    }
  } else if (statType === 'INV') {
    if (expandedX.every((x) => x !== 0)) {
      summary.regCoeffs = linReg(expandedX.map((x) => 1 / x), expandedY) ?? undefined;
    }
  } else if (statType === 'QUAD') {
    const sx = sumX;
    const sx2 = sumX2;
    const sx3 = expandedX.reduce((s, x) => s + x ** 3, 0);
    const sx4 = expandedX.reduce((s, x) => s + x ** 4, 0);
    const sy = sumY;
    const sxy = sumXY;
    const sx2y = expandedX.reduce((s, x, i) => s + x * x * expandedY[i], 0);
    const sol = solveSimultaneous([
      [n, sx, sx2, sy],
      [sx, sx2, sx3, sxy],
      [sx2, sx3, sx4, sx2y],
    ]);
    if (sol.ok && sol.values) {
      summary.regCoeffs = { a: sol.values[0], b: sol.values[1], c: sol.values[2] };
    }
  }

  return summary;
}

// ---------- Probability Distributions ----------
function erf(x: number): number {
  const sign = x >= 0 ? 1 : -1;
  x = Math.abs(x);
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741;
  const a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
  const t = 1 / (1 + p * x);
  const y = 1 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
  return sign * y;
}

function normalCdf(z: number): number {
  return 0.5 * (1 + erf(z / Math.SQRT2));
}

function invNormalCdf(p: number): number {
  if (p <= 0 || p >= 1) throw new Error('Math ERROR');
  // Acklam's rational approximation
  const a = [-3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2, 1.38357751867269e2, -3.066479806614716e1, 2.506628277459239];
  const b = [-5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2, 6.680131188771972e1, -1.328068155288572e1];
  const c = [-7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783];
  const d = [7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996, 3.754408661907416];
  const plow = 0.02425;
  const phigh = 1 - plow;
  if (p < plow) {
    const q = Math.sqrt(-2 * Math.log(p));
    return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
      ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  }
  if (p <= phigh) {
    const q = p - 0.5;
    const r = q * q;
    return ((((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q) /
      (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
  }
  const q = Math.sqrt(-2 * Math.log(1 - p));
  return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
    ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
}

function binomPmf(k: number, n: number, p: number): number {
  if (k < 0 || k > n || !Number.isInteger(k) || !Number.isInteger(n) || p < 0 || p > 1) return 0;
  let c = 1;
  const kk = Math.min(k, n - k);
  for (let i = 0; i < kk; i++) c = (c * (n - i)) / (i + 1);
  return c * Math.pow(p, k) * Math.pow(1 - p, n - k);
}

function poissonPmf(k: number, lam: number): number {
  if (k < 0 || !Number.isInteger(k) || lam <= 0) return 0;
  let res = Math.exp(-lam);
  for (let i = 1; i <= k; i++) res *= lam / i;
  return res;
}

export function computeDistribution(dist: DistType, vals: number[]): number {
  if (dist === 'NORMAL_PD') {
    const [x, sigma, mu] = vals;
    if (sigma <= 0) throw new Error('Math ERROR');
    const z = (x - mu) / sigma;
    return Math.exp(-0.5 * z * z) / (sigma * Math.sqrt(2 * Math.PI));
  }
  if (dist === 'NORMAL_CD') {
    const [lower, upper, sigma, mu] = vals;
    if (sigma <= 0) throw new Error('Math ERROR');
    return normalCdf((upper - mu) / sigma) - normalCdf((lower - mu) / sigma);
  }
  if (dist === 'INV_NORMAL') {
    const [area, sigma, mu] = vals;
    if (sigma <= 0 || area <= 0 || area >= 1) throw new Error('Math ERROR');
    return mu + sigma * invNormalCdf(area);
  }
  if (dist === 'BINOMIAL_PD') {
    const [x, n, p] = vals;
    return binomPmf(Math.round(x), Math.round(n), p);
  }
  if (dist === 'BINOMIAL_CD') {
    const [x, n, p] = vals;
    let sum = 0;
    for (let k = 0; k <= Math.floor(x); k++) sum += binomPmf(k, Math.round(n), p);
    return sum;
  }
  if (dist === 'POISSON_PD') {
    const [x, lam] = vals;
    return poissonPmf(Math.round(x), lam);
  }
  const [x, lam] = vals;
  let sum = 0;
  for (let k = 0; k <= Math.floor(x); k++) sum += poissonPmf(k, lam);
  return sum;
}

// ---------- Mini Spreadsheet Evaluator (A1..E10) ----------
export function evalSpreadsheetCell(
  raw: string,
  grid: string[][],
  visited = new Set<string>()
): number | string {
  const trimmed = raw.trim();
  if (!trimmed) return '';
  if (!trimmed.startsWith('=')) {
    const n = Number(trimmed.replace(',', '.'));
    return Number.isNaN(n) ? trimmed : n;
  }

  let expr = trimmed.slice(1).toUpperCase();

  const getCell = (colChar: string, rowNum: number): number => {
    const c = colChar.charCodeAt(0) - 65;
    const r = rowNum - 1;
    const key = `${colChar}${rowNum}`;
    if (r < 0 || r >= grid.length || c < 0 || c >= grid[0].length) return 0;
    if (visited.has(key)) return 0;
    const nextVis = new Set(visited);
    nextVis.add(key);
    const val = evalSpreadsheetCell(grid[r][c], grid, nextVis);
    return typeof val === 'number' ? val : 0;
  };

  // Handle SUM(A1:A5) / MEAN(A1:A5) / MIN / MAX
  expr = expr.replace(/(SUM|MEAN|MIN|MAX)\(([A-E])(\d+):([A-E])(\d+)\)/g, (_, fn, c1, r1, c2, r2) => {
    const cs = Math.min(c1.charCodeAt(0), c2.charCodeAt(0));
    const ce = Math.max(c1.charCodeAt(0), c2.charCodeAt(0));
    const rs = Math.min(Number(r1), Number(r2));
    const re = Math.max(Number(r1), Number(r2));
    const vals: number[] = [];
    for (let cc = cs; cc <= ce; cc++) {
      for (let rr = rs; rr <= re; rr++) {
        vals.push(getCell(String.fromCharCode(cc), rr));
      }
    }
    if (vals.length === 0) return '0';
    if (fn === 'SUM') return String(vals.reduce((a, b) => a + b, 0));
    if (fn === 'MEAN') return String(vals.reduce((a, b) => a + b, 0) / vals.length);
    if (fn === 'MIN') return String(Math.min(...vals));
    return String(Math.max(...vals));
  });

  // Replace cell refs A1..E10
  expr = expr.replace(/\b([A-E])(10|[1-9])\b/g, (_, col, row) => String(getCell(col, Number(row))));

  try {
    // Safe arithmetic only
    if (!/^[0-9+\-*/().\s]+$/.test(expr)) return 'ERR';
    const fn = new Function(`"use strict"; return (${expr});`);
    const out = fn();
    return typeof out === 'number' && Number.isFinite(out) ? out : 'ERR';
  } catch {
    return 'ERR';
  }
}
