import { CursorPos, MathNode, PathStep, VarName } from './types';

let idCounter = 1;
export function genId(): string {
  return `n_${idCounter++}`;
}

export function cloneNodes(nodes: MathNode[]): MathNode[] {
  return nodes.map((n) => {
    switch (n.type) {
      case 'char':
      case 'func':
      case 'const':
        return { ...n };
      case 'fraction':
        return { ...n, num: cloneNodes(n.num), den: cloneNodes(n.den) };
      case 'mixedFraction':
        return {
          ...n,
          whole: cloneNodes(n.whole),
          num: cloneNodes(n.num),
          den: cloneNodes(n.den),
        };
      case 'sqrt':
      case 'cbrt':
      case 'sup':
      case 'abs':
        return { ...n, body: cloneNodes(n.body) };
      case 'nroot':
        return { ...n, index: cloneNodes(n.index), body: cloneNodes(n.body) };
      case 'logBase':
        return { ...n, base: cloneNodes(n.base), body: cloneNodes(n.body) };
      case 'integral':
      case 'sum':
      case 'prod':
        return {
          ...n,
          expr: cloneNodes(n.expr),
          lower: cloneNodes(n.lower),
          upper: cloneNodes(n.upper),
        };
      case 'derivative':
        return { ...n, expr: cloneNodes(n.expr), at: cloneNodes(n.at) };
    }
  });
}

export function getSlotOrder(node: MathNode): string[] {
  switch (node.type) {
    case 'fraction':
      return ['num', 'den'];
    case 'mixedFraction':
      return ['whole', 'num', 'den'];
    case 'sqrt':
    case 'cbrt':
    case 'sup':
    case 'abs':
      return ['body'];
    case 'nroot':
      return ['index', 'body'];
    case 'logBase':
      return ['base', 'body'];
    case 'integral':
    case 'sum':
    case 'prod':
      return ['lower', 'upper', 'expr'];
    case 'derivative':
      return ['expr', 'at'];
    default:
      return [];
  }
}

export function getSlotArray(node: MathNode, slot: string): MathNode[] | null {
  switch (node.type) {
    case 'fraction':
      return slot === 'num' ? node.num : slot === 'den' ? node.den : null;
    case 'mixedFraction':
      return slot === 'whole' ? node.whole : slot === 'num' ? node.num : slot === 'den' ? node.den : null;
    case 'sqrt':
    case 'cbrt':
    case 'sup':
    case 'abs':
      return slot === 'body' ? node.body : null;
    case 'nroot':
      return slot === 'index' ? node.index : slot === 'body' ? node.body : null;
    case 'logBase':
      return slot === 'base' ? node.base : slot === 'body' ? node.body : null;
    case 'integral':
    case 'sum':
    case 'prod':
      return slot === 'expr' ? node.expr : slot === 'lower' ? node.lower : slot === 'upper' ? node.upper : null;
    case 'derivative':
      return slot === 'expr' ? node.expr : slot === 'at' ? node.at : null;
    default:
      return null;
  }
}

export function getListAtPath(root: MathNode[], path: PathStep[]): MathNode[] {
  let list = root;
  for (const step of path) {
    const node = list.find((n) => n.id === step.nodeId);
    if (!node) return root;
    const next = getSlotArray(node, step.slot);
    if (!next) return root;
    list = next;
  }
  return list;
}

export function moveCursorLeft(root: MathNode[], cursor: CursorPos): CursorPos {
  const list = getListAtPath(root, cursor.path);
  if (cursor.index > 0) {
    const prevNode = list[cursor.index - 1];
    const slots = getSlotOrder(prevNode);
    if (slots.length > 0) {
      const lastSlot = slots[slots.length - 1];
      const arr = getSlotArray(prevNode, lastSlot)!;
      return {
        path: [...cursor.path, { nodeId: prevNode.id, slot: lastSlot }],
        index: arr.length,
      };
    }
    return { path: cursor.path, index: cursor.index - 1 };
  }

  // At index 0 of current slot -> move to previous slot or exit container left
  if (cursor.path.length > 0) {
    const parentPath = cursor.path.slice(0, -1);
    const step = cursor.path[cursor.path.length - 1];
    const parentList = getListAtPath(root, parentPath);
    const parentIdx = parentList.findIndex((n) => n.id === step.nodeId);
    if (parentIdx >= 0) {
      const parentNode = parentList[parentIdx];
      const slots = getSlotOrder(parentNode);
      const slotIdx = slots.indexOf(step.slot);
      if (slotIdx > 0) {
        const prevSlot = slots[slotIdx - 1];
        const arr = getSlotArray(parentNode, prevSlot)!;
        return {
          path: [...parentPath, { nodeId: parentNode.id, slot: prevSlot }],
          index: arr.length,
        };
      }
      return { path: parentPath, index: parentIdx };
    }
  }

  // Wrap around to end of root if at very beginning
  return { path: [], index: root.length };
}

export function moveCursorRight(root: MathNode[], cursor: CursorPos): CursorPos {
  const list = getListAtPath(root, cursor.path);
  if (cursor.index < list.length) {
    const nextNode = list[cursor.index];
    const slots = getSlotOrder(nextNode);
    if (slots.length > 0) {
      const firstSlot = slots[0];
      return {
        path: [...cursor.path, { nodeId: nextNode.id, slot: firstSlot }],
        index: 0,
      };
    }
    return { path: cursor.path, index: cursor.index + 1 };
  }

  // At end of current slot -> move to next slot or exit container right
  if (cursor.path.length > 0) {
    const parentPath = cursor.path.slice(0, -1);
    const step = cursor.path[cursor.path.length - 1];
    const parentList = getListAtPath(root, parentPath);
    const parentIdx = parentList.findIndex((n) => n.id === step.nodeId);
    if (parentIdx >= 0) {
      const parentNode = parentList[parentIdx];
      const slots = getSlotOrder(parentNode);
      const slotIdx = slots.indexOf(step.slot);
      if (slotIdx >= 0 && slotIdx < slots.length - 1) {
        const nextSlot = slots[slotIdx + 1];
        return {
          path: [...parentPath, { nodeId: parentNode.id, slot: nextSlot }],
          index: 0,
        };
      }
      return { path: parentPath, index: parentIdx + 1 };
    }
  }

  // Wrap around to beginning of root if at very end
  return { path: [], index: 0 };
}

export function moveCursorVertical(root: MathNode[], cursor: CursorPos, dir: 'UP' | 'DOWN'): CursorPos | null {
  if (cursor.path.length === 0) return null;
  for (let depth = cursor.path.length - 1; depth >= 0; depth--) {
    const step = cursor.path[depth];
    const parentPath = cursor.path.slice(0, depth);
    const parentList = getListAtPath(root, parentPath);
    const node = parentList.find((n) => n.id === step.nodeId);
    if (!node) continue;

    if (node.type === 'fraction') {
      if (dir === 'DOWN' && step.slot === 'num') {
        return { path: [...parentPath, { nodeId: node.id, slot: 'den' }], index: Math.min(cursor.index, node.den.length) };
      }
      if (dir === 'UP' && step.slot === 'den') {
        return { path: [...parentPath, { nodeId: node.id, slot: 'num' }], index: Math.min(cursor.index, node.num.length) };
      }
    }
    if (node.type === 'mixedFraction') {
      if (dir === 'DOWN' && step.slot === 'num') {
        return { path: [...parentPath, { nodeId: node.id, slot: 'den' }], index: Math.min(cursor.index, node.den.length) };
      }
      if (dir === 'UP' && step.slot === 'den') {
        return { path: [...parentPath, { nodeId: node.id, slot: 'num' }], index: Math.min(cursor.index, node.num.length) };
      }
    }
    if (node.type === 'integral' || node.type === 'sum' || node.type === 'prod') {
      if (dir === 'UP' && step.slot === 'lower') {
        return { path: [...parentPath, { nodeId: node.id, slot: 'upper' }], index: Math.min(cursor.index, node.upper.length) };
      }
      if (dir === 'DOWN' && step.slot === 'upper') {
        return { path: [...parentPath, { nodeId: node.id, slot: 'lower' }], index: Math.min(cursor.index, node.lower.length) };
      }
    }
  }
  return null;
}

export function insertNodesAtCursor(
  root: MathNode[],
  cursor: CursorPos,
  nodesToInsert: MathNode[],
  overwrite = false,
  enterSlot?: { nodeIndex: number; slot: string }
): { root: MathNode[]; cursor: CursorPos } {
  const nextRoot = cloneNodes(root);
  const list = getListAtPath(nextRoot, cursor.path);
  const delCount = overwrite && cursor.index < list.length ? 1 : 0;
  list.splice(cursor.index, delCount, ...nodesToInsert);

  if (enterSlot) {
    const target = nodesToInsert[enterSlot.nodeIndex];
    if (target) {
      return {
        root: nextRoot,
        cursor: {
          path: [...cursor.path, { nodeId: target.id, slot: enterSlot.slot }],
          index: 0,
        },
      };
    }
  }

  return {
    root: nextRoot,
    cursor: {
      path: cursor.path,
      index: cursor.index + nodesToInsert.length,
    },
  };
}

/**
 * Casio Natural Display behavior: pressing fraction key [□/□] after typing a number/atom
 * lifts that preceding number/atom into the numerator and moves cursor into denominator.
 */
export function insertFractionSmart(
  root: MathNode[],
  cursor: CursorPos
): { root: MathNode[]; cursor: CursorPos } {
  const nextRoot = cloneNodes(root);
  const list = getListAtPath(nextRoot, cursor.path);

  let liftStart = cursor.index;
  const isDigitOrDot = (n: MathNode) =>
    n.type === 'char' && /^[0-9.,A-Fa-fxMyπe]$/.test(n.value);

  if (cursor.index > 0) {
    const prev = list[cursor.index - 1];
    if (isDigitOrDot(prev)) {
      while (liftStart > 0 && isDigitOrDot(list[liftStart - 1])) {
        liftStart--;
      }
    } else if (prev.type === 'char' && prev.value === ')') {
      let depth = 0;
      let k = cursor.index - 1;
      while (k >= 0) {
        const cur = list[k];
        if (cur.type === 'char' && cur.value === ')') depth++;
        else if ((cur.type === 'char' && cur.value === '(') || cur.type === 'func') {
          depth--;
          if (depth === 0) {
            liftStart = k;
            break;
          }
        }
        k--;
      }
    } else if (
      prev.type === 'sqrt' ||
      prev.type === 'cbrt' ||
      prev.type === 'nroot' ||
      prev.type === 'sup' ||
      prev.type === 'abs' ||
      prev.type === 'const'
    ) {
      liftStart = cursor.index - 1;
      while (liftStart > 0 && isDigitOrDot(list[liftStart - 1])) {
        liftStart--;
      }
    }
  }

  if (liftStart < cursor.index) {
    const lifted = list.splice(liftStart, cursor.index - liftStart);
    const frac: MathNode = {
      id: genId(),
      type: 'fraction',
      num: lifted,
      den: [],
    };
    list.splice(liftStart, 0, frac);
    return {
      root: nextRoot,
      cursor: {
        path: [...cursor.path, { nodeId: frac.id, slot: 'den' }],
        index: 0,
      },
    };
  }

  const frac: MathNode = {
    id: genId(),
    type: 'fraction',
    num: [],
    den: [],
  };
  list.splice(cursor.index, 0, frac);
  return {
    root: nextRoot,
    cursor: {
      path: [...cursor.path, { nodeId: frac.id, slot: 'num' }],
      index: 0,
    },
  };
}

export function deleteBeforeCursor(
  root: MathNode[],
  cursor: CursorPos
): { root: MathNode[]; cursor: CursorPos } {
  const nextRoot = cloneNodes(root);
  const list = getListAtPath(nextRoot, cursor.path);

  if (cursor.index > 0) {
    const target = list[cursor.index - 1];
    // If deleting a fraction with content in numerator, unwrap numerator like Casio
    if (target.type === 'fraction' && target.den.length === 0) {
      const unwrapped = target.num;
      list.splice(cursor.index - 1, 1, ...unwrapped);
      return {
        root: nextRoot,
        cursor: { path: cursor.path, index: cursor.index - 1 + unwrapped.length },
      };
    }
    list.splice(cursor.index - 1, 1);
    return {
      root: nextRoot,
      cursor: { path: cursor.path, index: cursor.index - 1 },
    };
  }

  // If at index 0 inside a container: unwrap or move left
  if (cursor.path.length > 0) {
    const parentPath = cursor.path.slice(0, -1);
    const step = cursor.path[cursor.path.length - 1];
    const parentList = getListAtPath(nextRoot, parentPath);
    const parentIdx = parentList.findIndex((n) => n.id === step.nodeId);
    if (parentIdx >= 0) {
      const parentNode = parentList[parentIdx];
      const slots = getSlotOrder(parentNode);
      const slotIdx = slots.indexOf(step.slot);
      if (slotIdx > 0) {
        const prevSlot = slots[slotIdx - 1];
        const prevArr = getSlotArray(parentNode, prevSlot)!;
        return {
          root: nextRoot,
          cursor: {
            path: [...parentPath, { nodeId: parentNode.id, slot: prevSlot }],
            index: prevArr.length,
          },
        };
      }
      // If all slots empty, remove the container node
      const allEmpty = slots.every((s) => (getSlotArray(parentNode, s)?.length ?? 0) === 0);
      if (allEmpty) {
        parentList.splice(parentIdx, 1);
        return {
          root: nextRoot,
          cursor: { path: parentPath, index: parentIdx },
        };
      }
      // Otherwise unwrap primary body
      if (parentNode.type === 'sqrt' || parentNode.type === 'cbrt' || parentNode.type === 'abs' || parentNode.type === 'sup') {
        const inner = parentNode.body;
        parentList.splice(parentIdx, 1, ...inner);
        return {
          root: nextRoot,
          cursor: { path: parentPath, index: parentIdx },
        };
      }
      if (parentNode.type === 'fraction') {
        const inner = [...parentNode.num, ...parentNode.den];
        parentList.splice(parentIdx, 1, ...inner);
        return {
          root: nextRoot,
          cursor: { path: parentPath, index: parentIdx },
        };
      }
    }
  }

  return { root: nextRoot, cursor };
}

export function extractVariablesFromNodes(nodes: MathNode[]): VarName[] {
  const found = new Set<VarName>();
  const validVars = new Set<VarName>(['A', 'B', 'C', 'D', 'E', 'F', 'x', 'y', 'M']);

  const walk = (list: MathNode[], ignoreX = false) => {
    for (const n of list) {
      if (n.type === 'char' && validVars.has(n.value as VarName)) {
        if (!(ignoreX && n.value === 'x')) {
          found.add(n.value as VarName);
        }
      } else if (n.type === 'integral' || n.type === 'sum' || n.type === 'prod' || n.type === 'derivative') {
        if (n.type === 'integral' || n.type === 'sum' || n.type === 'prod') {
          walk(n.lower, ignoreX);
          walk(n.upper, ignoreX);
          walk(n.expr, true);
        } else {
          walk(n.at, ignoreX);
          walk(n.expr, true);
        }
      } else {
        for (const s of getSlotOrder(n)) {
          const arr = getSlotArray(n, s);
          if (arr) walk(arr, ignoreX);
        }
      }
    }
  };

  walk(nodes);
  return Array.from(found);
}

export function nodesToPlainText(nodes: MathNode[]): string {
  return nodes
    .map((n) => {
      switch (n.type) {
        case 'char':
          return n.value;
        case 'func':
          return n.name;
        case 'const':
          return n.symbol;
        case 'fraction':
          return `(${nodesToPlainText(n.num)})/(${nodesToPlainText(n.den)})`;
        case 'mixedFraction':
          return `(${nodesToPlainText(n.whole)}+${nodesToPlainText(n.num)}/${nodesToPlainText(n.den)})`;
        case 'sqrt':
          return `√(${nodesToPlainText(n.body)})`;
        case 'cbrt':
          return `³√(${nodesToPlainText(n.body)})`;
        case 'nroot':
          return `${nodesToPlainText(n.index)}√(${nodesToPlainText(n.body)})`;
        case 'sup':
          return `^(${nodesToPlainText(n.body)})`;
        case 'logBase':
          return `log_${nodesToPlainText(n.base)}(${nodesToPlainText(n.body)})`;
        case 'abs':
          return `|${nodesToPlainText(n.body)}|`;
        case 'integral':
          return `∫(${nodesToPlainText(n.expr)},${nodesToPlainText(n.lower)},${nodesToPlainText(n.upper)})`;
        case 'derivative':
          return `d/dx(${nodesToPlainText(n.expr)},${nodesToPlainText(n.at)})`;
        case 'sum':
          return `Σ(${nodesToPlainText(n.expr)},${nodesToPlainText(n.lower)},${nodesToPlainText(n.upper)})`;
        case 'prod':
          return `Π(${nodesToPlainText(n.expr)},${nodesToPlainText(n.lower)},${nodesToPlainText(n.upper)})`;
      }
    })
    .join('');
}
