import { CalcSettings, ExactResult } from './types';

export function gcdInt(a: number, b: number): number {
  a = Math.abs(Math.round(a));
  b = Math.abs(Math.round(b));
  while (b !== 0) {
    const t = a % b;
    a = b;
    b = t;
  }
  return a || 1;
}

export function lcmInt(a: number, b: number): number {
  a = Math.abs(Math.round(a));
  b = Math.abs(Math.round(b));
  if (a === 0 || b === 0) return 0;
  return (a / gcdInt(a, b)) * b;
}

/**
 * Continued fraction rational approximation for |x| <= 1e7, max denominator 10000
 */
export function approximateRational(x: number, maxDen = 10000, tol = 1e-11): { num: number; den: number } | null {
  if (!Number.isFinite(x) || Math.abs(x) > 1e7) return null;
  if (Math.abs(x) < 1e-13) return { num: 0, den: 1 };

  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);

  let h1 = 1, h0 = 0;
  let k1 = 0, k0 = 1;
  let b = ax;

  for (let i = 0; i < 32; i++) {
    const a = Math.floor(b);
    const h2 = a * h1 + h0;
    const k2 = a * k1 + k0;
    if (k2 > maxDen) break;
    h0 = h1; h1 = h2;
    k0 = k1; k1 = k2;
    const frac = b - a;
    if (frac < 1e-13) break;
    b = 1 / frac;
  }

  if (k1 === 0) return null;
  const err = Math.abs(ax - h1 / k1);
  if (err <= tol * Math.max(1, ax)) {
    return { num: sign * h1, den: k1 };
  }
  return null;
}

const COMMON_RADICANDS = [2, 3, 5, 6, 7, 10, 11, 13, 14, 15, 17, 19, 21, 22, 23, 26, 29, 30];

export function tryExactRepresentation(value: number, preferMixed = false): ExactResult | undefined {
  if (!Number.isFinite(value)) return undefined;
  if (Math.abs(value) < 1e-12) return undefined;

  // Check pure rational first
  const rat = approximateRational(value, 9999, 1e-11);
  if (rat) {
    if (rat.den === 1) return undefined; // integer doesn't need fraction view
    if (preferMixed && Math.abs(rat.num) > rat.den) {
      const sign = rat.num < 0 ? '-' : '';
      const absN = Math.abs(rat.num);
      const whole = Math.floor(absN / rat.den);
      const rem = absN % rat.den;
      return {
        kind: 'mixed',
        displayWhole: `${sign}${whole}`,
        displayNum: `${rem}`,
        displayDen: `${rat.den}`,
        decimalValue: value,
        texLike: `${sign}${whole} ${rem}/${rat.den}`,
      };
    }
    return {
      kind: 'rational',
      displayNum: `${rat.num}`,
      displayDen: `${rat.den}`,
      decimalValue: value,
      texLike: `${rat.num}/${rat.den}`,
    };
  }

  // Check rational multiple of PI
  const piRatio = approximateRational(value / Math.PI, 999, 1e-10);
  if (piRatio && piRatio.num !== 0 && piRatio.den <= 360) {
    const numStr =
      piRatio.num === 1 ? 'π' : piRatio.num === -1 ? '-π' : `${piRatio.num}π`;
    if (piRatio.den === 1) {
      return {
        kind: 'pi',
        displayNum: numStr,
        decimalValue: value,
        texLike: numStr,
      };
    }
    return {
      kind: 'pi',
      displayNum: numStr,
      displayDen: `${piRatio.den}`,
      decimalValue: value,
      texLike: `${numStr}/${piRatio.den}`,
    };
  }

  // Check rational multiple of sqrt(k)
  for (const k of COMMON_RADICANDS) {
    const r = approximateRational(value / Math.sqrt(k), 120, 1e-10);
    if (r && r.num !== 0) {
      const prefix = r.num === 1 ? '' : r.num === -1 ? '-' : `${r.num}`;
      const numStr = `${prefix}√${k}`;
      if (r.den === 1) {
        return {
          kind: 'surd',
          displayNum: numStr,
          decimalValue: value,
          texLike: numStr,
        };
      }
      return {
        kind: 'surd',
        displayNum: numStr,
        displayDen: `${r.den}`,
        decimalValue: value,
        texLike: `${numStr}/${r.den}`,
      };
    }
  }

  return undefined;
}

const SUPERSCRIPTS: Record<string, string> = {
  '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴',
  '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹', '-': '⁻',
};

export function toSuperscript(s: string): string {
  return s
    .split('')
    .map((ch) => SUPERSCRIPTS[ch] ?? ch)
    .join('');
}

export function primeFactorizeString(n: number): string {
  if (!Number.isFinite(n) || !Number.isInteger(n) || Math.abs(n) > 9999999999) {
    return 'Math ERROR';
  }
  const absN = Math.abs(n);
  if (absN < 2) return `${n}`;
  const factors: Array<[number, number]> = [];
  let rem = absN;
  let d = 2;
  while (d * d <= rem) {
    if (rem % d === 0) {
      let count = 0;
      while (rem % d === 0) {
        rem /= d;
        count++;
      }
      factors.push([d, count]);
    }
    d += d === 2 ? 1 : 2;
  }
  if (rem > 1) factors.push([rem, 1]);
  const sign = n < 0 ? '-' : '';
  return (
    sign +
    factors
      .map(([p, e]) => (e === 1 ? `${p}` : `${p}${toSuperscript(`${e}`)}`))
      .join('×')
  );
}

export function formatDms(val: number): string {
  if (!Number.isFinite(val)) return 'Math ERROR';
  const sign = val < 0 ? '-' : '';
  let abs = Math.abs(val);
  const deg = Math.floor(abs + 1e-11);
  abs = Math.max(0, (abs - deg) * 60);
  let min = Math.floor(abs + 1e-9);
  let sec = (abs - min) * 60;
  sec = Math.round(sec * 100) / 100;
  if (sec >= 60) {
    sec -= 60;
    min += 1;
  }
  if (min >= 60) {
    min -= 60;
    return `${sign}${deg + 1}°0'0"`;
  }
  const secStr = Number.isInteger(sec) ? `${sec}` : sec.toFixed(2).replace(/\.?0+$/, '');
  return `${sign}${deg}°${min}'${secStr}"`;
}

const ENG_PREFIXES: Record<number, string> = {
  [-18]: 'a',
  [-15]: 'f',
  [-12]: 'p',
  [-9]: 'n',
  [-6]: 'μ',
  [-3]: 'm',
  [3]: 'k',
  [6]: 'M',
  [9]: 'G',
  [12]: 'T',
  [15]: 'P',
  [18]: 'E',
};

export function formatEng(val: number, expShift = 0, useSymbol = false, decimalMark: 'DOT' | 'COMMA' = 'DOT'): string {
  if (!Number.isFinite(val)) return 'Math ERROR';
  if (val === 0) return `0×10${toSuperscript(`${expShift}`)}`;
  const sign = val < 0 ? '-' : '';
  const abs = Math.abs(val);
  let exp3 = Math.floor(Math.log10(abs) / 3) * 3;
  exp3 += expShift * 3;
  const mant = abs / Math.pow(10, exp3);
  let mantStr = Number(mant.toPrecision(10)).toString();
  if (decimalMark === 'COMMA') mantStr = mantStr.replace('.', ',');
  if (useSymbol && ENG_PREFIXES[exp3]) {
    return `${sign}${mantStr}${ENG_PREFIXES[exp3]}`;
  }
  return `${sign}${mantStr}×10${toSuperscript(`${exp3}`)}`;
}

export function formatRealNumber(val: number, settings: CalcSettings): string {
  if (!Number.isFinite(val)) return 'Math ERROR';
  if (Math.abs(val) < 1e-13) val = 0;

  // Clean tiny floating point noise like 0.30000000000000004
  const rounded12 = Number(val.toPrecision(12));
  const num = Object.is(rounded12, -0) ? 0 : rounded12;
  const abs = Math.abs(num);

  let out = '';
  const { numberFormat, formatDigits } = settings;

  if (numberFormat === 'FIX') {
    if (abs >= 1e10) {
      out = toSciString(num, Math.min(9, formatDigits + 1));
    } else {
      out = num.toFixed(formatDigits);
    }
  } else if (numberFormat === 'SCI') {
    out = toSciString(num, formatDigits === 0 ? 10 : formatDigits);
  } else {
    const lowThreshold = numberFormat === 'NORM2' ? 1e-9 : 1e-2;
    if (abs !== 0 && (abs >= 1e10 || abs < lowThreshold)) {
      out = toSciString(num, 10);
    } else {
      out = Number(num.toPrecision(10)).toString();
      if (out.includes('e')) {
        out = toSciString(num, 10);
      }
    }
  }

  if (settings.digitSeparator && !out.includes('×10')) {
    const parts = out.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    out = parts.join('.');
  }

  if (settings.decimalMark === 'COMMA') {
    out = out.replace('.', ',');
  }

  return out;
}

function toSciString(num: number, sigDigits: number): string {
  if (num === 0) return '0';
  const sign = num < 0 ? '-' : '';
  const abs = Math.abs(num);
  const exp = Math.floor(Math.log10(abs));
  const mant = abs / Math.pow(10, exp);
  const mantStr = Number(mant.toPrecision(Math.max(1, Math.min(10, sigDigits)))).toString();
  return `${sign}${mantStr}×10${toSuperscript(`${exp}`)}`;
}
