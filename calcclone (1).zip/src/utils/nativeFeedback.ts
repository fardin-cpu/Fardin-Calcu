import { Capacitor } from '@capacitor/core';
import { Haptics, ImpactStyle } from '@capacitor/haptics';
import { StatusBar } from '@capacitor/status-bar';

let audioCtx: AudioContext | null = null;
let noiseBuf: AudioBuffer | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const Ctx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return null;
  if (!audioCtx) {
    audioCtx = new Ctx();
  }
  return audioCtx;
}

function getNoiseBuffer(ctx: AudioContext): AudioBuffer {
  if (noiseBuf && noiseBuf.sampleRate === ctx.sampleRate) {
    return noiseBuf;
  }
  const len = Math.max(1, Math.floor(ctx.sampleRate * 0.01));
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < len; i++) {
    data[i] = (Math.random() * 2 - 1) * (1 - i / len);
  }
  noiseBuf = buf;
  return buf;
}

export function playTapSound(strength: 'light' | 'medium' = 'light'): void {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      void ctx.resume().catch(() => {});
    }

    const now = ctx.currentTime;
    const isMedium = strength === 'medium';

    // 1. Crisp tactile switch transient (bandpass-filtered noise burst)
    const noiseSrc = ctx.createBufferSource();
    noiseSrc.buffer = getNoiseBuffer(ctx);

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(isMedium ? 2100 : 2650, now);
    filter.Q.setValueAtTime(1.8, now);

    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(isMedium ? 0.11 : 0.085, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.009);

    noiseSrc.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(ctx.destination);
    noiseSrc.start(now);
    noiseSrc.stop(now + 0.01);

    // 2. Subtle plastic keycap body thump (rapid pitch-drop triangle)
    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(isMedium ? 680 : 880, now);
    osc.frequency.exponentialRampToValueAtTime(isMedium ? 175 : 240, now + 0.014);

    const oscGain = ctx.createGain();
    oscGain.gain.setValueAtTime(isMedium ? 0.08 : 0.055, now);
    oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.018);

    osc.connect(oscGain);
    oscGain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.02);
  } catch {
    // Ignore audio context errors on restricted/headless environments
  }
}

export function triggerHaptic(strength: 'light' | 'medium' = 'light'): void {
  try {
    if (Capacitor.isNativePlatform()) {
      void Haptics.impact({
        style: strength === 'medium' ? ImpactStyle.Medium : ImpactStyle.Light,
      }).catch(() => {});
      return;
    }
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      navigator.vibrate(strength === 'medium' ? 16 : 9);
    }
  } catch {
    // Ignore unsupported platform/permission errors
  }
}

export async function initNativeFullscreen(): Promise<void> {
  try {
    if (Capacitor.isNativePlatform()) {
      await StatusBar.setOverlaysWebView({ overlay: true }).catch(() => {});
      await StatusBar.hide().catch(() => {});
    }
  } catch {
    // Ignore status bar errors on web/older platforms
  }
}
