FARDIN FX-991F - APK build (Capacitor + GitHub Actions)

1. github.com e notun repository banao (e.g. fardin-fx991f).
2. ZIP er shob file (www/, package.json, capacitor.config.json, .github/) repo te upload koro.
   Jodi ".github" folder upload na hoy: GitHub e "Add file > Create new file" e
   .github/workflows/build-apk.yml likhe build-apk.yml.copy.txt er content paste koro.
3. Repo > Actions tab > "Build APK" > Run workflow (push korleo auto chole).
4. 4-6 minute pore run er page e Artifacts > FARDIN-FX-991F-apk download koro.
   ZIP khule app-debug.apk phone e install koro (Unknown sources allow korte hobe).

Calculator edit korte: www/index.html
